Create c++ from xxx.proto :
.\protoc.exe -I . --cpp_out=. xxx.proto

Create c++ rpcz from xxx.proto :
.\protoc.exe -I . --cpp_rpcz_out=. xxx.proto