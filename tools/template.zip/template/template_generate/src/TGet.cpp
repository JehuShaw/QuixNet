#include <stdio.h>
#include <string.h>

#define MAX_PATH 260
#define MAX_LEN 2048

int main(int argc, char *argv[])
{
	freopen("table_record.txt", "r", stdin);
	freopen("TGet.txt", "w", stdout);


	char buf[MAX_LEN];

	// ignore first key field
	while (gets_s(buf) != NULL)
	{
		if (buf[0] == '/')
		{
			continue;
		}
		else
		{
			break;
		}
	}
	
	// read next
	while(gets_s(buf) != NULL)
	{
		if(buf[0] == '/')
		{
			continue;
		}
		
		char * p = buf;
		while(*p == ' ' || *p == 9/*Tab*/)	//clear tab and space
		{
		 	p++;
		}
		if(*p == '/' || *p == 0)		
			continue;
		
		char words[MAX_PATH], vars[MAX_PATH];
		sscanf(p, "%s %s", words, vars);	
		//����õ��� vars �������� silverBase;�����ģ������и��ֺ�
		//��Ϊ��������б�ʱ����Ҳ��Ҫ�ֺţ����Ծ�ûȥ����������Get��Set�����У�������� 
			
        if(vars[0] >= 'a' && vars[0] <= 'z') {
            vars[0] = vars[0] - 'a' + 'A';				//����ĸ��д
        }
		
		//this Case: silverBase=0;//���һ���
		//������ֵȺţ��ʹӵȺŴ��ص� 
		char * pEquals = strchr(vars, '=');
		if(pEquals != NULL)
		{			
			*pEquals = '\0';
		}
		else
		{
			//���û�з��ֵȺţ����п����������������
			// 1. private Integer silverBase;//���һ���
			// 2. private Integer silverBase;
			/* ���Բ������������ַ�ʽ���� 
			int len = strlen(vars);
			vars[len-1] = '\0';
			*/
			char * pFen = strchr(vars, ';');	// 100%����
			if(pFen != NULL)
			{
				*pFen = '\0';
			}			
		}
		
		
		if(strcmp(words, "string")==0) 
		{
			printf("\\tstd::string Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_str%s;\\n"
				"\\t}\n", vars,vars);
		}
		else if(strcmp(words, "int8_t") == 0)
		{
			printf("\\tint8_t Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_n%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(strcmp(words, "uint8_t") == 0)
		{
			printf("\\tuint8_t Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_n%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(strcmp(words, "int16_t") == 0)
		{
			printf("\\tint16_t Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_n%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(0 == strcmp(words, "uint16_t"))
		{
			printf("\\tuint16_t Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_n%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(strcmp(words, "int32_t") == 0)
		{
			printf("\\tint32_t Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_n%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(0 == strcmp(words, "uint32_t"))
		{
			printf("\\tuint32_t Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_n%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(0 == strcmp(words, "int64_t"))
		{
			printf("\\tint64_t Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_n%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(0 == strcmp(words, "uint64_t"))
		{
			printf("\\tuint64_t Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_n%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(strcmp(words, "char")==0)
		{
			printf("\\tchar Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_c%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(strcmp(words, "bool")==0)
		{
			printf("\\tbool Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_b%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(0 == strcmp(words, "double"))
		{
			printf("\\tdouble Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_d%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if(0 == strcmp(words, "float"))
		{
			printf("\\tfloat Get%s() const {\\n"
				"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				"\\t\\treturn m_f%s;\\n"
				"\\t}\n",vars,vars);
		}
		else if (0 == strcmp(words, "tiny::Json") || 0 == strcmp(words, "Json"))
		{
			char cFirst = vars[0];
			if (cFirst != '\0') {
				if (cFirst >= 'A' && cFirst <= 'Z') {
					//����ĸСд
					cFirst = cFirst + 'a' - 'A';
				}
				printf("\\t%s Get%s() const {\\n"
					"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
					"\\t\\treturn m_%c%s;\\n"
					"\\t}\n", words, vars, cFirst, (vars + 1));

				printf("\\tstd::string Get%sStr() const {\\n"
					"\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
					"\\t\\treturn m_%c%s.WriteJson();\\n"
					"\\t}\n", vars, cFirst, (vars + 1));
			}
		}
		else
		{
            char cFirst = vars[0];
            if(cFirst != '\0') {
                if(cFirst >= 'A' && cFirst <= 'Z') {
                    //����ĸСд
                    cFirst = cFirst + 'a' - 'A';
                }
			    printf("\\t%s Get%s() const {\\n"
				    "\\t\\tthd::CScopedReadLock rdLock(m_rwTicket);\\n"
				    "\\t\\treturn m_%c%s;\\n"
				    "\\t}\n", words, vars, cFirst, (vars + 1));
            }
		}
	}
	return 0;
}