#include <stdio.h>
#include <string.h>

#define MAX_PATH 260
#define MAX_LEN 2048

int main(int argc, char *argv[])
{
	//_mkdir("tmp");

	freopen("table_record.txt", "r", stdin);
	freopen("TVars.txt", "w", stdout);
	
	char buf[MAX_LEN];
	// ignore first key field
	while (gets_s(buf) != NULL)
	{
		if (buf[0] == '/')
		{
			continue;
		}
		else
		{
			break;
		}
	}
	// next field
	while(gets_s(buf) != NULL)
	{
		if(buf[0] == '/')
		{
			puts(buf);
			continue;
		}
		
		char * p = buf;
		while(*p == ' ' || *p == 9/*Tab*/)	//pass tab and space
		{
			putchar(*p);
		 	p++;
		}
		if(*p == '/')
		{
			puts(p);
			continue;
		}
		else if(*p == 0)
		{
			puts("");
			continue;
		}
		
		
		char words[MAX_PATH], vars[MAX_PATH];
		sscanf(p, "%s %s", words, vars);
		
		//����õ��� vars ��Ŀǰ֪�������������
		//1. silverBase;
		//2. silverBase=0;//����  or   silverBase;//���� 
		//3. silverBase 
		//��3�������in�ļ������������У�private String silverBase = NULL; //This is silverBase.. 
		
		bool bDefaultType = false;
		if(strcmp(words, "string")==0) 
		{
			printf("std::string m_str");
		}
		else if(strcmp(words, "int8_t") == 0)
		{
			printf("int8_t m_n");
		}
		else if(strcmp(words, "uint8_t") == 0)
		{
			printf("uint8_t m_n");
		}
		else if(strcmp(words, "int16_t") == 0)
		{
			printf("int16_t m_n");
		}
		else if(0 == strcmp(words, "uint16_t"))
		{
			printf("uint16_t m_n");
		}
		else if(strcmp(words, "int32_t") == 0)
		{
			printf("int32_t m_n");
		}
		else if(0 == strcmp(words, "uint32_t"))
		{
			printf("uint32_t m_n");
		}
		else if(0 == strcmp(words, "int64_t"))
		{
			printf("int64_t m_n");
		}
		else if(0 == strcmp(words, "uint64_t"))
		{
			printf("uint64_t m_n");
		}
		else if(strcmp(words, "char")==0)
		{
			printf("char m_c");
		}
		else if(strcmp(words, "bool")==0)
		{
			printf("bool m_b");
		}
		else if(0 == strcmp(words, "double"))
		{
			printf("double m_d");
		}
		else if(0 == strcmp(words, "float"))
		{
			printf("float m_f");
		}
		else
		{
			printf("%s m_", words);
            bDefaultType = true;
		}

        if(vars[0] >= 'a' && vars[0] <= 'z') {
            vars[0] = vars[0] - 'a' + 'A';				//����ĸ��д
        }	
		char * pFen = strchr(vars, ';');//��Ѱ�ֺ� 
		
		char * pEqual = strchr(vars, '=');
		if(pEqual == NULL)
		{
            if(bDefaultType) {
                char cFirst = vars[0];
                if(cFirst != '\0') {
                    if(cFirst >= 'A' && cFirst <= 'Z') {
                        //����ĸСд
                        cFirst = cFirst + 'a' - 'A';
                    }
                    printf("%c%s", cFirst, (vars+1));
                }
            } else {
			    printf("%s", vars);
            }
		}
		else
		{				
			*pEqual = '\0';
			pEqual = strchr(pEqual+1, ';');
            if(bDefaultType) {
                char cFirst = vars[0];
                if(cFirst != '\0') {
                    if(cFirst >= 'A' && cFirst <= 'Z') {
                        //����ĸСд
                        cFirst = cFirst + 'a' - 'A';
                    }
                    printf("%c%s", cFirst, (vars+1));
                }
            } else {
                printf("%s", vars);
            }
            if(NULL != pEqual) {
			    printf("%s", pEqual);
            }
		}

		if(pFen == NULL)
		{
			//û�зֺţ�˵���ǵ����������Ҫ��β�����			
			pFen = strchr(buf, ';');
            if(NULL != pFen) {
			    printf("%s", pFen);
            }
		}
		
		puts("");
	}
	
	return 0;
}