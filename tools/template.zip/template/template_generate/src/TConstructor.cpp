#include <stdio.h>
#include <string.h>
#include <map>

#define MAX_LEN 2048
#define FIRST_INDEX 0

int main(int argc, char *argv[])
{

	freopen("table_header.txt", "r", stdin);
	
	int index = FIRST_INDEX;
	char mapName[100][MAX_LEN];
	char bufT[MAX_LEN];
	while(gets_s(bufT) != NULL)
	{
		if(bufT[0] == '/')
			continue;
		
		char * p = bufT;
		while(*p == ' ' || *p == 9/*Tab*/)	//pass tab and space
		 	p++;
			
		if(*p == '/')
			continue;

		else if(*p == 0)
			continue;

		char words[MAX_LEN];
		sscanf(p, "%s", words);	//
		
		char szDefine[MAX_LEN];
		strcpy(szDefine, words);
		
		for(int i=strlen(szDefine); i>=0; i--)
		{
			if(szDefine[i] >= 97)
				szDefine[i] = szDefine[i] - 'a' + 'A';
		}	
		
		strcpy(mapName[index], szDefine);
		
		++index;
	}



////////////////////////////////////////////////////////

	freopen("TVars.txt", "r", stdin);
	freopen("TConstructor.txt", "w+", stdout);
	
	index = FIRST_INDEX;
	printf("(%%s, %%s[FIELD_%s]);\n", mapName[index]);
	++index;
	//printf("uint32_t nId = (uint32_t)atoi(row[FIELD_%s].c_str());\n", mapName[index++]);
	char buf[MAX_LEN];
	while(gets_s(buf) != NULL)
	{
		if(buf[0] == '/')
		{
			//puts(buf); //����������ע�� 
			continue;
		}
		
		char * p = buf;
		while(*p == ' ' || *p == 9/*Tab*/)	//pass tab and space
		{
			//putchar(*p);	//�����ǰ��Ŀո�Tab�ȵ� 
		 	p++;
		}
		if(*p == '/')
		{
			//puts(p);	//���Ҳ�������ע�� 
			continue;
		}
		else if(*p == 0)
		{
			//puts("");	//����Ҳ������� 
			continue;
		}

		char words[MAX_LEN], vars[MAX_LEN];
		sscanf(p, "%s %s", words, vars);	//
		
		char * pEquals = strchr(vars, '=');
		if(pEquals != NULL)
		{
			*pEquals = '\0';
		}
		else
		{
			char * pFen = strchr(vars, ';');	// 100%����
			if(pFen != NULL)
			{
				*pFen = '\0';
			}
		}

		printf("(%%s%s, %%s[FIELD_%s]);\n", vars, mapName[index]);

		++index;
	}
	return 0;
}
