#include <stdio.h>
#include <string.h>

#define MAX_PATH 260
#define MAX_LEN 2048

int main(int argc, char *argv[])
{
	freopen("table_record.txt", "r", stdin);
	freopen("TCopyConstructor.txt", "w+", stdout);
	
	char buf[MAX_LEN];

	// ignore first key field
	while (gets_s(buf) != NULL)
	{
		if (buf[0] == '/')
		{
			continue;
		}
		else
		{
			break;
		}
	}
	// next field
	while(gets_s(buf) != NULL)
	{
		if(buf[0] == '/')
		{
			//puts(buf); //����������ע�� 
			continue;
		}
		
		char * p = buf;
		while(*p == ' ' || *p == 9/*Tab*/)	//pass tab and space
		{
			//putchar(*p);	//�����ǰ��Ŀո�Tab�ȵ� 
		 	p++;
		}
		if(*p == '/')
		{
			//puts(p);	//���Ҳ�������ע�� 
			continue;
		}
		else if(*p == 0)
		{
			//puts("");	//����Ҳ������� 
			continue;
		}

		
		char words[MAX_PATH], vars[MAX_PATH];
		sscanf(p, "%s %s", words, vars);
        if(vars[0] >= 'a' && vars[0] <= 'z') {
		    vars[0] = vars[0] - 'a' + 'A';				//����ĸ��д
        }
		
		char * pEquals = strchr(vars, '=');
		if(pEquals != NULL)
		{
			*pEquals = '\0';
		}
		else
		{
			char * pFen = strchr(vars, ';');	// 100%����
			if(pFen != NULL)
			{
				*pFen = '\0';
			}
		}
		
		if(strcmp(words, "int32_t") == 0 || strcmp(words, "uint32_t") == 0 || strcmp(words, "int64_t") == 0 || strcmp(words, "uint64_t") == 0
			|| strcmp(words, "int8_t")==0 || strcmp(words, "uint8_t") == 0 || strcmp(words, "int16_t") == 0 || strcmp(words, "uint16_t") == 0)
		{
			printf("m_n%s(%%s.m_n%s),\n", vars, vars);
		}
		else if(strcmp(words, "char")==0)
		{
			printf("m_c%s(%%s.m_c%s),\n", vars, vars);
		}
		else if(strcmp(words, "bool")==0)
		{
			printf("m_b%s(%%s.m_b%s),\n", vars, vars);
		}
		else if(0 == strcmp(words, "double"))
		{
			printf("m_d%s(%%s.m_d%s),\n", vars, vars);
		}
		else if(0 == strcmp(words, "float"))
		{
			printf("m_f%s(%%s.m_f%s),\n", vars, vars);
		}
		else if(strcmp(words, "string") == 0)
		{		
			printf("m_str%s(%%s.m_str%s),\n", vars, vars);
		}
		else
		{
            char cFirst = vars[0];
            if(cFirst != '\0') {
                if(cFirst >= 'A' && cFirst <= 'Z') {
                    //����ĸСд
                    cFirst = cFirst + 'a' - 'A';
                }
			    printf("m_%c%s(%%s.m_%c%s),\n", cFirst, (vars+1), cFirst, (vars + 1));
            }
		}
	}
	fseek(stdout, -3L, SEEK_END);
	printf(" ");
	return 0;
}
