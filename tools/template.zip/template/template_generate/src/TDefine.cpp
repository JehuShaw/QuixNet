#include <stdio.h>
#include <string.h>

#define MAX_LEN 2048

int main(int argc, char *argv[])
{
	freopen("table_header.txt", "r", stdin);
	freopen("TDefine.txt", "w+", stdout);
	
	int index = 1;
	char buf[MAX_LEN];
	while(gets_s(buf) != NULL)
	{
		if(buf[0] == '/')
		{
			//puts(buf); //����������ע�� 
			continue;
		}
		
		char * p = buf;
		while(*p == ' ' || *p == 9/*Tab*/)	//pass tab and space
		{
			//putchar(*p);	//�����ǰ��Ŀո�Tab�ȵ� 
		 	p++;
		}
		if(*p == '/')
		{
			//puts(p);	//���Ҳ�������ע�� 
			continue;
		}
		else if(*p == 0)
		{
			//puts("");	//����Ҳ������� 
			continue;
		}

		
		char words[MAX_LEN];
		sscanf(p, "%s", words);	//
		
		char szDefine[MAX_LEN];
		strcpy(szDefine, words);
		
		for(int i=strlen(szDefine); i>=0; i--)
		{
			if(szDefine[i] >= 97)
				szDefine[i] = szDefine[i] - 'a' + 'A';
		}	
		
		printf("#define FIELD_%s std::string(\"%s\")", szDefine, words);
		puts("");
		++index;
	}
	return 0;
}
