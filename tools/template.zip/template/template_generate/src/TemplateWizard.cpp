#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#define MAX_LEN 2048
#define KEY_WORD_SIZE 512
#define FIRST_INDEX 0

static inline void EscapeCharacter(char* szBuf){
	long nDestIndex = 0;
	long nSrcIndex = 1;
	while('\0' != szBuf[nDestIndex]) {

		szBuf[nDestIndex] = szBuf[nSrcIndex - 1];

		if('\\' == szBuf[nDestIndex]) {
			if('\0' != szBuf[nSrcIndex]) {
				if('n' == szBuf[nSrcIndex]) {
					szBuf[nDestIndex] = '\n';
					++nDestIndex;
					++nSrcIndex;
					szBuf[nDestIndex] = szBuf[nSrcIndex];
					++nSrcIndex;
					continue;
				} else if('t' == szBuf[nSrcIndex]) {
					szBuf[nDestIndex] = '\t';
					++nDestIndex;
					++nSrcIndex;
					szBuf[nDestIndex] = szBuf[nSrcIndex];
					++nSrcIndex;
					continue;
				} else if('b' == szBuf[nSrcIndex]) {
					szBuf[nDestIndex] = '\b';
					++nDestIndex;
					++nSrcIndex;
					szBuf[nDestIndex] = szBuf[nSrcIndex];
					++nSrcIndex;
					continue;
				} else if('\\' == szBuf[nSrcIndex]) {
					++nDestIndex;
					++nSrcIndex;
					szBuf[nDestIndex] = szBuf[nSrcIndex];
					++nSrcIndex;
					continue;
                }
			}
		}

		++nDestIndex;
		++nSrcIndex;
	}
}

int main(int argc, char *argv[])
{
	printf("Enter the class name starting with C:");
	char szName[MAX_LEN];
	if (scanf("%s", szName) < 1) {
		printf("\n Error! Must input the name of the class.\n");
		return 0;
	}
	szName[MAX_LEN - 1] = '\0';

	printf("Enter the row structure name (Automatically add \"Row\") :");
	char szRowName[MAX_LEN];
	if (scanf("%s", szRowName) < 1) {
		printf("\n Error! Must input the name of the row.\n");
		return 0;
	}
	szRowName[MAX_LEN - 1] = '\0';
	if (szRowName[0] >= 97) {
		szRowName[0] = szRowName[0] - 'a' + 'A';
	}
	char szMapName[MAX_LEN];
	strcpy(szMapName, szRowName);
	strcat(szRowName, "Row");

	printf("Whether to extend this class ? ��Yes: input 'Y' or 'y' ��No:(default) input 'N' or 'n')");
	char szExtendClass[2];
	if (scanf("%s", szExtendClass) < 1) {
		printf("\n Error! Must input whether extend this class.\n");
		return 0;
	}
	szExtendClass[1] = '\0';
	
	char szClassName[MAX_LEN];
	strcpy(szClassName, szName+1);
	

	char szFileName_h[MAX_LEN], szFileName_cpp[MAX_LEN];
	strcpy(szFileName_h, szClassName);
	strcpy(szFileName_cpp, szClassName);
	strcat(szFileName_h, ".h");
	strcat(szFileName_cpp, ".cpp");	

	char szDefine[MAX_LEN];
	strcpy(szDefine, szClassName);
	
	strcpy(szClassName, szName);
	
	for(int i=strlen(szDefine); i>=0; i--)
	{
		if(szDefine[i] >= 97)
			szDefine[i] = szDefine[i] - 'a' + 'A';
	}	
	
	strcat(szMapName, "_ROWS_T");
	for(int i=strlen(szMapName); i>=0; i--)
	{
		if(szMapName[i] >= 97)
			szMapName[i] = szMapName[i] - 'a' + 'A';
	}
	

	FILE * fout_h = fopen(szFileName_h, "w");
	
	struct tm *t;
	time_t tt;
    time(&tt);
    t=localtime(&tt);
 	fprintf(fout_h, "/*\n\tCode Generate by tool %4d-%02d-%02d %02d:%02d:%02d\n*/\n\n",t->tm_year+1900,t->tm_mon+1,t->tm_mday,t->tm_hour,t->tm_min,t->tm_sec);
	
	fprintf(fout_h, "#ifndef TEMP_%s_H\n#define TEMP_%s_H\n\n", szDefine,szDefine);
	fprintf(fout_h, "#include <vector>\n#include \"Common.h\"\n#include \"TemplateBase.h\"\n#include \"SpinRWLock.h\"\n#include \"ScopedRWLock.h\"");	
	if ('Y' != szExtendClass[0] && 'y' != szExtendClass[0]) {
		fprintf(fout_h, "\n#include \"Singleton.h\"");
	}
	fprintf(fout_h, "\n\n");

	// typedef
	char szBuf[MAX_LEN];
	fprintf(fout_h, "class %s {\npublic:\n\t%s(void):\n", szRowName, szRowName);

	//���캯�� 
	FILE * fin = fopen("RConstructor.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: RConstructor.txt\n");
		fclose(fout_h);
		return -1;
	}

	while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{
		fprintf(fout_h, "\t\t%s", szBuf);
	}
	fprintf(fout_h, "\t{}\n\n");
	fclose(fin);

	// ��ؐ���캯��
	fin = fopen("TCopyConstructor.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: TCopyConstructor.txt\n");
		fclose(fout_h);
		return -1;
	}

	fprintf(fout_h, "\t%s(const %s& orig):\n", szRowName, szRowName);
	while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{
		fprintf(fout_h, "\t\t");
		fprintf(fout_h, szBuf, "orig");
	}
	fprintf(fout_h, "\t{}\n\n");
	fclose(fin);

	//��������
	fprintf(fout_h, "\t~%s(void) {}\n\n", szRowName);

	// �xֵ������
	fin = fopen("TEqualOperator.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: TEqualOperator.txt\n");
		fclose(fout_h);
		return -1;
	}

	fprintf(fout_h, "\t%s& operator = (const %s& right) {\n", szRowName, szRowName);
	fprintf(fout_h, "\t\tif (this == &right) {\n\t\t\treturn *this;\n\t\t}\n");
	fprintf(fout_h, "\t\tthd::CScopedReadLock rdLock(right.m_rwTicket);\n");
	fprintf(fout_h, "\t\tthd::CScopedWriteLock wrLock(m_rwTicket);\n");
	while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{
		fprintf(fout_h, "\t\t");
		fprintf(fout_h, szBuf, "right");
	}
	fprintf(fout_h, "\t\treturn *this;\n\t}\n\n");
	fclose(fin);

	//Get & Set
	fin = fopen("TGet.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: TGet.txt\n");
		fclose(fout_h);
		return -1;
	}
	while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{
		EscapeCharacter(szBuf);
		fprintf(fout_h, "%s\n", szBuf);
	}
	fclose(fin);

	fin = fopen("TSet.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: TSet.txt\n");
		fclose(fout_h);
		return -1;
	}
	while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{
		EscapeCharacter(szBuf);
		fprintf(fout_h, szBuf, szDefine);
		fprintf(fout_h, "\n");
	}
	fclose(fin);

	fin = fopen("table_record.txt", "r");
	if(!fin)
	{
		printf("Error! No this file: TVars.txt\n");
		fclose(fout_h);
		return -1;
	}
	// get first
	char szKeyType[KEY_WORD_SIZE] = {'\0'};
	char szKeyVar[KEY_WORD_SIZE] = {'\0'};
	while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
	{
		if(szBuf[0] == '/') {
			continue;
		}
		sscanf(szBuf, "%s %s", szKeyType, szKeyVar);
		char * pEquals = strchr(szKeyVar, '=');
		if(pEquals != NULL)
		{
			*pEquals = '\0';
		}
		else
		{
			char * pFen = strchr(szKeyVar, ';');	// 100%����
			if(pFen != NULL)
			{
				*pFen = '\0';
			}
		}
		// get first
		break;
	}
	fprintf(fout_h, "private:\n \tfriend class %s;\n", szClassName);
	fin = fopen("TVars.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: TVars.txt\n");
		fclose(fout_h);
		return -1;
	}
	while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
	{
		fprintf(fout_h, "\t%s", szBuf);
	}	
	fclose(fin);	
	fprintf(fout_h, "\t// read write lock.\n\tthd::CSpinRWLock m_rwTicket;\n};\n\n");
	
	fprintf(fout_h, "typedef std::map<%s, %s> %s;\n\n", szKeyType, szRowName, szMapName);
	
	// class
	fprintf(fout_h, "class %s\n\t: public CTemplateBase\n", szClassName);
	if ('Y' != szExtendClass[0] && 'y' != szExtendClass[0]) {
		fprintf(fout_h, "\t, public util::Singleton<%s>\n", szClassName);
	}
	fprintf(fout_h, "{\n");
	fprintf(fout_h, "public:\n");
	
	fprintf(fout_h, "\tvirtual void OnRowData(csv_columns_t& row);\n\n");

	if ('Y' == szExtendClass[0] || 'y' == szExtendClass[0]) {
		fprintf(fout_h, "\tvoid GetRowData(csv_columns_t& inRow, %s& outID, %s& outRow);\n\n", szKeyType, szRowName);
	}
	
	fprintf(fout_h, "\tinline %s* GetRow(%s %s) {\n", szRowName, szKeyType, szKeyVar);
	fprintf(fout_h, "\t\tthd::CScopedReadLock rdLock(m_rwLock);\n");
	fprintf(fout_h, "\t\t%s::iterator it(m_rows.find(%s));\n", szMapName, szKeyVar);
	fprintf(fout_h, "\t\tif (it != m_rows.end()) { return &it->second; }\n");
	fprintf(fout_h, "\t\treturn NULL;\n\t}\n\n");	
	
	if ('Y' != szExtendClass[0] && 'y' != szExtendClass[0]) {
		fprintf(fout_h, "private:\n");
	} else {
		fprintf(fout_h, "protected:\n");
	}
	fprintf(fout_h, "\t%s m_rows;\n", szMapName);
	fprintf(fout_h, "\tthd::CSpinRWLock m_rwLock;\n");
	fprintf(fout_h, "};\n\n#endif /* TEMP_%s_H */\n", szDefine);
	fclose(fout_h);
	
	
	///////////////////////////////CPP//////////////////////////////////////
	FILE * fout_cpp = fopen(szFileName_cpp, "w");	
	fprintf(fout_cpp, "#include \"%s\"\n", szFileName_h);
	fprintf(fout_cpp, "#include \"CsvParser.h\"\n");
	fprintf(fout_cpp, "#include \"NodeDefines.h\"\n");
	fprintf(fout_cpp, "#include \"StringResolved.h\"\n\n");
	
	fin = fopen("TDefine.txt", "r");
	if(!fin)
	{
		printf("Error! No this file: Define.txt\n");
		fclose(fout_cpp);
		return -1;
	}
	int nCount = 0;
	while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
	{
		++nCount;
		fprintf(fout_cpp, "%s", szBuf);
	}	
	fclose(fin);
	
	fprintf(fout_cpp, "\n\n");	
	fprintf(fout_cpp, "void %s::OnRowData(csv_columns_t& row) {\n", szClassName);
	fprintf(fout_cpp, "\tassert(row.size() >= %d);\n\n", nCount);
	fprintf(fout_cpp, "\tutil::CStringResolved strResolved(csv_field_terminator);\n");
	fprintf(fout_cpp, "\t%s %s;\n", szKeyType, szKeyVar);
	fprintf(fout_cpp, "\t%s tRow;\n", szRowName);
	
	fin = fopen("TConstructor.txt", "r");
	if(!fin)
	{
		printf("Error! No this file: Constructor.txt\n");
		fclose(fout_cpp);
		return -1;
	}

	if(fgets(szBuf, MAX_LEN - 1, fin) != NULL) {
		char szTemp[MAX_LEN];
		sprintf(szTemp, szBuf, szKeyVar, "row");
		fprintf(fout_cpp, "\tstrResolved.CastToType%s", szTemp);
		while(fgets(szBuf, MAX_LEN - 1, fin) != NULL)
		{
			sprintf(szTemp, szBuf, "tRow.", "row");
			fprintf(fout_cpp, "\tstrResolved.CastToType%s", szTemp);
		}
	}
	fprintf(fout_cpp, "\n\tthd::CScopedWriteLock wrLock(m_rwLock);\n");
	fprintf(fout_cpp, "\tm_rows.insert(%s::value_type(%s, tRow));\n}\n",szMapName, szKeyVar);

	if ('Y' == szExtendClass[0] || 'y' == szExtendClass[0]) {
		fprintf(fout_cpp, "\n\n");
		fprintf(fout_cpp, "void %s::GetRowData(csv_columns_t& inRow, %s& outID, %s& outRow) {\n", szClassName, szKeyType, szRowName);
		fprintf(fout_cpp, "\tassert(inRow.size() >= %d);\n\n", nCount);
		fprintf(fout_cpp, "\tutil::CStringResolved strResolved(csv_field_terminator);\n");

		fin = fopen("TConstructor.txt", "r");
		if (!fin)
		{
			printf("Error! No this file: Constructor.txt\n");
			fclose(fout_cpp);
			return -1;
		}
		if (fgets(szBuf, MAX_LEN - 1, fin) != NULL) {
			char szTemp[MAX_LEN];
			sprintf(szTemp, szBuf, "outID", "inRow");
			fprintf(fout_cpp, "\tstrResolved.CastToType%s", szTemp);
			while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
			{
				sprintf(szTemp, szBuf, "outRow.", "inRow");
				fprintf(fout_cpp, "\tstrResolved.CastToType%s", szTemp);
			}
		}
		fprintf(fout_cpp, "}\n");
	}

	fclose(fin);	

	fclose(fout_cpp);
	return 0;
}


