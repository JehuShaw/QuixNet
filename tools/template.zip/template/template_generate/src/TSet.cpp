#include <stdio.h>
#include <string.h>

#define MAX_PATH 260
#define MAX_LEN 2048

int main(int argc, char *argv[])
{
	freopen("table_record.txt", "r", stdin);
	freopen("TSet.txt", "w", stdout);

	char buf[MAX_LEN];

	// ignore first key field
	while (gets_s(buf) != NULL)
	{
		if (buf[0] == '/')
		{
			continue;
		}
		else
		{
			break;
		}
	}
	
	// read next
	while(gets_s(buf) != NULL)
	{
		if(buf[0] == '/')
		{
			continue;
		}
		
		char * p = buf;
		while(*p == ' ' || *p == 9/*Tab*/)	//clear tab and space
		{
			//putchar(*p);
		 	p++;
		}
		if(*p == '/' || *p == 0)		
			continue;
		
		char words[MAX_PATH], vars[MAX_PATH];
		sscanf(p, "%s %s", words, vars);		
        if(vars[0] >= 'a' && vars[0] <= 'z') {
            vars[0] = vars[0] - 'a' + 'A';				//����ĸ��д
        }
		
		char * pEquals = strchr(vars, '=');
		if(pEquals != NULL)
		{
			*pEquals = '\0';
		}
		else
		{
			char * pFen = strchr(vars, ';');	// 100%����
			if(pFen != NULL)
			{
				*pFen = '\0';
			}
		}

		if(strcmp(words, "string")==0) 
		{
			printf("\\tvoid Set%s(const std::string& str%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_str%s = str%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(strcmp(words, "int8_t") == 0)
		{
			printf("\\tvoid Set%s(int8_t n%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_n%s = n%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(strcmp(words, "uint8_t") == 0)
		{
			printf("\\tvoid Set%s(uint8_t n%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_n%s = n%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(strcmp(words, "int16_t") == 0)
		{
			printf("\\tvoid Set%s(int16_t n%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_n%s = n%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(0 == strcmp(words, "uint16_t"))
		{
			printf("\\tvoid Set%s(uint16_t n%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_n%s = n%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(strcmp(words, "int32_t") == 0)
		{
			printf("\\tvoid Set%s(int32_t n%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_n%s = n%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(0 == strcmp(words, "uint32_t"))
		{
			printf("\\tvoid Set%s(uint32_t n%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_n%s = n%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(0 == strcmp(words, "int64_t"))
		{
			printf("\\tvoid Set%s(int64_t n%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_n%s = n%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(0 == strcmp(words, "uint64_t"))
		{
			printf("\\tvoid Set%s(uint64_t n%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_n%s = n%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(strcmp(words, "char")==0)
		{
			printf("\\tvoid Set%s(char c%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_c%s = c%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(strcmp(words, "bool")==0)
		{
			printf("\\tvoid Set%s(bool b%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_b%s = b%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(0 == strcmp(words, "double"))
		{
			printf("\\tvoid Set%s(double d%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_d%s = d%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if(0 == strcmp(words, "float"))
		{
			printf("\\tvoid Set%s(float f%s) {\\n"
				"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				"\\t\\tm_f%s = f%s;\\n"
				"\\t}\n",vars,vars,vars,vars);
		}
		else if (0 == strcmp(words, "tiny::Json") || 0 == strcmp(words, "Json"))
		{
			char cFirst = vars[0];
			if (cFirst != '\0') {
				if (cFirst >= 'A' && cFirst <= 'Z') {
					//����ĸСд
					cFirst = cFirst + 'a' - 'A';
				}
				printf("\\tvoid Set%s(const %s& %c%s) {\\n"
					"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
					"\\t\\tm_%c%s = %c%s;\\n"
					"\\t}\n", vars, words, cFirst, vars + 1, cFirst, vars + 1, cFirst, vars + 1);

				printf("\\tvoid Set%sStr(const std::string& %c%s) {\\n"
					"\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
					"\\t\\tm_%c%s.ReadJson(%c%s);\\n"
					"\\t}\n", vars, cFirst, vars + 1, cFirst, vars + 1, cFirst, vars + 1);
			}
		}
		else
		{
            char cFirst = vars[0];
            if(cFirst != '\0') {
                if(cFirst >= 'A' && cFirst <= 'Z') {
                    //����ĸСд
                    cFirst = cFirst + 'a' - 'A';
                }
			    printf("\\tvoid Set%s(const %s& %c%s) {\\n"
				    "\\t\\tthd::CScopedWriteLock wrLock(m_rwTicket);\\n"
				    "\\t\\tm_%c%s = %c%s;\\n"
				    "\\t}\n",vars,words,cFirst,vars+1,cFirst,vars+1,cFirst,vars+1);
            }
		}
	}
	return 0;
}