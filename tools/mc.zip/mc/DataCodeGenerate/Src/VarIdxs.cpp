#include <stdio.h>
#include <string.h>

#define MAX_PATH 260
#define MAX_LEN 2048

int main(int argc, char *argv[])
{
	freopen("in.txt", "r", stdin);
	freopen("VarIdxs.txt", "w", stdout);

	unsigned long index = 0;
	char buf[MAX_LEN];
	while (gets_s(buf) != NULL)
	{
		if (buf[0] == '/')
		{
			continue;
		}

		char * p = buf;
		while (*p == ' ' || *p == 9/*Tab*/)	//clear tab and space
		{
			//putchar(*p);
			p++;
		}
		if (*p == '/' || *p == 0)
			continue;

		char words[MAX_PATH], vars[MAX_PATH];
		sscanf(p, "%s %s", words, vars);

		char * pEquals = strchr(vars, '=');
		if (pEquals != NULL)
		{
			*pEquals = '\0';
		}
		else
		{
			char * pFen = strchr(vars, ';');	// 100%����
			if (pFen != NULL)
			{
				*pFen = '\0';
			}
		}

		// ת��д
		for (int j = 0; vars[j] != '\0'; ++j) {
			if (vars[j] >= 'a' && vars[j] <= 'z') {
				vars[j] = vars[j] - 'a' + 'A';
			}
		}

		printf("%s_INDEX %u\n", vars, index);

		++index;
	}
	return 0;
}