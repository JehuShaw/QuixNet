#include <stdio.h>
#include <string.h>

#define MAX_PATH 260
#define MAX_LEN 2048

int main(int argc, char *argv[])
{
	freopen("in.txt", "r", stdin);
	freopen("Serialize.txt", "w", stdout);
	
	int nCount = 0;
	char buf[MAX_LEN];
	while(gets_s(buf) != NULL)
	{
		if(buf[0] == '/')
		{
			//puts(buf); //����������ע�� 
			continue;
		}
		
		char * p = buf;
		while(*p == ' ' || *p == 9/*Tab*/)	//pass tab and space
		{
			//putchar(*p);	//�����ǰ��Ŀո�Tab�ȵ� 
		 	p++;
		}
		if(*p == '/')
		{
			//puts(p);	//���Ҳ�������ע�� 
			continue;
		}
		else if(*p == 0)
		{
			//puts("");	//����Ҳ������� 
			continue;
		}

		
		char words[MAX_PATH], vars[MAX_PATH];
		sscanf(p, "%s %s", words, vars);
        if(vars[0] >= 'a' && vars[0] <= 'z') {
            vars[0] = vars[0] - 'a' + 'A';				//����ĸ��д
        }
		
		char * pEquals = strchr(vars, '=');
		if(pEquals != NULL)
		{
			*pEquals = '\0';
		}
		else
		{
			char * pFen = strchr(vars, ';');	// 100%����
			if(pFen != NULL)
			{
				*pFen = '\0';
			}
		}

		// ת��д
		char upCaseVar[MAX_PATH] = { '\0' };
		for (int j = 0; vars[j] != '\0'; ++j) {
			if (vars[j] >= 'a' && vars[j] <= 'z') {
				upCaseVar[j] = vars[j] - 'a' + 'A';
			}
			else {
				upCaseVar[j] = vars[j];
			}
		}
		
		if (nCount >= 1)
		{
			printf("\n");
		}
		
		if(strcmp(words, "int32_t")==0 || strcmp(words, "uint32_t") == 0 || strcmp(words, "int64_t") == 0 || strcmp(words, "uint64_t") == 0
			|| strcmp(words, "int8_t")==0 || strcmp(words, "uint8_t") == 0 || strcmp(words, "int16_t") == 0 || strcmp(words, "uint16_t") == 0)
		{
			printf("outStream.Serialize(m_n%s, m_bitSigns.GetBit(%%s_%s_INDEX));", vars, upCaseVar);
		} 
		else if(strcmp(words, "char")==0)
		{
			printf("outStream.Serialize(m_c%s, m_bitSigns.GetBit(%%s_%s_INDEX));", vars, upCaseVar);
		}
		else if(strcmp(words, "bool")==0)
		{
			printf("outStream.Serialize(m_b%s, m_bitSigns.GetBit(%%s_%s_INDEX));", vars, upCaseVar);
		}
		else if(strcmp(words, "string") == 0)
		{			
			printf("outStream.Serialize(m_str%s, m_bitSigns.GetBit(%%s_%s_INDEX));", vars, upCaseVar);
		}
		else if(0 == strcmp(words, "double"))
		{
			printf("outStream.Serialize(m_d%s, m_bitSigns.GetBit(%%s_%s_INDEX));", vars, upCaseVar);
		}
		else if(0 == strcmp(words, "float"))
		{
			printf("outStream.Serialize(m_f%s, m_bitSigns.GetBit(%%s_%s_INDEX));", vars, upCaseVar);
		}
		else
		{
            char cFirst = vars[0];
            if(cFirst != '\0') {
                if(cFirst >= 'A' && cFirst <= 'Z') {
                    //����ĸСд
                    cFirst = cFirst + 'a' - 'A';
                }
			    printf("outStream.Serialize(m_%c%s, m_bitSigns.GetBit(%%s_%s_INDEX));", cFirst, (vars+1), upCaseVar);
            }
		}
		++nCount;
	}
	return 0;
}
