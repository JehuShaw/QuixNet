#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#define MAX_PATH 260
static const int MAX_LEN  = 1024*300;

static inline void EscapeCharacter(char* szBuf){
	long nDestIndex = 0;
	long nSrcIndex = 1;
	while('\0' != szBuf[nDestIndex]) {

		szBuf[nDestIndex] = szBuf[nSrcIndex - 1];

		if('\\' == szBuf[nDestIndex]) {
			if('\0' != szBuf[nSrcIndex]) {
				if('n' == szBuf[nSrcIndex]) {
					szBuf[nDestIndex] = '\n';
					++nDestIndex;
					++nSrcIndex;
					szBuf[nDestIndex] = szBuf[nSrcIndex];
					++nSrcIndex;
					continue;
				} else if('t' == szBuf[nSrcIndex]) {
					szBuf[nDestIndex] = '\t';
					++nDestIndex;
					++nSrcIndex;
					szBuf[nDestIndex] = szBuf[nSrcIndex];
					++nSrcIndex;
					continue;
				} else if('b' == szBuf[nSrcIndex]) {
					szBuf[nDestIndex] = '\b';
					++nDestIndex;
					++nSrcIndex;
					szBuf[nDestIndex] = szBuf[nSrcIndex];
					++nSrcIndex;
					continue;
				} else if('\\' == szBuf[nSrcIndex]) {
					++nDestIndex;
					++nSrcIndex;
					szBuf[nDestIndex] = szBuf[nSrcIndex];
					++nSrcIndex;
					continue;
                }
			}
		}

		++nDestIndex;
		++nSrcIndex;
	}
}

int main(int argc, char *argv[])
{
	printf("Please input the name of the class that begins with C:");
	char szClassName[MAX_PATH];
	if(scanf("%s", szClassName)< 1) {
		printf("\n Error! Must input the name of the class.\n");
		return 0;
	}
	szClassName[MAX_PATH - 1] = '\0';

	printf("Please input the name of the table:");
	char szTableName[MAX_PATH];
	if(scanf("%s", szTableName)< 1) {
		printf("\n Error! Must input the name of the table.\n");
		return 0;
	}
	szTableName[MAX_PATH - 1] = '\0';

    printf("Do you use the PoolBase ? ��Yes: input 'Y' or 'y' ��No:(default) input 'N' or 'n')");
    char szSetPoolBase[2];
    if(scanf("%s", szSetPoolBase)< 1) {
        printf("\n Error! Must input whether use the PoolBase.\n");
        return 0;
    }
	szSetPoolBase[1] = '\0';

	printf("Do you want to Load multiple record ? ��Yes: input 'Y' or 'y' ��No:(default) input 'N' or 'n')");
	char szMultipleRecord[2];
	if(scanf("%s", szMultipleRecord)< 1) {
		printf("\n Error! Must input whether open the multiple record.\n");
		return 0;
	}
	szMultipleRecord[1] = '\0';
	
	char szFileName_h[MAX_PATH], szFileName_cpp[MAX_PATH];
	strcpy(szFileName_h, szClassName+1);
	strcpy(szFileName_cpp, szClassName+1);
	strcat(szFileName_h, ".h");
	strcat(szFileName_cpp, ".cpp");	
	
	char szDefine[MAX_PATH];
	strcpy(szDefine, szClassName+1);
	
	for(int i=strlen(szDefine); i>=0; i--)
	{
		if(szDefine[i] >= 97)
			szDefine[i] = szDefine[i] - 'a' + 'A';
	}	

	FILE * fout_h = fopen(szFileName_h, "w");

	struct tm *t;
	time_t tt;
    time(&tt);
    t=localtime(&tt);
 	fprintf(fout_h, "/*\n\tCode Generate by tool %4d-%02d-%02d %02d:%02d:%02d\n*/\n\n",t->tm_year+1900,t->tm_mon+1,t->tm_mday,t->tm_hour,t->tm_min,t->tm_sec);
	
	fprintf(fout_h, "#ifndef MC_%s_H\n#define MC_%s_H\n\n", szDefine,szDefine);
	bool bPoolBase = ('Y' == szSetPoolBase[0] || 'y' == szSetPoolBase[0]);
    if(bPoolBase) {
	    fprintf(fout_h, "#include \"ICacheValue.h\"\n#include \"SpinRWLock.h\"\n#include \"ScopedRWLock.h\"\n#include \"PoolBase.h\"\n#include \"BitSignSet.h\"\n");
		if('Y' == szMultipleRecord[0] || 'y' == szMultipleRecord[0]) {
			fprintf(fout_h, "#include \"ShareDefines.h\"\n\n");
			fprintf(fout_h, "class CResponseRows;\n\n");
		} else {
			fprintf(fout_h, "\n");
		}
    } else {
        fprintf(fout_h, "#include \"ICacheValue.h\"\n#include \"SpinRWLock.h\"\n#include \"ScopedRWLock.h\"\n#include \"BitSignSet.h\"\n");
		if('Y' == szMultipleRecord[0] || 'y' == szMultipleRecord[0]) {
			fprintf(fout_h, "#include \"ShareDefines.h\"\n\n");
			fprintf(fout_h, "class CResponseRows;\n\n");
		} else {
			fprintf(fout_h, "\n");
		}
    }
	//��������궨���б�
	FILE * fin = fopen("VarIdxs.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: VarIdxs.txt\n");
		fclose(fout_h);
		return -1;
	}
	char szBuf[MAX_LEN] = { '\0' };
	while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{
		fprintf(fout_h, "#define %s_%s", szDefine, szBuf);
	}
	fclose(fin);

	fprintf(fout_h, "\n");

	if (bPoolBase) {
		fprintf(fout_h, "class %s : public ICacheValue, public util::PoolBase<%s>\n", szClassName, szClassName);
	} else {
		fprintf(fout_h, "class %s : public ICacheValue\n", szClassName);
	}

	fprintf(fout_h, "{\n");
	fprintf(fout_h, "public:\n");
	
	//���캯�� 
	fin = fopen("Constructor.txt", "r");
	if(!fin)
	{
		printf("Error! No this file: Constructor.txt\n");
		fclose(fout_h);	
		return -1;
	}
	fprintf(fout_h, "\t%s(void):\n", szClassName);
	unsigned long fieldCount = 0;
	while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
	{
		fprintf(fout_h, "\t\t%s", szBuf);
		++fieldCount;
	}
    fprintf(fout_h, "\t\tm_n64Cas(0),\n"
		"\t\tm_u8ChgType(MCCHANGE_NIL),\n"
		"\t\tm_bitSigns(%u)\n",fieldCount);
	fprintf(fout_h, "\t{}\n\n");
	fclose(fin);

	// ��ؐ���캯��
	fin = fopen("CopyConstructor.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: CopyConstructor.txt\n");
		fclose(fout_h);
		return -1;
	}
	fprintf(fout_h, "\t%s(const %s& orig):\n", szClassName, szClassName);
	while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{
		fprintf(fout_h, "\t\t");
		fprintf(fout_h, szBuf, "orig");
	}
	fprintf(fout_h, "\t\tm_n64Cas(0),\n"
		"\t\tm_u8ChgType(MCCHANGE_NIL),\n"
		"\t\tm_bitSigns(%u)\n", fieldCount);
	fprintf(fout_h, "\t{}\n\n");
	fclose(fin);
	 
	//��������
	fprintf(fout_h, "\t~%s(void) {}\n\n", szClassName);

	// �xֵ������
	fin = fopen("EqualOperator.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: EqualOperator.txt\n");
		fclose(fout_h);
		return -1;
	}
	fprintf(fout_h, "\t%s& operator = (const %s& right) {\n", szClassName, szClassName);
	fprintf(fout_h, "\t\tif (this == &right) {\n\t\t\treturn *this;\n\t\t}\n");
	fprintf(fout_h, "\t\tthd::CScopedReadLock rdLock(right.m_rwTicket);\n");
	fprintf(fout_h, "\t\tthd::CScopedWriteLock wrLock(m_rwTicket);\n");
	while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{
		fprintf(fout_h, "\t\t");
		fprintf(fout_h, szBuf, "right");
	}
	fprintf(fout_h, "\t\treturn *this;\n\t}\n\n\n");
	fclose(fin);
	
	//Get & Set
 	fin = fopen("Get.txt", "r");
 	if(!fin)
	{
		printf("Error! No this file: Get.txt\n");
		fclose(fout_h);
		return -1;
	}
 	while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
	{
		EscapeCharacter(szBuf);
		fprintf(fout_h, "%s\n", szBuf);
	}
	fclose(fin);
    fprintf(fout_h, "\tuint64_t GetCas() const {\n"
		"\t\tthd::CScopedReadLock rdLock(m_rwTicket);\n"
		"\t\treturn m_n64Cas;\n"
	"\t}\n\n");

		
	fin  = fopen("Set.txt", "r");
	if(!fin)
	{
		printf("Error! No this file: Set.txt\n");
		fclose(fout_h);
		return -1;
	}
 	while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
	{
		EscapeCharacter(szBuf);
		fprintf(fout_h, szBuf, szDefine);
		fprintf(fout_h, "\n");
	}
	fclose(fin);
	fprintf(fout_h, "\tvoid SetCas(uint64_t n64Cas) {\n"
		"\t\tthd::CScopedWriteLock wrLock(m_rwTicket);\n"
		"\t\tm_n64Cas = n64Cas;\n"
	"\t}\n\n");

	if('Y' == szMultipleRecord[0] || 'y' == szMultipleRecord[0]) {
		fprintf(fout_h, "\tstatic MCResult LoadAllRecord("
			"\n\t\tCResponseRows& outRecords,"
			"\n\t\teRouteType routeType,"
			"\n\t\tuint64_t u64Route,"
			"\n\t\tconst util::CValueStream& strKeys,"
			"\n\t\tuint32_t nCount = 0,"
			"\n\t\tuint32_t nOffset = 0);\n\n");
	}
	// 
	fprintf(fout_h, "\tMCResult AddToCache(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
	//
	fprintf(fout_h, "\tMCResult LoadFromCache(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
    //
    fprintf(fout_h, "\tMCResult StoreToCache(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
	//
	fprintf(fout_h, "\tMCResult ReadOnlyFromCache(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
    //
    fprintf(fout_h, "\tMCResult GetsFromCache(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
	// 
	fprintf(fout_h, "\tMCResult CasToCache(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
	//
	fprintf(fout_h, "\tMCResult DelFromCache(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");

	if('Y' == szMultipleRecord[0] || 'y' == szMultipleRecord[0]) {
		fprintf(fout_h, "\tstatic MCResult SelectAllRecord("
			"\n\t\tCResponseRows& outRecords,"
			"\n\t\teRouteType routeType,"
			"\n\t\tuint64_t u64Route,"
			"\n\t\tconst util::CValueStream& strKeys,"
			"\n\t\tuint32_t nCount = 0,"
			"\n\t\tuint32_t nOffset = 0);\n\n");
	}
    //
    fprintf(fout_h, "\tMCResult InsertToDB(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
    //
    fprintf(fout_h, "\tMCResult SelectFromDB(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
    //
    fprintf(fout_h, "\tMCResult UpdateToDB(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
    //
    fprintf(fout_h, "\tMCResult DeleteFromDB(uint64_t u64Route, const util::CValueStream& strKeys);\n\n");
	//
	fprintf(fout_h, "\tuint8_t ChangeType() const { return m_u8ChgType; }\n\n");
	//
	fprintf(fout_h, "\tvoid RecoverChgType(const util::BitSignSet& inBitSigns, uint8_t oldChgType);\n\n");
	// 
	fprintf(fout_h, "\tconst char* GetCacheKeyName() const;\n\n");
	//
	fprintf(fout_h, "\tuint64_t ObjectId() const { return (uint64_t)this; }\n\n");
	//Serialize()����
	fprintf(fout_h, "\tvoid Serialize(util::CTransferStream& outStream, util::BitSignSet& outBitSigns, uint8_t& outChgType);\n\n");
	// Parse()
    fprintf(fout_h, "\tvoid Parse(const std::string& inArray, uint64_t n64Cas);\n\n");
	//
	fprintf(fout_h, "\tvoid Parse(const std::string& inArray);\n\n");
	
	//�����б�
	fprintf(fout_h, "protected:\n");
	fin = fopen("Vars.txt", "r");
	if(!fin)
	{
		printf("Error! No this file: vars.txt\n");
		fclose(fout_h);
		return -1;
	}
 	while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
	{
		fprintf(fout_h, "\t%s", szBuf);
	}
	fclose(fin);

	fprintf(fout_h, "\t// The cache check and set flag.\n"
		"\tuint64_t m_n64Cas;\n\n");

    fprintf(fout_h,
		"protected:\n"
		"\tvolatile uint8_t m_u8ChgType;\n"
		"\tutil::BitSignSet m_bitSigns;\n"
		"\tthd::CSpinRWLock m_rwTicket;\n");

	fprintf(fout_h, "};\n\n#endif /* MC_%s_H */\n", szDefine);
	fclose(fout_h);
	
	///////////////////////////////CPP//////////////////////////////////////
	FILE * fout_cpp = fopen(szFileName_cpp, "w");	
	fprintf(fout_cpp, "#include \"%s\"\n", szFileName_h);
	fprintf(fout_cpp, "#include \"CacheOperateHelper.h\"\n");
	fprintf(fout_cpp, "#include \"Log.h\"\n");
	fprintf(fout_cpp, "#include \"TransferStream.h\"\n");
	fprintf(fout_cpp, "#include \"ValueStream.h\"\n\n");

	fprintf(fout_cpp, "#define CACHE_KEY_NAME \"%s\"\n\n\n", szTableName);

	if('Y' == szMultipleRecord[0] || 'y' == szMultipleRecord[0]) {
		fprintf(fout_cpp,"MCResult %s::LoadAllRecord("
			"\n\tCResponseRows& outRecords,"
			"\n\teRouteType routeType,"
			"\n\tuint64_t u64Route,"
			"\n\tconst util::CValueStream& strKeys,"
			"\n\tuint32_t nCount/* = 0*/,"
			"\n\tuint32_t nOffset/* = 0*/)\n"
		"{\n"
			"\tCRequestMultiRows cacheRequest;\n"
			"\tutil::CValueStream tsTableKey;\n"
			"\ttsTableKey.Serialize(CACHE_KEY_NAME);\n"
			"\tif(strKeys.GetLength() > 0) {\n"
			"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
			"\t}\n"
			"\tcacheRequest.SetKey(tsTableKey);\n"
			"\tif(nCount > 0) {\n"
				"\t\tcacheRequest.SetCount(nCount);\n"
				"\t\tcacheRequest.SetOffset(nOffset);\n"
			"\t}\n"
			"\tMcLoadAll(routeType, u64Route, cacheRequest, outRecords);\n\n"

			"\treturn outRecords.GetFirstRecordResult();\n"
		"}\n\n", szClassName);
	}

	fprintf(fout_cpp, "MCResult %s::AddToCache(uint64_t u64Route, const util::CValueStream& strKeys)\n"
	"{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
		"\treturn McAddOneRecord(u64Route, tsTableKey, *this);\n"
	"}\n\n",szClassName);

	fprintf(fout_cpp, "MCResult %s::LoadFromCache(uint64_t u64Route, const util::CValueStream& strKeys)\n"
	"{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
		"\treturn McLoadOneRecord(u64Route, tsTableKey, *this);\n"
	"}\n\n",szClassName);

    fprintf(fout_cpp, "MCResult %s::StoreToCache(uint64_t u64Route, const util::CValueStream& strKeys)\n"
    "{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
        "\treturn McStoreOneRecord(u64Route, tsTableKey, *this);\n"
    "}\n\n",szClassName);

	fprintf(fout_cpp, "MCResult %s::ReadOnlyFromCache(uint64_t u64Route, const util::CValueStream& strKeys)\n"
		"{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
		"\treturn McReadOnlyOneRecord(u64Route, tsTableKey, *this);\n"
	"}\n\n", szClassName);

    fprintf(fout_cpp, "MCResult %s::GetsFromCache(uint64_t u64Route, const util::CValueStream& strKeys)\n"
    "{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
        "\treturn McGetsOneRecord(u64Route, tsTableKey, *this);\n"
    "}\n\n",szClassName);

	fprintf(fout_cpp, "MCResult %s::CasToCache(uint64_t u64Route, const util::CValueStream& strKeys)\n"
	"{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
		"\treturn McCasOneRecord(u64Route, tsTableKey, *this);\n"
	"}\n\n",szClassName);

	fprintf(fout_cpp, "MCResult %s::DelFromCache(uint64_t u64Route, const util::CValueStream& strKeys)\n"
	"{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
        "\tMCResult nResult = McDelOneRecord(u64Route, tsTableKey);\n"
		"\tif(MCERR_OK == nResult) {\n"
			"\t\tatomic_xchg8(&m_u8ChgType, MCCHANGE_NIL);\n"
		"\t}\n"
		"\treturn nResult;\n"
	"}\n\n",szClassName);

	if('Y' == szMultipleRecord[0] || 'y' == szMultipleRecord[0]) {
		fprintf(fout_cpp,"MCResult %s::SelectAllRecord("
			"\n\tCResponseRows& outRecords,"
			"\n\teRouteType routeType,"
			"\n\tuint64_t u64Route," 
			"\n\tconst util::CValueStream& strKeys,"
			"\n\tuint32_t nCount/* = 0*/,"
			"\n\tuint32_t nOffset/* = 0*/)\n"
			"{\n"
			"\tCRequestMultiRows cacheRequest;\n"
			"\tutil::CValueStream tsTableKey;\n"
			"\ttsTableKey.Serialize(CACHE_KEY_NAME);\n"
			"\tif(strKeys.GetLength() > 0) {\n"
			"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
			"\t}\n"
			"\tcacheRequest.SetKey(tsTableKey);\n"
			"\tif(nCount > 0) {\n"
			"\t\tcacheRequest.SetCount(nCount);\n"
			"\t\tcacheRequest.SetOffset(nOffset);\n"
			"\t}\n"
			"\tMcDBSelectAll(routeType, u64Route, cacheRequest, outRecords);\n\n"

			"\treturn outRecords.GetFirstRecordResult();\n"
			"}\n\n", szClassName);
	}

    fprintf(fout_cpp, "MCResult %s::InsertToDB(uint64_t u64Route, const util::CValueStream& strKeys)\n"
    "{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
        "\treturn McInsertOneRecordToDB(u64Route, tsTableKey, *this);\n"
    "}\n\n",szClassName);

    fprintf(fout_cpp, "MCResult %s::SelectFromDB(uint64_t u64Route, const util::CValueStream& strKeys)\n"
    "{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
        "\treturn McSelectOneRecordFromDB(u64Route, tsTableKey, *this);\n"
    "}\n\n",szClassName);

    fprintf(fout_cpp, "MCResult %s::UpdateToDB(uint64_t u64Route, const util::CValueStream& strKeys)\n"
    "{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
        "\treturn McUpdateOneRecordToDB(u64Route, tsTableKey, *this);\n"
    "}\n\n",szClassName);

    fprintf(fout_cpp, "MCResult %s::DeleteFromDB(uint64_t u64Route, const util::CValueStream& strKeys)\n"
    "{\n"
		"\tutil::CTransferStream tsTableKey;\n"
		"\ttsTableKey.Serialize(CACHE_KEY_NAME, true);\n"
		"\tif(strKeys.GetLength() > 0) {\n"
		"\t\ttsTableKey.WriteBytes(strKeys.GetData(), strKeys.GetLength());\n"
		"\t}\n"
        "\treturn McDeleteOneRecordFromDB(u64Route, tsTableKey);\n"
    "}\n\n",szClassName);

	fprintf(fout_cpp, "void %s::RecoverChgType(const util::BitSignSet& inBitSigns, uint8_t oldChgType)\n"
		"{\n"
		"\tthd::CScopedWriteLock wrLock(m_rwTicket);\n"
		"\tm_bitSigns = inBitSigns;\n"
		"\tif(MCCHANGE_UPDATE == oldChgType) {\n"
		"\t\tatomic_xchg8(&m_u8ChgType, oldChgType);\n"
		"\t}\n"
		"}\n\n",szClassName);

	fprintf(fout_cpp, "const char* %s::GetCacheKeyName() const\n"
		"{\n"
		"\treturn CACHE_KEY_NAME;\n"
		"}\n\n", szClassName);
	
	fprintf(fout_cpp, "void %s::Serialize(util::CTransferStream& outStream, util::BitSignSet& outBitSigns, uint8_t& outChgType)\n", szClassName);
	fprintf(fout_cpp, "{\n");
	fin = fopen("Serialize.txt", "r");
	if(!fin)
	{
		printf("Error! No this file: Serialize.txt\n");
		fclose(fout_cpp);
		return -1;
	}
    if(fgets(szBuf, MAX_LEN-1, fin) != NULL) {
        fprintf(fout_cpp, "\tthd::CScopedReadLock rdLock(m_rwTicket);\n\n");
		fprintf(fout_cpp, "\t");
        fprintf(fout_cpp, szBuf, szDefine);
        while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
        {
			fprintf(fout_cpp, "\t");
			fprintf(fout_cpp, szBuf, szDefine);
        }
		fprintf(fout_cpp, "\n\n");
    }
	fprintf(fout_cpp, "\toutBitSigns = m_bitSigns;\n\tm_bitSigns.ResetBitSet();\n");
	fprintf(fout_cpp, "\toutChgType = atomic_xchg8(&m_u8ChgType, MCCHANGE_NIL);\n");
	fprintf(fout_cpp, "}\n");
	fclose(fin);

	fprintf(fout_cpp, "\nvoid %s::Parse(const std::string& inArray, uint64_t n64Cas)\n", szClassName);
	fprintf(fout_cpp, "{\n\tthd::CScopedWriteLock wrLock(m_rwTicket);\n\n");
	fin = fopen("Parse.txt", "r");
	if(!fin)
	{
		printf("Error! No this file: Parse.txt\n");
		fclose(fout_cpp);
		return -1;
	}
    if(fgets(szBuf, MAX_LEN-1, fin) != NULL)
    { // first get
        fprintf(fout_cpp,"\tutil::CTransferStream stream(inArray, false);\n");
        fprintf(fout_cpp, "\t%s", szBuf);
        while(fgets(szBuf, MAX_LEN-1, fin) != NULL)
        {
            fprintf(fout_cpp, "\t%s", szBuf);
        }
        fprintf(fout_cpp,"\n\n");
    }
    fprintf(fout_cpp, "\tm_n64Cas = n64Cas;\n");
	fprintf(fout_cpp, "\tatomic_xchg8(&m_u8ChgType, MCCHANGE_NIL);\n");
	fprintf(fout_cpp, "\tm_bitSigns.ResetBitSet();\n");
	fprintf(fout_cpp, "}\n");
	fclose(fin);

	fprintf(fout_cpp, "\nvoid %s::Parse(const std::string& inArray)\n", szClassName);
	fprintf(fout_cpp, "{\n\tthd::CScopedWriteLock wrLock(m_rwTicket);\n\n");
	fin = fopen("Parse.txt", "r");
	if (!fin)
	{
		printf("Error! No this file: Parse.txt\n");
		fclose(fout_cpp);
		return -1;
	}
	if (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
	{ // first get
		fprintf(fout_cpp, "\tutil::CTransferStream stream(inArray, false);\n");
		fprintf(fout_cpp, "\t%s", szBuf);
		while (fgets(szBuf, MAX_LEN - 1, fin) != NULL)
		{
			fprintf(fout_cpp, "\t%s", szBuf);
		}
		fprintf(fout_cpp, "\n\n");
	}
	fprintf(fout_cpp, "\tatomic_xchg8(&m_u8ChgType, MCCHANGE_NIL);\n");
	fprintf(fout_cpp, "\tm_bitSigns.ResetBitSet();\n");
	fprintf(fout_cpp, "}\n\n\n");
	fclose(fin);
	

	fclose(fout_cpp);
	return 0;
}


