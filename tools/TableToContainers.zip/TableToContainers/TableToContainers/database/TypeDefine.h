/* 
 * File:   TypeDefine.h
 * Author: Jehu Shaw
 *
 * Created on 2011_7_20, 18:23
 */

#ifndef TYPEDEFINE_H
#define	TYPEDEFINE_H

#include "Common.h"

class IWrapper{
public:
    virtual bool getUpdate() = 0;
    virtual void setUpdate(bool val) = 0;
    virtual bool getSelect() = 0;
    virtual void setSelect(bool val) = 0;
};


class wstring_bs_t:public IWrapper {
public:
    wstring_bs_t(){}
    wstring_bs_t(const wstring_bs_t& w):var(w.var){}
    
    const std::wstring& operator()(){return var;}

    void operator()(const std::wstring& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const std::wstring& val){}
    
protected:
    std::wstring var;
};

class wstring_fd_t:public wstring_bs_t{
public:
    friend class ITableDescriptor;
    wstring_fd_t():bUpdated(false),bSelected(false){}
    wstring_fd_t(const wstring_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    wstring_fd_t& operator=(const std::wstring& v){
        setVar(v);
        return *this;
    }
    
    wstring_fd_t& operator=(const wstring_fd_t& w){
        setVar(w.var);
        return *this;
    }

    wstring_fd_t& operator+=(const std::wstring& v){
        addVar(v);
        return *this;
    }
    
    wstring_fd_t& operator+=(const wstring_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const std::wstring& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const std::wstring& val){
        bUpdated = false;
    }
    
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const std::wstring& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const std::wstring& v){
        var += v;
        bUpdated = true;
    }
};

class wstring_ky_t:public wstring_fd_t {
public:
    wstring_ky_t():wstring_fd_t(){}
    wstring_ky_t(const wstring_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    wstring_ky_t& operator=(const std::wstring& v){
        setVar(v);
        return *this;
    }
    
    wstring_ky_t& operator=(const wstring_ky_t& w){
        setVar(w.var);
        return *this;
    }

    wstring_ky_t& operator+=(const std::wstring& v){
        addVar(v);
        return *this;
    }
    
    wstring_ky_t& operator+=(const wstring_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const std::wstring& getOldValue(){
        return oldVar;
    }
    
    virtual void resetUpdate(const std::wstring& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    std::wstring oldVar;
};

class string_bs_t:public IWrapper {
public:
    string_bs_t(){}
    string_bs_t(const string_bs_t& w):var(w.var){}
    
    const std::string& operator()(){return var;}

    void operator()(const std::string& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const std::string& val){}
protected:
    std::string var;
};

class string_fd_t:public string_bs_t {
public:
    friend class ITableDescriptor;
    string_fd_t():bUpdated(false),bSelected(false){}
    string_fd_t(const string_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    string_fd_t& operator=(const std::string& v){
        setVar(v);
        return *this;
    }
    
    string_fd_t& operator=(const string_fd_t& w){
        setVar(w.var);
        return *this;
    }

    string_fd_t& operator+=(const std::string& v){
        addVar(v);
        return *this;
    }
    
    string_fd_t& operator+=(const string_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const std::string& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const std::string& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const std::string& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const std::string& v){
        var += v;
        bUpdated = true;
    }
};

class string_ky_t:public string_fd_t {
public:
    string_ky_t():string_fd_t(){}
    string_ky_t(const string_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    string_ky_t& operator=(const std::string& v){
        setVar(v);
        return *this;
    }
    
    string_ky_t& operator=(const string_ky_t& w){
        setVar(w.var);
        return *this;
    }

    string_ky_t& operator+=(const std::string& v){
        addVar(v);
        return *this;
    }
    
    string_ky_t& operator+=(const string_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const std::string& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const std::string& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    std::string oldVar;
};

class double_bs_t:public IWrapper {
public:
    double_bs_t(){}
    double_bs_t(const double_bs_t& w):var(w.var){}
    
    const double& operator()(){return var;}

    void operator()(const double& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const double& val){}
protected:
    double var;
};

class double_fd_t:public double_bs_t {
public:
    friend class ITableDescriptor;
    double_fd_t():bUpdated(false),bSelected(false){}
    double_fd_t(const double_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    double_fd_t& operator=(const double& v){
        setVar(v);
        return *this;
    }
    
    double_fd_t& operator=(const double_fd_t& w){
        setVar(w.var);
        return *this;
    }

    double_fd_t& operator+=(const double& v){
        addVar(v);
        return *this;
    }
    
    double_fd_t& operator+=(const double_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const double& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const double& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const double& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const double& v){
        var += v;
        bUpdated = true;
    }
};

class double_ky_t:public double_fd_t {
public:
    double_ky_t():double_fd_t(){}
    double_ky_t(const double_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    double_ky_t& operator=(const double& v){
        setVar(v);
        return *this;
    }
    
    double_ky_t& operator=(const double_ky_t& w){
        setVar(w.var);
        return *this;
    }

    double_ky_t& operator+=(const double& v){
        addVar(v);
        return *this;
    }
    
    double_ky_t& operator+=(const double_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const double& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const double& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    double oldVar;
};

class float_bs_t:public IWrapper {
public:
    float_bs_t(){}
    float_bs_t(const float_bs_t& w):var(w.var){}
    
    const float& operator()(){return var;}

    void operator()(const float& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const float& val){}
protected:
    float var;
};

class float_fd_t:public float_bs_t {
public:
    friend class ITableDescriptor;
    float_fd_t():bUpdated(false),bSelected(false){}
    float_fd_t(const float_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    float_fd_t& operator=(const float& v){
        setVar(v);
        return *this;
    }
    
    float_fd_t& operator=(const float_fd_t& w){
        setVar(w.var);
        return *this;
    }

    float_fd_t& operator+=(const float& v){
        addVar(v);
        return *this;
    }
    
    float_fd_t& operator+=(const float_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const float& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const float& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const float& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const float& v){
        var += v;
        bUpdated = true;
    }
};

class float_ky_t:public float_fd_t {
public:
    float_ky_t():float_fd_t(){}
    float_ky_t(const float_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    float_ky_t& operator=(const float& v){
        setVar(v);
        return *this;
    }
    
    float_ky_t& operator=(const float_ky_t& w){
        setVar(w.var);
        return *this;
    }

    float_ky_t& operator+=(const float& v){
        addVar(v);
        return *this;
    }
    
    float_ky_t& operator+=(const float_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const float& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const float& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    float oldVar;
};

class uint64_bs_t:public IWrapper {
public:
    uint64_bs_t(){}
    uint64_bs_t(const uint64_bs_t& w):var(w.var){}
    
    const uint64& operator()(){return var;}

    void operator()(const uint64& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const uint64& val){}
protected:
    uint64 var;
};

class uint64_fd_t:public uint64_bs_t {
public:
    friend class ITableDescriptor;
    uint64_fd_t():bUpdated(false),bSelected(false){}
    uint64_fd_t(const uint64_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    uint64_fd_t& operator=(const uint64& v){
        setVar(v);
        return *this;
    }
    
    uint64_fd_t& operator=(const uint64_fd_t& w){
        setVar(w.var);
        return *this;
    }

    uint64_fd_t& operator+=(const uint64& v){
        addVar(v);
        return *this;
    }
    
    uint64_fd_t& operator+=(const uint64_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const uint64& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const uint64& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const uint64& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const uint64& v){
        var += v;
        bUpdated = true;
    }
};

class uint64_ky_t:public uint64_fd_t {
public:
    uint64_ky_t():uint64_fd_t(){}
    uint64_ky_t(const uint64_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    uint64_ky_t& operator=(const uint64_t& v){
        setVar(v);
        return *this;
    }
    
    uint64_ky_t& operator=(const uint64_ky_t& w){
        setVar(w.var);
        return *this;
    }

    uint64_ky_t& operator+=(const uint64_t& v){
        addVar(v);
        return *this;
    }
    
    uint64_ky_t& operator+=(const uint64_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const uint64_t& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const uint64_t& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    uint64_t oldVar;
};

class uint32_bs_t:public IWrapper {
public:
    uint32_bs_t(){}
    uint32_bs_t(const uint32_bs_t& w):var(w.var){}
    
    const uint32_t& operator()(){return var;}

    void operator()(const uint32_t& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const uint32_t& val){}
protected:
    uint32_t var;
};

class uint32_fd_t:public uint32_bs_t {
public:
    friend class ITableDescriptor;
    uint32_fd_t():bUpdated(false),bSelected(false){}
    uint32_fd_t(const uint32_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    uint32_fd_t& operator=(const uint32_t& v){
        setVar(v);
        return *this;
    }
    
    uint32_fd_t& operator=(const uint32_fd_t& w){
        setVar(w.var);
        return *this;
    }

    uint32_fd_t& operator+=(const uint32_t& v){
        addVar(v);
        return *this;
    }
    
    uint32_fd_t& operator+=(const uint32_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const uint32_t& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const uint32_t& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const uint32_t& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const uint32_t& v){
        var += v;
        bUpdated = true;
    }
};

class uint32_ky_t:public uint32_fd_t {
public:
    uint32_ky_t():uint32_fd_t(){}
    uint32_ky_t(const uint32_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    uint32_ky_t& operator=(const uint32_t& v){
        setVar(v);
        return *this;
    }
    
    uint32_ky_t& operator=(const uint32_ky_t& w){
        setVar(w.var);
        return *this;
    }

    uint32_ky_t& operator+=(const uint32_t& v){
        addVar(v);
        return *this;
    }
    
    uint32_ky_t& operator+=(const uint32_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const uint32_t& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const uint32_t& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    uint32_t oldVar;
};

class uint16_bs_t:public IWrapper {
public:
    uint16_bs_t(){}
    uint16_bs_t(const uint16_bs_t& w):var(w.var){}
    
    const uint16_t& operator()(){return var;}

    void operator()(const uint16_t& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const uint16_t& val){}
protected:
    uint16_t var;
};

class uint16_fd_t:public uint16_bs_t {
public:
    friend class ITableDescriptor;
    uint16_fd_t():bUpdated(false),bSelected(false){}
    uint16_fd_t(const uint16_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    uint16_fd_t& operator=(const uint16_t& v){
        setVar(v);
        return *this;
    }
    
    uint16_fd_t& operator=(const uint16_fd_t& w){
        setVar(w.var);
        return *this;
    }

    uint16_fd_t& operator+=(const uint16_t& v){
        addVar(v);
        return *this;
    }
    
    uint16_fd_t& operator+=(const uint16_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const uint16_t& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const uint16_t& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const uint16_t& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const uint16_t& v){
        var += v;
        bUpdated = true;
    }
};

class uint16_ky_t:public uint16_fd_t {
public:
    uint16_ky_t():uint16_fd_t(){}
    uint16_ky_t(const uint16_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    uint16_ky_t& operator=(const uint16_t& v){
        setVar(v);
        return *this;
    }
    
    uint16_ky_t& operator=(const uint16_ky_t& w){
        setVar(w.var);
        return *this;
    }

    uint16_ky_t& operator+=(const uint16_t& v){
        addVar(v);
        return *this;
    }
    
    uint16_ky_t& operator+=(const uint16_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const uint16_t& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const uint16_t& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    uint16_t oldVar;
};

class uint8_bs_t:public IWrapper {
public:
    uint8_bs_t(){}
    uint8_bs_t(const uint8_bs_t& w):var(w.var){}
    
    const uint8_t& operator()(){return var;}

    void operator()(const uint8_t& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const uint8_t& val){}
protected:
    uint8_t var;
};

class uint8_fd_t:public uint8_bs_t {
public:
    friend class ITableDescriptor;
    uint8_fd_t():bUpdated(false),bSelected(false){}
    uint8_fd_t(const uint8_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    uint8_fd_t& operator=(const uint8_t& v){
        setVar(v);
        return *this;
    }
    
    uint8_fd_t& operator=(const uint8_fd_t& w){
        setVar(w.var);
        return *this;
    }

    uint8_fd_t& operator+=(const uint8_t& v){
        addVar(v);
        return *this;
    }
    
    uint8_fd_t& operator+=(const uint8_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const uint8_t& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const uint8_t& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const uint8_t& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const uint8_t& v){
        var += v;
        bUpdated = true;
    }
};

class uint8_ky_t:public uint8_fd_t {
public:
    uint8_ky_t():uint8_fd_t(){}
    uint8_ky_t(const uint8_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    uint8_ky_t& operator=(const uint8_t& v){
        setVar(v);
        return *this;
    }
    
    uint8_ky_t& operator=(const uint8_ky_t& w){
        setVar(w.var);
        return *this;
    }

    uint8_ky_t& operator+=(const uint8_t& v){
        addVar(v);
        return *this;
    }
    
    uint8_ky_t& operator+=(const uint8_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const uint8_t& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const uint8_t& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    uint8_t oldVar;
};

class int64_bs_t:public IWrapper {
public:
    int64_bs_t(){}
    int64_bs_t(const int64_bs_t& w):var(w.var){}
    
    const int64_t& operator()(){return var;}

    void operator()(const int64_t& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const int64_t& val){}
protected:
    int64_t var;
};

class int64_fd_t:public int64_bs_t {
public:
    friend class ITableDescriptor;
    int64_fd_t():bUpdated(false),bSelected(false){}
    int64_fd_t(const int64_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    int64_fd_t& operator=(const int64_t& v){
        setVar(v);
        return *this;
    }
    
    int64_fd_t& operator=(const int64_fd_t& w){
        setVar(w.var);
        return *this;
    }

    int64_fd_t& operator+=(const int64_t& v){
        addVar(v);
        return *this;
    }
    
    int64_fd_t& operator+=(const int64_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const int64_t& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const int64_t& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const int64_t& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const int64_t& v){
        var += v;
        bUpdated = true;
    }
};

class int64_ky_t:public int64_fd_t {
public:
    int64_ky_t():int64_fd_t(){}
    int64_ky_t(const int64_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    int64_ky_t& operator=(const int64_t& v){
        setVar(v);
        return *this;
    }
    
    int64_ky_t& operator=(const int64_ky_t& w){
        setVar(w.var);
        return *this;
    }

    int64_ky_t& operator+=(const int64_t& v){
        addVar(v);
        return *this;
    }
    
    int64_ky_t& operator+=(const int64_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const int64_t& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const int64_t& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    int64_t oldVar;
};

class int32_bs_t:public IWrapper {
public:
    int32_bs_t(){}
    int32_bs_t(const int32_bs_t& w):var(w.var){}
    
    const int32_t& operator()(){return var;}

    void operator()(const int32_t& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const int32_t& val){}
protected:
    int32_t var;
};

class int32_fd_t:public int32_bs_t {
public:
    friend class ITableDescriptor;
    int32_fd_t():bUpdated(false),bSelected(false){}
    int32_fd_t(const int32_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    int32_fd_t& operator=(const int32_t& v){
        setVar(v);
        return *this;
    }
    
    int32_fd_t& operator=(const int32_fd_t& w){
        setVar(w.var);
        return *this;
    }

    int32_fd_t& operator+=(const int32_t& v){
        addVar(v);
        return *this;
    }
    
    int32_fd_t& operator+=(const int32_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const int32_t& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const int32_t& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const int32_t& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const int32_t& v){
        var += v;
        bUpdated = true;
    }
};

class int32_ky_t:public int32_fd_t {
public:
    int32_ky_t():int32_fd_t(){}
    int32_ky_t(const int32_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    int32_ky_t& operator=(const int32_t& v){
        setVar(v);
        return *this;
    }
    
    int32_ky_t& operator=(const int32_ky_t& w){
        setVar(w.var);
        return *this;
    }

    int32_ky_t& operator+=(const int32_t& v){
        addVar(v);
        return *this;
    }
    
    int32_ky_t& operator+=(const int32_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const int32_t& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const int32_t& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    int32_t oldVar;
};

class int16_bs_t:public IWrapper {
public:
    int16_bs_t(){}
    int16_bs_t(const int16_bs_t& w):var(w.var){}
    
    const int16_t& operator()(){return var;}

    void operator()(const int16_t& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const int16_t& val){}
protected:
    int16_t var;
};

class int16_fd_t:public int16_bs_t {
public:
    friend class ITableDescriptor;
    int16_fd_t():bUpdated(false),bSelected(false){}
    int16_fd_t(const int16_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    int16_fd_t& operator=(const int16_t& v){
        setVar(v);
        return *this;
    }
    
    int16_fd_t& operator=(const int16_fd_t& w){
        setVar(w.var);
        return *this;
    }

    int16_fd_t& operator+=(const int16_t& v){
        addVar(v);
        return *this;
    }
    
    int16_fd_t& operator+=(const int16_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const int16_t& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const int16_t& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const int16_t& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const int16_t& v){
        var += v;
        bUpdated = true;
    }
};

class int16_ky_t:public int16_fd_t {
public:
    int16_ky_t():int16_fd_t(){}
    int16_ky_t(const int16_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    int16_ky_t& operator=(const int16_t& v){
        setVar(v);
        return *this;
    }
    
    int16_ky_t& operator=(const int16_ky_t& w){
        setVar(w.var);
        return *this;
    }

    int16_ky_t& operator+=(const int16_t& v){
        addVar(v);
        return *this;
    }
    
    int16_ky_t& operator+=(const int16_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const int16_t& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const int16_t& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    int16_t oldVar;
};

class int8_bs_t:public IWrapper {
public:
    int8_bs_t(){}
    int8_bs_t(const int8_bs_t& w):var(w.var){}
    
    const int8_t& operator()(){return var;}

    void operator()(const int8_t& v){
        var = v;
        resetUpdate(var);
    }
    
    virtual bool getUpdate(){return false;}
    
    virtual void setUpdate(bool val){}
    
    virtual bool getSelect(){return false;}
    
    virtual void setSelect(bool val){}
    
    virtual void resetUpdate(const int8_t& val){}
protected:
    int8_t var;
};

class int8_fd_t:public int8_bs_t {
public:
    friend class ITableDescriptor;
    int8_fd_t():bUpdated(false),bSelected(false){}
    int8_fd_t(const int8_fd_t& w):bUpdated(w.bUpdated),bSelected(w.bSelected){var = w.var;}

    int8_fd_t& operator=(const int8_t& v){
        setVar(v);
        return *this;
    }
    
    int8_fd_t& operator=(const int8_fd_t& w){
        setVar(w.var);
        return *this;
    }

    int8_fd_t& operator+=(const int8_t& v){
        addVar(v);
        return *this;
    }
    
    int8_fd_t& operator+=(const int8_fd_t& w){
        addVar(w.var);
        return *this;
    }

    bool getUpdate(){
        return bUpdated;
    }
    
    void setUpdate(bool val){
        bUpdated = val;
    }
    
    bool getSelect(){
        return bSelected;
    }
    
    void setSelect(bool val){
        bSelected = val;
    }
    
    virtual const int8_t& getOldValue(){
        return var;
    }
    
    virtual void resetUpdate(const int8_t& val){
        bUpdated = false;
    }
protected:
    bool bUpdated;
    bool bSelected;
    
    void setVar(const int8_t& v){
        if(var != v){
            var = v;
            bUpdated = true;
        }
    }
    
    void addVar(const int8_t& v){
        var += v;
        bUpdated = true;
    }
};

class int8_ky_t:public int8_fd_t {
public:
    int8_ky_t():int8_fd_t(){}
    int8_ky_t(const int8_ky_t& w):oldVar(w.oldVar){
        var= w.var;
        bUpdated = w.bUpdated;
        bSelected = w.bSelected;
    }
    
    int8_ky_t& operator=(const int8_t& v){
        setVar(v);
        return *this;
    }
    
    int8_ky_t& operator=(const int8_ky_t& w){
        setVar(w.var);
        return *this;
    }

    int8_ky_t& operator+=(const int8_t& v){
        addVar(v);
        return *this;
    }
    
    int8_ky_t& operator+=(const int8_ky_t& w){
        addVar(w.var);
        return *this;
    }
    
    virtual const int8_t& getOldValue(){
        return oldVar;
    }

    virtual void resetUpdate(const int8_t& val){
        oldVar = val;
        bUpdated = false;
    }
protected:
    int8_t oldVar;
};

#endif	/* TYPEDEFINE_H */

