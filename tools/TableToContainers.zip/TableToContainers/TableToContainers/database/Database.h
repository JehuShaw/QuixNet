/*
 * File:   Database.h
 * Author: Jehu Shaw
 *
 */

#ifndef _DATABASE_H
#define _DATABASE_H

#include <string>
#include "CircleQueue.h"
#include "CallBackDB.h"
#include "CThreads.h"
#include "AutoPointer.h"
#include "Field.h"

namespace db {

using namespace std;
class QueryResult;
//class QueryThread;
class Database;

#define QUERY_RESULT_DEFAULT_FIELD_SIZE 32
#define QUERY_STRING_DEFAULT_SIZE 256

struct DatabaseConnection
{
	virtual ~DatabaseConnection() {}
	thd::CMutex Busy;
};

class QueryStrBuffer
{
public:
	QueryStrBuffer() {
		m_query = m_defBuf;
	}
	~QueryStrBuffer() {
		Clear();
	}
	QueryStrBuffer(const QueryStrBuffer& orig) {
		int nSize = (int)strlen(orig.m_query) + 1;
		if(nSize > QUERY_STRING_DEFAULT_SIZE) {
			m_query = new char[nSize];
		} else {
			m_query = m_defBuf;
		}
		memcpy(m_query, orig.m_query, nSize);
	}

	INLINE void Clear() {
		if(m_defBuf != m_query) {
			delete [] m_query;
			m_query = m_defBuf;
		}
	}

	char* SetQueryStr(int size) {
		Clear();
		if(size > QUERY_STRING_DEFAULT_SIZE) {
			m_query = new char[size];
		} else {
			m_query = m_defBuf;
		}
		return m_query;
	}

	INLINE const char* GetQueryStr() const {
		return m_query;
	}


private:
	char* m_query;
	char m_defBuf[QUERY_STRING_DEFAULT_SIZE];
};

struct SERVER_DECL AsyncQueryResult
{
	util::CAutoPointer<QueryResult> result;
	QueryStrBuffer query;
};

class SERVER_DECL AsyncQueryBase
{
public:
	virtual ~AsyncQueryBase() { }

	virtual bool IsQueryEmpty() const = 0;
	virtual int GetQuerySize() const = 0;
	virtual util::CAutoPointer<QueryResult> GetQueryResult(int index) const = 0;
	
protected:
	friend class Database;
	virtual bool IsTransaction() const = 0;
	virtual void Callback(void) = 0;
	virtual void SetQueryResult(int index, util::CAutoPointer<QueryResult>& result) = 0;
	virtual const char* GetQueryString(int index) const = 0;
	virtual void ResetQueryString() = 0;
};

class SERVER_DECL AsyncQueryCb : public AsyncQueryBase
{
public:
	AsyncQueryCb(util::CAutoPointer<SQLCallbackBase> f) : func(f), bTransaction(false) {}
	AsyncQueryCb(util::CAutoPointer<SQLCallbackBase> f, bool bTrans) : func(f), bTransaction(bTrans) {}
	~AsyncQueryCb() { if(!queries.empty()){ queries.clear(); } }

	int AddQuery(const char * format, ...)
	{
		char query[16384];
		va_list vlist;
		va_start(vlist, format);
		vsnprintf(query, 16384, format, vlist);
		va_end(vlist);

		AsyncQueryResult res;
		int nSize = (int)strlen(query) + 1;
		char* pBuf = res.query.SetQueryStr(nSize);
		memcpy(pBuf, query, nSize);
		int nIdx = queries.size();
		queries.push_back(res);
		return nIdx;
	}

	int AddQueryNA(const char * str)
	{
		AsyncQueryResult res;
		int nSize = (int)strlen(str) + 1;
		char* pBuf = res.query.SetQueryStr(nSize);
		memcpy(pBuf, str, nSize);
		int nIdx = queries.size();
		queries.push_back(res);
		return nIdx;
	}

	int AddQueryStr(const string& str)
	{
		AsyncQueryResult res;
		int nSize = (int)str.length() + 1;
		char* pBuf = res.query.SetQueryStr(nSize);
		memcpy(pBuf, str.c_str(), nSize);
		int nIdx = queries.size();
		queries.push_back(res);
		return nIdx;
	}

	virtual bool IsQueryEmpty() const {
		return queries.empty();
	}

	virtual int GetQuerySize() const {
		return (int)queries.size();
	}

	virtual util::CAutoPointer<QueryResult> GetQueryResult(int index) const {
		return queries[index].result;
	}

protected:
	util::CAutoPointer<SQLCallbackBase> func;
	vector<AsyncQueryResult> queries;
	bool bTransaction;

	virtual bool IsTransaction() const {
		return bTransaction;
	}

	virtual void SetQueryResult(int index, util::CAutoPointer<QueryResult>& result) {
		queries[index].result = result;
	}

	virtual const char* GetQueryString(int index) const {
		return queries[index].query.GetQueryStr();
	}

	virtual void ResetQueryString() {
		for(int i = 0; i < (int)queries.size(); ++i) {
			queries[i].query.Clear();
		}
	}

	virtual void Callback(void) {
		if(func.IsInvalid()) {
			return;
		}
		func->run(queries);
	}
};

class SERVER_DECL AsyncQueryWait : public AsyncQueryBase
{
public:
	AsyncQueryWait() : bTransaction(false) { waitEvent.suspend(); }
	AsyncQueryWait(bool bTrans) : bTransaction(bTrans) { waitEvent.suspend(); }
	~AsyncQueryWait() { Reset(); }

	int AddQuery(const char * format, ...)
	{
		char query[16384];
		va_list vlist;
		va_start(vlist, format);
		vsnprintf(query, 16384, format, vlist);
		va_end(vlist);

		AsyncQueryResult res;
		int nSize = (int)strlen(query) + 1;
		char* pBuf = res.query.SetQueryStr(nSize);
		memcpy(pBuf, query, nSize);
		int nIdx = queries.size();
		queries.push_back(res);
		return nIdx;
	}

	int AddQueryNA(const char * str)
	{
		AsyncQueryResult res;
		int nSize = (int)strlen(str) + 1;
		char* pBuf = res.query.SetQueryStr(nSize);
		memcpy(pBuf, str, nSize);
		int nIdx = queries.size();
		queries.push_back(res);
		return nIdx;
	}

	int AddQueryStr(const string& str)
	{
		AsyncQueryResult res;
		int nSize = (int)str.length() + 1;
		char* pBuf = res.query.SetQueryStr(nSize);
		memcpy(pBuf, str.c_str(), nSize);
		int nIdx = queries.size();
		queries.push_back(res);
		return nIdx;
	}

	virtual bool IsQueryEmpty() const {
		return queries.empty();
	}

	virtual int GetQuerySize() const {
		return (int)queries.size();
	}

	virtual util::CAutoPointer<QueryResult> GetQueryResult(int index) const {
		return queries[index].result;
	}

	void Wait(void) {
		waitEvent.wait();
	}

	void Reset(void) {
		if(!queries.empty()){
			queries.clear(); 
		}
		waitEvent.suspend();
	}

protected:
	thd::CSpinEvent waitEvent;
	vector<AsyncQueryResult> queries;
	bool bTransaction;

	virtual bool IsTransaction() const {
		return bTransaction;
	}

	virtual void SetQueryResult(int index, util::CAutoPointer<QueryResult>& result) {
		queries[index].result = result;
	}

	virtual const char* GetQueryString(int index) const {
		return queries[index].query.GetQueryStr();
	}

	virtual void ResetQueryString() {
		for(int i = 0; i < (int)queries.size(); ++i) {
			queries[i].query.Clear();
		}
	}

	virtual void Callback(void) {
		waitEvent.resume();
	}
};

class SERVER_DECL Database : public thd::CThread
{
	//friend class QueryThread;
	friend class BatchQuery;
public:
	Database();
	virtual ~Database();

	/************************************************************************/
	/* Thread Stuff                                                         */
	/************************************************************************/
	bool Run();

	/************************************************************************/
	/* Virtual Functions                                                    */
	/************************************************************************/
	virtual bool Initialize(const char* Hostname, unsigned int port,
		const char* Username, const char* Password, const char* DatabaseName,
		uint32_t ConnectionCount, uint32_t BufferSize) = 0;
	
	virtual void Shutdown() = 0;

	virtual util::CAutoPointer<QueryResult> Query(const char* QueryString, ...) throw();
	virtual util::CAutoPointer<QueryResult> QueryNA(const char* QueryString) throw();
	virtual util::CAutoPointer<QueryResult> FQuery(const char* QueryString, util::CAutoPointer<DatabaseConnection> con);
	virtual bool FWaitExecute(const char* QueryString, util::CAutoPointer<DatabaseConnection> con);
	virtual bool WaitExecute(const char* QueryString, ...) throw();//Wait For Request Completion
	virtual bool WaitExecuteNA(const char* QueryString) throw();//Wait For Request Completion
	virtual bool Execute(const char* QueryString, ...);
	virtual bool ExecuteNA(const char* QueryString);

	INLINE const string& GetHostName() { return mHostname; }
	INLINE const string& GetDatabaseName() { return mDatabaseName; }
	INLINE const uint32_t GetQueueSize() { return execute_queue.Size(); }

	virtual string EscapeString(const string& Escape) = 0;
	virtual void EscapeLongString(const char* str, uint32_t len, stringstream& out) = 0;
	virtual string EscapeString(const char* esc, util::CAutoPointer<DatabaseConnection> con) = 0;
	
	void WaitBatchQuery(util::CAutoPointer<AsyncQueryCb> aqcb) throw();
	void EndThreads();
	
	//void thread_proc_query();

	util::CAutoPointer<DatabaseConnection> GetFreeConnection() throw();

	void AddAsyncQuery(util::CAutoPointer<AsyncQueryBase> aq);

	static util::CAutoPointer<Database> CreateDatabaseInterface();
	static void CleanupLibs();

	virtual bool SupportsReplaceInto() = 0;
	virtual bool SupportsTableLocking() = 0;

	virtual void BeginTransaction(util::CAutoPointer<DatabaseConnection> conn) = 0;
	virtual void EndTransaction(util::CAutoPointer<DatabaseConnection> conn) = 0;
	virtual void RollbackTransaction(util::CAutoPointer<DatabaseConnection> conn) = 0;

    virtual int SelectDB(const char* db) = 0;

protected:

	// spawn threads and shizzle
	void _Initialize();

	// actual query function
	virtual bool _SendQuery(util::CAutoPointer<DatabaseConnection>& con, const char* Sql, bool Self) = 0;
	virtual util::CAutoPointer<QueryResult> _StoreQueryResult(util::CAutoPointer<DatabaseConnection>& con) = 0;

	void PerformAsyncQuery(util::CAutoPointer<AsyncQueryBase>& pAq, util::CAutoPointer<DatabaseConnection>& ccon) throw();
	////////////////////////////////
	thd::CCircleQueue<util::CAutoPointer<AsyncQueryBase> > query_queue;

	////////////////////////////////
	thd::CCircleQueue<QueryStrBuffer> execute_queue;
	util::CAutoPointer<DatabaseConnection> * Connections;
	
	uint32_t _counter;
	///////////////////////////////

	int32_t mConnectionCount;
    int32_t mCurConCount;

	// For reconnecting a broken connection
	string mHostname;
	string mUsername;
	string mPassword;
	string mDatabaseName;
	uint32_t mPort;

	// Initialized on load: Database::Database() : CThread()
	volatile bool ThreadRunning;

	//QueryThread * qt;
};

class SERVER_DECL QueryResult
{
public:
	QueryResult(uint32_t fields, uint32_t rows) : mFieldCount(fields), mRowCount(rows) {
		if(mFieldCount > QUERY_RESULT_DEFAULT_FIELD_SIZE) {
			mCurrentRow = new Field[mFieldCount];
		} else {
			mCurrentRow = mDefaultFields;
		}
	}
	QueryResult(const QueryResult& orig) : mFieldCount(orig.mFieldCount), mRowCount(orig.mRowCount) {
		if(mFieldCount > QUERY_RESULT_DEFAULT_FIELD_SIZE) {
			mCurrentRow = new Field[mFieldCount];
		} else {
			mCurrentRow = mDefaultFields;
		}
		for(unsigned int i = 0; i < mFieldCount; ++i) {
			mCurrentRow[i] = orig.mCurrentRow[i];
		}
	}
	virtual ~QueryResult() {
		if(mDefaultFields != mCurrentRow) {
			delete [] mCurrentRow;
			mCurrentRow = NULL;
		}
	}

	virtual bool NextRow() { return false; }

	INLINE Field* Fetch() { return mCurrentRow; }
	INLINE uint32_t GetFieldCount() const { return mFieldCount; }
	INLINE uint32_t GetRowCount() const { return mRowCount; }
    virtual Field* GetFieldByName(char* szFieldName) { return NULL; }

protected:
	uint32_t mFieldCount;
	uint32_t mRowCount;

private:
    Field *mCurrentRow;
	Field mDefaultFields[QUERY_RESULT_DEFAULT_FIELD_SIZE];
};

//class SERVER_DECL QueryThread : public CThread
//{
//	friend class Database;
//	Database * db;
//public:
//	QueryThread(Database * d) : CThread(), db(d) {}
//	~QueryThread();
//	bool Run();
//};

}

#endif
