/*
 * File:   Queue.h
 * Author: Jehu Shaw
 *
 */

 
#ifndef FQUEUE_H
#define FQUEUE_H

#include "Mutex.h"

namespace db {
 
template<class T> 
class FQueue 
{
public:
	FQueue() { first = last = NULL; size = 0; }
	~FQueue() {
		lock.Acquire();
		while(NULL != first) {
			delete first;
			first = (h*)first->pNext;
			--size;
		}
		lock.Release();
	}

	uint32_t get_size()
	{
		lock.Acquire();
		uint32_t retval = size;
		lock.Release();
		return retval;
	}

	void push(const T* item)
	{
		h* p = new h;
		p->pValue = item;
		p->pNext = NULL;
		
		lock.Acquire();
		if(last != NULL)//have some items
		{
			last->pNext = (h*)p;
			last = p;
			++size;
		}
		else //first item
		{
			last = first = p;
			size = 1;
		}
		lock.Release();
	}

	T* pop_nowait() { return pop(); }

	T* pop()
	{
		lock.Acquire();
		if(size == 0) {
			lock.Release();
			return NULL;
		}

		h* tmp = first;
		if(tmp == NULL) {
			lock.Release();
			return NULL;
		}

		if(--size > 0) { //more than 1 item
			first = (h*)first->pNext;
		} else  {//last item
			first = last = NULL;
		}
		
		lock.Release();

		T returnVal = tmp->pValue;
		delete tmp;
		return returnVal;
	}
	
private:
	struct h
	{
		T* pValue;
		void* pNext;
	};

	h * first;
	h * last;
	
	thread::Mutex lock;
	volatile unsigned int size;
};

}

#endif 