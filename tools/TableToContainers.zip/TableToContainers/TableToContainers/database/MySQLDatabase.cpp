/*
 * File:   MySQLDatabase.cpp
 * Author: Jehu Shaw
 *
 */

#include "DatabaseEnv.h"

#if defined(ENABLE_DATABASE_MYSQL)

#include "MySQLDatabase.h"

using namespace db;
using namespace util;

MySQLDatabase::~MySQLDatabase()
{
    mCurConCount = 0;
	for(int32_t i = 0; i < mConnectionCount; ++i) {
        CAutoPointer<MySQLDatabaseConnection> conn(Connections[i]);
        if(conn.IsInvalid()) {
			continue;
		}
        mysql_close(conn->MySql);
	}
	delete [] Connections;
}

MySQLDatabase::MySQLDatabase() : Database()
{

}

void MySQLDatabase::BeginTransaction(CAutoPointer<DatabaseConnection> conn)
{
	_SendQuery(conn, "BEGIN;", false);
}

void MySQLDatabase::EndTransaction(CAutoPointer<DatabaseConnection> conn)
{
	_SendQuery(conn, "COMMIT;", false);
}

void MySQLDatabase::RollbackTransaction(CAutoPointer<DatabaseConnection> conn)
{
	_SendQuery(conn, "ROLLBACK;", false);
}

bool MySQLDatabase::Initialize(const char* Hostname, unsigned int port, const char* Username,
	const char* Password, const char* DatabaseName, uint32_t ConnectionCount, uint32_t BufferSize)
{
	uint32_t i;
	MYSQL * temp = NULL;
	MYSQL * temp2 = NULL;
	my_bool my_true = true;

	mHostname = string(Hostname);
	mConnectionCount = ConnectionCount;
	mUsername = string(Username);
	mPassword = string(Password);
	mDatabaseName = string(DatabaseName);

	if(ConnectionCount < 1) {
		return false;
	}

	Log.Notice("MySQLDatabase", "Connecting to `%s`, database `%s`...", Hostname, DatabaseName);
	
    delete [] Connections;
	Connections = new CAutoPointer<DatabaseConnection> [ConnectionCount];

	for(i = 0; i < ConnectionCount; ++i) {

		temp = mysql_init(NULL);
		if(temp == NULL) {
			continue;
		}

		if(mysql_options(temp, MYSQL_SET_CHARSET_NAME, "utf8")) {
			Log.Error("MySQLDatabase", "Could not set utf8 character set.");
		}

		if (mysql_options(temp, MYSQL_OPT_RECONNECT, &my_true)) {
			Log.Error("MySQLDatabase", "MYSQL_OPT_RECONNECT could not be set, connection drops may occur but will be counteracted.");
		}

		temp2 = mysql_real_connect(temp, Hostname, Username, Password, DatabaseName, port, NULL, CLIENT_MULTI_RESULTS | CLIENT_MULTI_STATEMENTS);
		if(temp2 == NULL) {
			Log.Error("MySQLDatabase", "Connection failed due to: `%s`", mysql_error(temp));
			mysql_close(temp);
			return false;
		}

		CAutoPointer<MySQLDatabaseConnection> pMysqlConnc(new MySQLDatabaseConnection);
		pMysqlConnc->MySql = temp2;
		Connections[i] = pMysqlConnc;

        ++mCurConCount;
	}

	Database::_Initialize();
	return true;
}

string MySQLDatabase::EscapeString(const string& Escape) throw()
{
	CAutoPointer<MySQLDatabaseConnection> mysqlCon(GetFreeConnection());
	if(mysqlCon.IsInvalid()) {
		return string();
	}
	char a2[16384] = { 0 };
	string ret;
	if(mysql_real_escape_string(mysqlCon->MySql, a2, Escape.c_str(),
		(unsigned long)Escape.length()) == 0)
	{
		ret = Escape.c_str();
	} else {
		ret = a2;
	}
	mysqlCon->Busy.unlock();

	return string(ret);
}

void MySQLDatabase::EscapeLongString(const char * str, uint32_t len, stringstream& out) throw()
{
	CAutoPointer<MySQLDatabaseConnection> mysqlCon(GetFreeConnection());
	if(mysqlCon.IsInvalid()) {
		return;
	}
	char a2[65536*3] = { 0 };
	const char * ret;
	if(mysql_real_escape_string(mysqlCon->MySql,
		a2, str, (unsigned long)len) == 0) 
	{
		ret = str;
	} else {
		ret = a2;
	}
	out.write(a2, (std::streamsize)strlen(a2));
	mysqlCon->Busy.unlock();
}

string MySQLDatabase::EscapeString(const char * esc, CAutoPointer<DatabaseConnection> con)
{
	CAutoPointer<MySQLDatabaseConnection> mysqlCon(con);
	if(mysqlCon.IsInvalid()) {
		return string();
	}
	char a2[16384] = { 0 };
	const char * ret;
	if(mysql_real_escape_string(mysqlCon->MySql, a2, 
		(char*)esc, (unsigned long)strlen(esc)) == 0) 
	{
		ret = esc;
	} else {
		ret = a2;
	}

	return string(ret);
}

void MySQLDatabase::Shutdown()
{
	EndThreads();
	mysql_library_end();
}

bool MySQLDatabase::_SendQuery(CAutoPointer<DatabaseConnection>& con, const char* Sql, bool Self)
{
	//dunno what it does ...leaving untouched 
    CAutoPointer<MySQLDatabaseConnection> myCon(con);
    if(myCon.IsInvalid()) { return false; }
	int result = mysql_query(myCon->MySql, Sql);
	if(result > 0)
	{
		if(Self == false && _HandleError(myCon, mysql_errno(myCon->MySql)))
		{
			// Re-send the query, the connection was successful.
			// The true on the end will prevent an endless loop here, as it will
			// stop after sending the query twice.
			result = _SendQuery(con, Sql, true);
		}
		else{
            //printf("Sql query failed due to [%s], Query: [%s]", mysql_error(myCon->MySql), Sql);
			Log.outError("Sql query failed due to [%s], Query: [%s]", mysql_error(myCon->MySql), Sql);
       }
	}

	return (result == 0 ? true : false);
}

bool MySQLDatabase::_HandleError(CAutoPointer<MySQLDatabaseConnection>& con, uint32_t ErrorNumber)
{
	// Handle errors that should cause a reconnect to the Database.
	switch(ErrorNumber)
	{
	case 2006:  // Mysql server has gone away
	case 2008:  // Client ran out of memory
	case 2013:  // Lost connection to sql server during query
	case 2055:  // Lost connection to sql server - system error
		{
			// Let's instruct a reconnect to the db when we encounter these errors.
			return _Reconnect(con);
		}break;
	}

	return false;
}

int MySQLDatabase::SelectDB(const char *db)
{
    if(mCurConCount < 1) {
        return 0;
    }
    int nResult(0);
    for(int32_t i = 0; i < mConnectionCount; ++i) {
        CAutoPointer<MySQLDatabaseConnection> myCon(Connections[i]);
        if(myCon.IsInvalid()) {
            continue;
        }
        int nRt = mysql_select_db(myCon->MySql, db);
        if(0 != nRt) {
            nResult = nRt;
        }
    }
    return nResult;
}

MySQLQueryResult::MySQLQueryResult(MYSQL_RES* res, MYSQL_FIELD *fields, uint32_t FieldCount, uint32_t RowCount) 
	: QueryResult(FieldCount, RowCount), mResult(res), mField(fields)
{
}

MySQLQueryResult::~MySQLQueryResult()
{
	mysql_free_result(mResult);
}

bool MySQLQueryResult::NextRow()
{
	MYSQL_ROW row = mysql_fetch_row(mResult);
	if(row == NULL) {
		return false;
	}
	Field* arrRows = Fetch();
	if(NULL == arrRows) {
		return false;
	}
	for(uint32_t i = 0; i < mFieldCount; ++i) {
		arrRows[i].SetValue(row[i]);
        arrRows[i].SetField(mField[i].name);
    }
	return true;
}

Field* MySQLQueryResult::GetFieldByName(char* szFieldName)
{
	Field* arrRows = Fetch();
	if(szFieldName && arrRows && mField) {
		for(int i = 0; i < (int)mFieldCount ;++i) {
			if(strcmp(mField[i].name, szFieldName) == 0) {
				return &(arrRows[i]);
			}
		}        
	}
	return NULL;
}

CAutoPointer<QueryResult> MySQLDatabase::_StoreQueryResult(CAutoPointer<DatabaseConnection>& con)
{
	CAutoPointer<MySQLDatabaseConnection> db(con);
    if(db.IsInvalid()) {
        return CAutoPointer<QueryResult>();
    }

	MYSQL_RES * pRes = mysql_store_result(db->MySql);
	if(NULL == pRes) {
		bool bVain = true;
		int32_t nRows = (int32_t)mysql_affected_rows(db->MySql);
		mysql_free_result(pRes);
		while(0 == mysql_next_result(db->MySql)) {  
			pRes = mysql_store_result(db->MySql);
			if(NULL != pRes) {
				bVain = false;
				break;
			}
			nRows = (int32_t)mysql_affected_rows(db->MySql);
			mysql_free_result(pRes);
		}
		if(bVain) {
			if(mysql_field_count(db->MySql) == 0) {
				// query does not return data
				// (it was not a SELECT)		
				if(nRows > -1) {
					return CAutoPointer<QueryResult>(
						new MySQLQueryResult(NULL, NULL, 0, nRows));
				}
			}
			return CAutoPointer<QueryResult>();
		}
	}

	int32_t nRows = (int32_t)mysql_affected_rows(db->MySql);
	uint32_t uFields = (uint32_t)mysql_field_count(db->MySql);
    MYSQL_FIELD *fields = mysql_fetch_fields(pRes);
	if(nRows < 1 || uFields == 0) {
		mysql_free_result(pRes);
		// delete left result set.
		while(0 == mysql_next_result(db->MySql)) {  
			MYSQL_RES* res = mysql_store_result(db->MySql);  
			mysql_free_result(res);
		}
		return CAutoPointer<QueryResult>();
	}

	CAutoPointer<MySQLQueryResult> res = CAutoPointer<MySQLQueryResult>(
		new MySQLQueryResult(pRes, fields, uFields, nRows));
	res->NextRow();
	// only return first result, delete left result set.
	while(0 == mysql_next_result(db->MySql)) {  
		MYSQL_RES* res = mysql_store_result(db->MySql);  
		mysql_free_result(res);
	}
	return res;
}

bool MySQLDatabase::_Reconnect(CAutoPointer<MySQLDatabaseConnection>& conn)
{
	MYSQL * temp, *temp2;

	temp = mysql_init(NULL);
	temp2 = mysql_real_connect(temp, mHostname.c_str(), mUsername.c_str(), mPassword.c_str(),
		mDatabaseName.c_str(), mPort, NULL , CLIENT_MULTI_RESULTS | CLIENT_MULTI_STATEMENTS);
	if(temp2 == NULL) {
		Log.Error("MySQLDatabase", "Could not reconnect to database because of `%s`", mysql_error(temp));
		mysql_close(temp);
		return false;
	}

	if(conn->MySql != NULL) {
		mysql_close(conn->MySql);
	}
	conn->MySql = temp;
	return true;
}

#endif
