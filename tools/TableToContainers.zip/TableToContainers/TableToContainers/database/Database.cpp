/*
 * File:   Database.cpp
 * Author: Jehu Shaw
 *
 */

#include "DatabaseEnv.h"

using namespace db;
using namespace util;
using namespace thd;

SQLCallbackBase::~SQLCallbackBase()
{

}

Database::Database() : CThread(), query_queue(32), execute_queue(32)
	, _counter(0), Connections(NULL), mConnectionCount(-1), ThreadRunning(false)
	, mCurConCount(0)
{

}

Database::~Database()
{
   EndThreads();
}

void Database::_Initialize()
{
	// Spawn Database thread
	ThreadPool.ExecuteTask(this);

	// launch the query thread
	//qt = new QueryThread(this);
	//ThreadPool.ExecuteTask(qt);
}

CAutoPointer<DatabaseConnection> Database::GetFreeConnection() throw()
{
    if(mCurConCount < 1) {
        return CAutoPointer<DatabaseConnection>();
    }
	int32_t i = 0;
	for(;;)
	{
		CAutoPointer<DatabaseConnection> con(Connections[ ((i++) % mConnectionCount) ]);
		if(!con.IsInvalid() && con->Busy.tryLock()) { 
			return con;
		}
	}

	// shouldn't be reached
	return CAutoPointer<DatabaseConnection>();
}

// Use this when we request data that can return a value (not async)
CAutoPointer<QueryResult> Database::Query(const char* QueryString, ...) throw()
{	
	char sql[16384];
	va_list vlist;
	va_start(vlist, QueryString);
	vsnprintf(sql, 16384, QueryString, vlist);
	va_end(vlist);

	// Send the query
	CAutoPointer<QueryResult> qResult;
	CAutoPointer<DatabaseConnection> con(GetFreeConnection());

	if(_SendQuery(con, sql, false)) {
		qResult = _StoreQueryResult(con);
    }

    if(!con.IsInvalid()) {
	    con->Busy.unlock();
    }
	return qResult;
}

CAutoPointer<QueryResult> Database::QueryNA(const char* QueryString) throw()
{	
	// Send the query
	CAutoPointer<QueryResult> qResult;
	CAutoPointer<DatabaseConnection> con(GetFreeConnection());

	if(_SendQuery(con, QueryString, false)) {
		qResult = _StoreQueryResult(con);
	}

    if(!con.IsInvalid()) {
	    con->Busy.unlock();
    }
	return qResult;
}

CAutoPointer<QueryResult> Database::FQuery(const char * QueryString, CAutoPointer<DatabaseConnection> con)
{	
	// Send the query
	CAutoPointer<QueryResult> qResult;
	if(_SendQuery(con, QueryString, false)) {
		qResult = _StoreQueryResult(con);
	}
	return qResult;
}

bool Database::FWaitExecute(const char * QueryString, CAutoPointer<DatabaseConnection> con)
{	
	// Send the query
	return _SendQuery(con, QueryString, false);
}

void Database::PerformAsyncQuery(CAutoPointer<AsyncQueryBase>& pAq, CAutoPointer<DatabaseConnection>& ccon) throw()
{
    if(pAq.IsInvalid()) {
        return;
    }

	if(pAq->IsQueryEmpty()) {
		return;
	}

	CAutoPointer<DatabaseConnection> con(ccon);
	if(ccon.IsInvalid()) {
		con = GetFreeConnection();
	}

	if(pAq->IsTransaction()) {
		BeginTransaction(con);
	}

	int nQuerySize = pAq->GetQuerySize();
	for(int i = 0; i < nQuerySize; ++i) {
		if(_SendQuery(con, pAq->GetQueryString(i), false)) {
			pAq->SetQueryResult(i, _StoreQueryResult(con));
		}
	}
	pAq->ResetQueryString();

	if(pAq->IsTransaction()) {
		EndTransaction(con);
	}

	if(ccon.IsInvalid() && !con.IsInvalid()) {
		con->Busy.unlock();
    }

	pAq->Callback();
}
// Use this when we do not have a result. ex: INSERT into SQL 1 
bool Database::Execute(const char* QueryString, ...)
{
	char query[16384];

	va_list vlist;
	va_start(vlist, QueryString);
	vsnprintf(query, 16384, QueryString, vlist);
	va_end(vlist);

	if(!ThreadRunning) {
		return WaitExecuteNA(query);
	}

	QueryStrBuffer* pStr = execute_queue.WriteLock();
	int nSize = (int)strlen(query) + 1;
	char* pBuf = pStr->SetQueryStr(nSize);
	memcpy(pBuf, query, nSize);
	execute_queue.WriteUnlock();
	return true;
}

bool Database::ExecuteNA(const char* QueryString)
{
	if(!ThreadRunning) {
		return WaitExecuteNA(QueryString);
	}

	QueryStrBuffer* pStr = execute_queue.WriteLock();
	int nSize = (int)strlen(QueryString) + 1;
	char* pBuf = pStr->SetQueryStr(nSize);
	memcpy(pBuf, QueryString, nSize);
	execute_queue.WriteUnlock();
	return true;
}

// Wait till the other queries are done, then execute
bool Database::WaitExecute(const char* QueryString, ...) throw()
{
	char sql[16384];
	va_list vlist;
	va_start(vlist, QueryString);
	vsnprintf(sql, 16384, QueryString, vlist);
	va_end(vlist);

	CAutoPointer<DatabaseConnection> con(GetFreeConnection());
	bool Result = _SendQuery(con, sql, false);
    if(!con.IsInvalid()) {
	    con->Busy.unlock();
    }
	return Result;
}

bool Database::WaitExecuteNA(const char* QueryString) throw()
{
	CAutoPointer<DatabaseConnection> con(GetFreeConnection());
	bool Result = _SendQuery(con, QueryString, false);
    if(!con.IsInvalid()) {
	    con->Busy.unlock();
    }
	return Result;
}

bool Database::Run()
{
//	SetThreadName("Database Execute Thread");
	SetThreadState(THREADSTATE_BUSY);
	atomic_xchg8(&ThreadRunning, true);
	CAutoPointer<DatabaseConnection> con(GetFreeConnection());

	while(true) {

		int nExeSize = execute_queue.Size();
		for(int i = 0; i < nExeSize; ++i) {
			QueryStrBuffer* pStr = execute_queue.ReadLock();
			if(NULL == pStr) {
				break;
			}
			_SendQuery(con, pStr->GetQueryStr(), false);
			pStr->Clear();
			execute_queue.ReadUnlock();
		}

		int nQuerySize = query_queue.Size();
		for(int j = 0; j < nQuerySize; ++j) {
			CAutoPointer<AsyncQueryBase>* pAq = query_queue.ReadLock();
			if(NULL == pAq) {
				break;
			}
			PerformAsyncQuery(*pAq, con);
			pAq->SetRawPointer(NULL);
			query_queue.ReadUnlock();
		}

		if(GetThreadState() == THREADSTATE_TERMINATE) {
			if(execute_queue.Size() < 1 && query_queue.Size() < 1) {
				break;
			}
		}

		Sleep(3);
	}
	atomic_xchg8(&ThreadRunning, false);

	return false;
}

//void BatchQuery::AddQuery(const char * format, ...)
//{
//	AsyncQueryResult res;
//	va_list ap;
//	char buffer[10000];
//	size_t len;
//	va_start(ap, format);
//	vsnprintf(buffer, 10000, format, ap);
//	va_end(ap);
//	len = strlen(buffer);
//	ASSERT(len);
//	res.query = new char[len+1];
//	memcpy(res.query, buffer, len);
//	res.query[len] = '\0';
//
//	res.result = NULL;
//	queries.push_back(res);
//}

//void BatchQuery::Perform()
//{
//	DatabaseConnection * conn = db->GetFreeConnection();
//	vector<AsyncQueryResult>::iterator itr = queries.begin();
//	for(; itr != queries.end(); ++itr) {
//		itr->result = db->FQuery(itr->query, conn);
//    }
//
//    if(NULL != conn) {
//	    conn->Busy.Release();
//    }
//
//	if(NULL != func) {
//		func->run(queries);
//	}
//
//	delete this;
//}

//BatchQuery::~BatchQuery()
//{
//	delete func;
//	func = NULL;
//	vector<AsyncQueryResult>::iterator itr = queries.begin();
//	for(; itr != queries.end(); ++itr) {
//		if(itr->result) {
//			delete itr->result;
//			itr->result = NULL;
//		}
//		delete[] itr->query;
//		itr->query = NULL;
//	}
//}

void Database::EndThreads()
{
	SetThreadState(THREADSTATE_TERMINATE);

	// wait
	for(int i = 0; ThreadRunning; ++i) {
		cpu_relax(i);
	}
}

//bool QueryThread::Run()
//{
//	db->thread_proc_query();
//	return true;
//}
//
//QueryThread::~QueryThread()
//{
//	db->qt = NULL;
//}

//void Database::thread_proc_query()
//{
//	AsyncQuery* q;
//	DatabaseConnection* con = GetFreeConnection();
////        printf("Database::thread_proc_query() start\n");
//	q = query_queue.pop();
//	while(1) {
//		if(q != NULL) {
//			PerformAsyncQuery(q, con);
//			delete q;
//		}
//
//		if(GetThreadState() == THREADSTATE_TERMINATE) {
//			break;
//		}
//
//		q = query_queue.pop();
//		if(q == NULL) {
//			Sleep(10);
//		}
//	}
//
//    if(NULL != con) {
//	    con->Busy.Release();
//    }
//
//	// kill any queries
//	q = query_queue.pop();
//	while(q != NULL) {
//		PerformAsyncQuery(q, NULL);
//		delete q;
//
//		q = query_queue.pop();
//	}
//}

void Database::WaitBatchQuery(CAutoPointer<AsyncQueryCb> aqcb) throw()
{
	CAutoPointer<AsyncQueryBase> aq(aqcb);
	if(aq.IsInvalid()) {
		return;
	}

	if(aq->IsQueryEmpty()) {
		return;
	}

	CAutoPointer<DatabaseConnection> conn(GetFreeConnection());
	
	int nQuerySize = aq->GetQuerySize();
	for(int i = 0; i < nQuerySize; ++i) {
		aq->SetQueryResult(i, FQuery(aq->GetQueryString(i), conn));
	}
	aq->ResetQueryString();

	if(!conn.IsInvalid()) {

		conn->Busy.unlock();
	}

	aq->Callback();
}

void Database::AddAsyncQuery(CAutoPointer<AsyncQueryBase> aq)
{
	if(aq.IsInvalid()) {
		return;
	}

	if(!ThreadRunning) {
		PerformAsyncQuery(aq, CAutoPointer<DatabaseConnection>());
	}

	CAutoPointer<AsyncQueryBase>* pAq = query_queue.WriteLock();
	*pAq = aq;
	query_queue.WriteUnlock();
}


