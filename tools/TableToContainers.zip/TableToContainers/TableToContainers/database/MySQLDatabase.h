/*
 * File:   MySQLDatabase.h
 * Author: Jehu Shaw
 *
 */

#ifndef _MYSQLDATABASE_H
#define _MYSQLDATABASE_H

#include <mysql.h>
#include "Database.h"

namespace db {

class SchemeDescriptor;
class dbFieldDescriptor;

struct MySQLDatabaseConnection : public DatabaseConnection
{
	MYSQL * MySql;
};

class SERVER_DECL MySQLDatabase : public Database
{
	friend class QueryThread;
	//friend class BatchQuery;
public:
	MySQLDatabase();
	~MySQLDatabase();

	bool Initialize(const char* Hostname, unsigned int port,
		const char* Username, const char* Password, const char* DatabaseName,
		uint32_t ConnectionCount, uint32_t BufferSize);

	void Shutdown();

	std::string EscapeString(const std::string& Escape);
	void EscapeLongString(const char * str, uint32_t len, std::stringstream& out);
	std::string EscapeString(const char * esc, util::CAutoPointer<DatabaseConnection> con);

	bool SupportsReplaceInto() { return true; }
	bool SupportsTableLocking() { return true; }

	void BeginTransaction(util::CAutoPointer<DatabaseConnection> conn);
	void EndTransaction(util::CAutoPointer<DatabaseConnection> conn);
	void RollbackTransaction(util::CAutoPointer<DatabaseConnection> conn);

    int SelectDB(const char *db);
        
protected:

	bool _HandleError(util::CAutoPointer<MySQLDatabaseConnection>& con, uint32_t ErrorNumber);
	bool _SendQuery(util::CAutoPointer<DatabaseConnection>& con, const char* Sql, bool Self = false);

	bool _Reconnect(util::CAutoPointer<MySQLDatabaseConnection>& conn);

	util::CAutoPointer<QueryResult> _StoreQueryResult(util::CAutoPointer<DatabaseConnection>& con);

};

class SERVER_DECL MySQLQueryResult : public QueryResult, public util::PoolBase<MySQLQueryResult, 8>
{
public:
	MySQLQueryResult(MYSQL_RES* res, MYSQL_FIELD *fields , uint32_t FieldCount, uint32_t RowCount);
	~MySQLQueryResult();

	bool NextRow();

	Field* GetFieldByName(char* szFieldName);

protected:
	MYSQL_RES* mResult;
	MYSQL_FIELD* mField;
};

}

#endif		// _MYSQLDATABASE_H
