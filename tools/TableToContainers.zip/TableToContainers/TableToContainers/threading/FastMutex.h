/*
 * File:   FastMutex.h
 * Author: Jehu Shaw
 *
 */

#ifndef _FAST_MUTEX_H
#define _FAST_MUTEX_H

#include "Common.h"
#include "ILock.h"
#include "AtomicLock.h"

namespace thd {

class CFastMutex : public ILock
{
public:
	CFastMutex() : m_lock(0) {}

	~CFastMutex() {}

	void lock() throw()
	{
		unsigned long threadId = CurrentThreadId();
		if(threadId == (unsigned long)m_lock) {
			++m_recursiveCount;
			return;
		}

		for(int i = 0; atomic_cmpxchg(&m_lock, threadId, 0); ++i) {
			cpu_relax(i);
		}

		++m_recursiveCount;
	}

	bool tryLock() throw()
	{
		unsigned long threadId = CurrentThreadId();
		if(threadId == (unsigned long)m_lock) {
			++m_recursiveCount;
			return true;
		}

		if(atomic_cmpxchg(&m_lock, threadId, 0) == 0) {
			++m_recursiveCount;
			return true;
		}

		return false;
	}

	void unlock() throw()
	{
		unsigned long threadId = CurrentThreadId();
		if(threadId == (unsigned long)m_lock) {
			if(m_recursiveCount > 0) {
				--m_recursiveCount;
			}
			if(m_recursiveCount == 0) {
				atomic_xchg(&m_lock, 0);
			}
		}
	}

private:
	CFastMutex(const CFastMutex& orig);
	CFastMutex& operator=(const CFastMutex& orig);

private:
	volatile unsigned long m_lock;
	long m_recursiveCount;
};

}

#endif /* _FAST_MUTEX_H */

