#include "Common.h"
#include "CThreads.h"

using namespace thd;

CThread::CThread() : ThreadBase(), m_startTime(0)
{
	SetThreadState(THREADSTATE_AWAITING);
}

CThread::~CThread()
{
	
}

bool CThread::Run()
{
	return false;
}

void CThread::OnShutdown()
{
	SetThreadState(THREADSTATE_TERMINATE);
}

