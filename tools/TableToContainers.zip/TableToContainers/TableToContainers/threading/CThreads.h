/*
 * File:   CThreads.h
 * Author: Jehu Shaw
 *
 */

// Class CThread - Base class for all threads in the
// server, and allows for easy management .

#ifndef _CTHREADS_H
#define _CTHREADS_H

#include "ThreadBase.h"
#include "AtomicLock.h"

namespace thd {

enum CThreadState
{
	THREADSTATE_TERMINATE = 0,
	THREADSTATE_PAUSED	= 1,
	THREADSTATE_SLEEPING  = 2,
	THREADSTATE_BUSY	  = 3,
	THREADSTATE_AWAITING  = 4,
};

class SERVER_DECL CThread : public ThreadBase
{
public:
	CThread();
	~CThread();

	INLINE void SetThreadState(CThreadState threadState) {
		atomic_xchg(&m_threadState, threadState);
	}
	INLINE CThreadState GetThreadState() {
		return (CThreadState)m_threadState;
	}
	int GetThreadId() { return m_threadId; }
	time_t GetStartTime() { return m_startTime; }
	virtual bool Run();
	virtual void OnShutdown();

protected:

	CThread& operator=( CThread &other ) {
		this->m_startTime = other.m_startTime;
		this->m_threadId = other.m_threadId;
		atomic_xchg(&m_threadState, other.m_threadState);
		return *this;
	}

	volatile long m_threadState;
	time_t m_startTime;
	int m_threadId;
};

}

#endif /* _CTHREADS_H */
