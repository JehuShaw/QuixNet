/*
 * File:   SpinRWLock.h
 * Author: Jehu Shaw
 *
 * Created on 2013��10��1��, ����10:32
 */

#ifndef __SPINRWLOCK_H_
#define	__SPINRWLOCK_H_

#include "SpinLock.h"
#include "IRWLock.h"

namespace thd {

	class CSpinRWLock : private CSpinLock, public IRWLock {
	public:
		CSpinRWLock() throw() : CSpinLock(), m_readers(0) {
		}

        ~CSpinRWLock() throw() {
        }

		void lockWrite() throw() {

			/* Get lock */
			lock();

			/* Wait for readers to finish */
			for(int i = 0; m_readers; ++i) {
				cpu_relax(i);
			}
		}

		void unlockWrite() throw() {
			unlock();
		}

		bool tryLockWrite() throw() {

			/* Want no readers */
			if(m_readers) return false;

			/* Try to get write lock */
			if(!tryLock()) return false;

			if (m_readers) {
				/* Oops, a reader started */
				unlock();
				return false;
			}

			/* Success! */
			return true;
		}

		void lockRead() throw() {

			while (1)
			{
				/* Success? */
				if(lockable())
				{
					/* Speculatively take read lock */
					atomic_inc(&m_readers);

					/* Success? */
					if (lockable()) return;

					/* Failure - undo, and wait until we can try again */
					atomic_dec(&m_readers);
				}

				for(int i = 0; !lockable(); ++i) {
					cpu_relax(i);
				}
			}

		}

		void unlockRead() throw() {
			atomic_dec(&m_readers);
		}

		bool tryLockRead() throw() {

			/* Speculatively take read lock */
			atomic_inc(&m_readers);

			/* Success? */
			if (lockable()) return true;

			/* Failure - undo */
			atomic_dec(&m_readers);

			return false;

		}

		bool upgradeLockRead() throw() {
			/* Try to convert into a write lock */
			if (!tryLock()) return false;

			/* I'm no longer a reader */
			atomic_dec(&m_readers);

			/* Wait for all other readers to finish */
			for(int i = 0; m_readers; ++i) {
				cpu_relax(i);
			}
			return true;
		}

	private:
		volatile uint32_t m_readers;
	};

}

#endif  // __SPINRWLOCK_H_
