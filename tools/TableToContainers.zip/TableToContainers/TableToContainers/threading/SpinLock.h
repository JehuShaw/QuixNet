/*
 * File:   SpinLock.h
 * Author: Jehu Shaw
 *
 * Created on 2013��10��1��, ����10:32
 */

#ifndef SPINLOCK_H_
#define	SPINLOCK_H_

#include "Common.h"
#include "AtomicLock.h"

namespace thd {


	class CSpinLock : public ILock
	{
	public:
		CSpinLock(void) { m_lock.u = 0; }
		~CSpinLock(void) { }

		void lock() throw() {

			uint16_t me = (uint16_t)atomic_xadd16(&m_lock.s.users, 1);

			for(int i = 0; m_lock.s.ticket != me; ++i) {
				cpu_relax(i);
			}

		}

		void unlock() throw() {

			memory_barrier();
			m_lock.s.ticket++;
		}

		bool tryLock() throw() {
			uint16_t me = m_lock.s.users;
			uint16_t menew = me + 1;
			union TicketLock cmp;
			cmp.s.ticket = me;
			cmp.s.users = me;
			union TicketLock cmpnew;
			cmpnew.s.ticket = me;
			cmpnew.s.users = menew;

			if(atomic_cmpxchg(&m_lock.u, cmpnew.u, cmp.u) == cmp.u) {
				return true;
			}
			return false;
		}

		bool lockable() throw() {
			union TicketLock u;
			u.u = m_lock.u;
			memory_barrier();
			return (u.s.ticket == u.s.users);
		}

	protected:
		union TicketLock
		{
			uint32_t u;
			struct
			{
				uint16_t ticket;
				uint16_t users;
			} s;
		};

		volatile union TicketLock m_lock;
	};

class CSpinEvent {
public:
	CSpinEvent(void) : m_flag(FALSE) {}
	~CSpinEvent(void) { resume(); }

	void wait() {
		// wait
		for(int i = 0; TRUE == m_flag; ++i) {
			cpu_relax(i);
		}
	}

	void suspend() {
		atomic_xchg8(&m_flag, TRUE);
	}

	void resume() {
		atomic_xchg8(&m_flag, FALSE);
	}

private:
	volatile char m_flag;
};



}

#endif  // SPINLOCK_H_
