/*
 * File:   IRWLock.h
 * Author: Jehu Shaw
 *
 */

#ifndef __IRWLOCK_H_
#define __IRWLOCK_H_

#include "Common.h"

namespace thd {

/** An abstract base class for synchronization primitives.
 */
class IRWLock
{
  public:

  /** Destructor. */
  virtual ~IRWLock() { }

  /** Acquire a write lock, blocking until the unlockWrite is acquired. */
  virtual void lockWrite() throw() = 0;

  /** Release the write lock. */
  virtual void unlockWrite() throw() = 0;

  /** Acquire a read lock, blocking until the unlockRead is acquired. */
  virtual void lockRead() throw() = 0;

  /** Release the read lock. */
  virtual void unlockRead() throw() = 0;
};

}; // namespace thd

#endif // __IRWLOCK_H_

/* end of header file */
