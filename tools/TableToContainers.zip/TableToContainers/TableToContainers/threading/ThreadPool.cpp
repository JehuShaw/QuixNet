#include "ThreadPool.h"
#include "Log.h"

using namespace thd;
using namespace util;

#ifdef WIN32
#include <process.h>
#endif

namespace thd {
	SERVER_DECL CThreadPool ThreadPool;
}

CThreadPool::CThreadPool()
{
	_bShutdown = false;
	_threadsExitedSinceLastCheck = 0;
	_threadsRequestedSinceLastCheck = 0;
	_threadsEaten = 0;
	_threadsFreedSinceLastCheck = 0;
}

bool CThreadPool::ThreadExit(Thread * t)
{
	CScopedLock scopedLock(_mutex);
	
	// we're definitely no longer active
	m_activeThreads.erase(t);

	// do we have to kill off some threads?
	if(_threadsToExit > 0)
	{
		// kill us.
		--_threadsToExit;
		++_threadsExitedSinceLastCheck;
		if(t->DeleteAfterExit)
			m_freeThreads.erase(t);

		delete t;
		return false;
	}

	// enter the "suspended" pool
	++_threadsExitedSinceLastCheck;
	++_threadsEaten;
	std::set<Thread*>::iterator itr = m_freeThreads.find(t);

	if(itr != m_freeThreads.end())
	{
		Log.outError("Thread %u duplicated with thread %u", (*itr)->ControlInterface.GetId(), t->ControlInterface.GetId());
	}
	m_freeThreads.insert(t);
#ifdef OPEN_THREAD_POOL_DEBUG
	Log.Debug("ThreadPool", "Thread %u entered the free pool.", t->ControlInterface.GetId());
#endif
	return true;
}

void CThreadPool::ExecuteTask(ThreadBase * ExecutionTarget)
{
	CScopedLock scopedLock(_mutex);

	if(_bShutdown) {
		return;
	}

	++_threadsRequestedSinceLastCheck;
	--_threadsEaten;
    Thread * t(NULL);
	// grab one from the pool, if we have any.
	if(m_freeThreads.size())
	{
        ThreadSet::iterator itF(m_freeThreads.begin());
        while(m_freeThreads.end() != itF) 
        {
            t = *itF;
            
            if(NULL == t) {
                m_freeThreads.erase(itF++);
                continue;
            }
            
            // execute the task on this thread.
            t->ExecutionTarget = ExecutionTarget;
            // resume the thread, and it should start working.
            if(t->ControlInterface.Resume()) {
                m_freeThreads.erase(itF++);
                m_activeThreads.insert(t);
#ifdef OPEN_THREAD_POOL_DEBUG
                Log.Debug("ThreadPool", "Thread %u left the thread pool.", t->ControlInterface.GetId());
#endif
                break;
            } else {
                t->ExecutionTarget = NULL;
            }
            ++itF;
        }

	}
	else
	{
		// creating a new thread means it heads straight to its task.
		// no need to resume it :)
		t = StartThread(ExecutionTarget);
        if(NULL != t) {
            m_activeThreads.insert(t);
        }
	}

    if(NULL != t) {
#ifdef OPEN_THREAD_POOL_DEBUG
	// add the thread to the active set
#ifdef WIN32
	Log.Debug("ThreadPool", "Thread %u is now executing task at 0x%p.", t->ControlInterface.GetId(), ExecutionTarget);
#else
	Log.Debug("ThreadPool", "Thread %u is now executing task at %p.", t->ControlInterface.GetId(), ExecutionTarget);
#endif
#endif
    }
	
}

void CThreadPool::Startup(int tCount/* = THREAD_RESERVE*/)
{
	for(int i= 0; i < tCount; ++i) {
		StartThread(NULL);
	}
#ifdef OPEN_THREAD_POOL_DEBUG
	Log.Debug("ThreadPool", "Startup, launched %u threads.", tCount);
#endif
}

void CThreadPool::ShowStats()
{
	CScopedLock scopedLock(_mutex);
	Log.Debug("ThreadPool", "============ ThreadPool Status =============");
	Log.Debug("ThreadPool", "Active Threads: %u", m_activeThreads.size());
	Log.Debug("ThreadPool", "Suspended Threads: %u", m_freeThreads.size());
	Log.Debug("ThreadPool", "Requested-To-Freed Ratio: %.3f%% (%u/%u)", float( float(_threadsRequestedSinceLastCheck+1) 
        / float(_threadsExitedSinceLastCheck+1) * 100.0f ), _threadsRequestedSinceLastCheck, _threadsExitedSinceLastCheck);
	Log.Debug("ThreadPool", "Eaten Count: %d (negative is bad!)", _threadsEaten);
	Log.Debug("ThreadPool", "============================================");
}

void CThreadPool::IntegrityCheck()
{
	CScopedLock scopedLock(_mutex);
	int32_t gobbled = _threadsEaten;

    if(gobbled < 0)
	{
		// this means we requested more threads than we had in the pool last time.
        // spawn "gobbled" + THREAD_RESERVE extra threads.
		uint32_t new_threads = abs(gobbled) + THREAD_RESERVE;
		_threadsEaten= 0;

		for(uint32_t i = 0; i < new_threads; ++i) {
			StartThread(NULL);
		}

		Log.Debug("ThreadPool", "IntegrityCheck: (gobbled < 0) Spawning %u threads.", new_threads);
	}
	else if(gobbled < THREAD_RESERVE)
	{
        // this means while we didn't run out of threads, we were getting damn low.
		// spawn enough threads to keep the reserve amount up.
		uint32_t new_threads = (THREAD_RESERVE - gobbled);
		for(uint32_t i = 0; i < new_threads; ++i) {
			StartThread(NULL);
		}
		Log.Debug("ThreadPool", "IntegrityCheck: (gobbled <= 5) Spawning %u threads.", new_threads);
	}
	else if(gobbled > THREAD_RESERVE)
	{
		// this means we had "excess" threads sitting around doing nothing.
		// lets kill some of them off.
		uint32_t kill_count = (gobbled - THREAD_RESERVE);
		KillFreeThreads(kill_count);
		_threadsEaten -= kill_count;

		Log.Debug("ThreadPool", "IntegrityCheck: (gobbled > 5) Killing %u threads.", kill_count);
	}
	else
	{
		// perfect! we have the ideal number of free threads.
		Log.Debug("ThreadPool", "IntegrityCheck: Perfect!");
	}

	_threadsExitedSinceLastCheck = 0;
	_threadsRequestedSinceLastCheck = 0;
	_threadsFreedSinceLastCheck = 0;

}

void CThreadPool::KillFreeThreads(uint32_t count)
{
    CScopedLock scopedLock(_mutex);
#ifdef OPEN_THREAD_POOL_DEBUG
	Log.Debug("ThreadPool", "Killing %u excess threads.", count);
#endif
	Thread * t;
	ThreadSet::iterator itr;
	uint32_t i;
	for(i = 0, itr = m_freeThreads.begin(); i < count && itr != m_freeThreads.end(); ++i, ++itr)
	{
		t = *itr;
		t->ExecutionTarget = NULL; 
		t->DeleteAfterExit = true;
		++_threadsToExit;
		t->ControlInterface.Resume();
	}
}

void CThreadPool::Shutdown()
{
    if(true) {
	    CScopedLock scopedLock(_mutex);
	    _bShutdown = true;
	    size_t tcount = m_activeThreads.size() + m_freeThreads.size();		// exit all
#ifdef OPEN_THREAD_POOL_DEBUG
	    Log.Debug("ThreadPool", "Shutting down %u threads.", tcount);
#endif
	    KillFreeThreads((uint32_t)m_freeThreads.size());
	    _threadsToExit += (uint32_t)m_activeThreads.size();

		std::set< Thread* >::iterator itr = m_activeThreads.begin();
        for(; itr != m_activeThreads.end(); ++itr) 
		{
            Thread *t = *itr;
		    if(t->ExecutionTarget) {
			    t->ExecutionTarget->OnShutdown();
			} else {       
                t->ControlInterface.Resume();
			}
	    }
    } // scoped

	for(int i = 0;; ++i)
	{
		CScopedLock scopedLock(_mutex);
		if(m_activeThreads.size() || m_freeThreads.size())
		{
			if( i != 0 && m_freeThreads.size() != 0 )
			{
				/*if we are here then a thread in the free pool checked if it was being shut down just before CThreadPool::Shutdown() was called,
				but called Suspend() just after KillFreeThreads(). All we need to do is to resume it.*/
				Thread * t;
				ThreadSet::iterator itr;
				for(itr = m_freeThreads.begin(); itr != m_freeThreads.end(); ++itr)
				{
					t = *itr;
					t->ControlInterface.Resume();
				}
			}
#ifdef OPEN_THREAD_POOL_DEBUG
			Log.Debug("ThreadPool", "%u active and %u free threads remaining...",
                m_activeThreads.size(), m_freeThreads.size() );
#endif
            Sleep(1);
			continue;
		}
		break;
	}
}

/* this is the only platform-specific code. neat, huh! */
#ifdef WIN32

static unsigned long WINAPI thread_proc(void* param)
{
	Thread * t = (Thread*)param;
    uint32_t tid(0);
    bool ht;
    if(true) {
	    CScopedLock scopedThreadLock(t->SetupMutex);
	    tid = t->ControlInterface.GetId();
	    ht = (t->ExecutionTarget != NULL);
    } // scoped
#ifdef OPEN_THREAD_POOL_DEBUG
	Log.Debug("ThreadPool", "Thread %u started.", t->ControlInterface.GetId());
#endif
	for(;;)
	{
		if(t->ExecutionTarget != NULL)
		{
			if(t->ExecutionTarget->Run()) {
				delete t->ExecutionTarget;
			}
			t->ExecutionTarget = NULL;
		}

		if(!thd::ThreadPool.ThreadExit(t))
		{
#ifdef OPEN_THREAD_POOL_DEBUG
			Log.Debug("ThreadPool", "Thread %u exiting.", tid);
#endif
			break;
		}
		else
		{
#ifdef OPEN_THREAD_POOL_DEBUG
			if(ht) {
				Log.Debug("ThreadPool", "Thread %u waiting for a new task.", tid);
			}
#endif
			// enter "suspended" state. when we return, the threadpool will either tell us to fuk off, or to execute a new task.
			t->ControlInterface.Suspend();
			// after resuming, this is where we will end up. start the loop again, check for tasks, then go back to the threadpool.
		}
	}

	// at this point the t pointer has already been freed, so we can just cleanly exit.
	ExitThread(0);
}

Thread * CThreadPool::StartThread(ThreadBase * ExecutionTarget)
{
    if(true){
        CScopedLock scopedLock(_mutex);
        if(_bShutdown) {
            return NULL;
        }
    } // scoped

	HANDLE h;
	Thread * t = new Thread;
	
	t->DeleteAfterExit = false;
	t->ExecutionTarget = ExecutionTarget;
	//h = (HANDLE)_beginthreadex(NULL, 0, &thread_proc, (void*)t, 0, NULL);

	CScopedLock scopedThreadLock(t->SetupMutex);
	DWORD thread_id(0);
	h = CreateThread(NULL, 0, &thread_proc, (LPVOID)t, 0, (LPDWORD)&thread_id);
	t->ControlInterface.Setup(h, thread_id);
	return t;
}

#else

static void * thread_proc(void * param)
{
	Thread * t = (Thread*)param;

#ifdef OPEN_THREAD_POOL_DEBUG
    if(true){
	    CScopedLock scopedThreadLock(t->SetupMutex);
	    Log.Debug("ThreadPool", "Thread %u started.", t->ControlInterface.GetId());
    } // scoped
#endif

	for(;;)
	{
		if(t->ExecutionTarget != NULL)
		{
			if(t->ExecutionTarget->run()) {
				delete t->ExecutionTarget;
			}

			t->ExecutionTarget = NULL;
		}

		if(!ThreadPool.ThreadExit(t)) {
			break;
		} else {
			// enter "suspended" state. when we return, the threadpool will either tell us to fuk off, or to execute a new task.
			t->ControlInterface.Suspend();
			// after resuming, this is where we will end up. start the loop again, check for tasks, then go back to the threadpool.
		}
	}
	pthread_exit(0);
}

Thread * CThreadPool::StartThread(ThreadBase * ExecutionTarget)
{
	pthread_t target;
	Thread * t = new Thread;
	t->ExecutionTarget = ExecutionTarget;
	t->DeleteAfterExit = false;

	// lock the main mutex, to make sure id generation doesn't get messed up
	CScopedLock scopedLock(_mutex);
    CScopedLock scopedThreadLock(t->SetupMutex);
    pthread_create(&target, NULL, &thread_proc, (void*)t);
    t->ControlInterface.Setup(target);
    pthread_detach(target);
	return t;
}

#endif


