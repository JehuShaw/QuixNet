/*
 * File:   ILock.h
 * Author: Jehu Shaw
 *
 */

#ifndef __ILOCK_H_
#define __ILOCK_H_

#include "Common.h"

namespace thd {

/** An abstract base class for synchronization primitives.
 */
class ILock
{
  public:

  /** Destructor. */
  virtual ~ILock() { }

  /** %Lock operation. */
  virtual void lock() throw() = 0;

  /** Unlock operation. */
  virtual void unlock() throw() = 0;
};

}; // namespace thd

#endif // __ILOCK_H_

/* end of header file */
