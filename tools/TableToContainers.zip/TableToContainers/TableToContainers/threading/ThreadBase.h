/*
 * File:   ThreadBase.h
 * Author: Jehu Shaw
 *
 */

#ifndef _THREAD_BASE_H
#define _THREAD_BASE_H

namespace thd {

class SERVER_DECL ThreadBase
{
public:
	ThreadBase() {}
	virtual ~ThreadBase() {}
	virtual bool Run() = 0;
	virtual void OnShutdown() {}

protected:
#ifdef WIN32
	HANDLE THREAD_HANDLE;
#else
	pthread_t THREAD_HANDLE;
#endif
};

}

#endif

