/*
 * File:   ThreadPool.h
 * Author: Jehu Shaw
 *
 */

#ifndef __THREADPOOL_H
#define __THREADPOOL_H

#include "Common.h"

namespace thd {

#ifdef WIN32

class SERVER_DECL ThreadController
{
	HANDLE hThread;
	uint32_t thread_id;
    HANDLE sem;
public:
	ThreadController() : hThread(NULL), thread_id(0), sem(NULL) {}

	void Setup(HANDLE h, uint32_t threadId)
	{
		hThread = h;
		thread_id = threadId;
        sem = CreateSemaphore(NULL, 0, 2147483647, NULL);
	}

	void Suspend()
	{
		// We can't be suspended by someone else. That is a big-no-no and will lead to crashes.
		ASSERT(GetCurrentThreadId() == thread_id);

        WaitForSingleObject(sem, INFINITE);
	}

	bool Resume()
	{
		// This SHOULD be called by someone else.
		ASSERT(GetCurrentThreadId() != thread_id);

		return ReleaseSemaphore(sem, 1, NULL) != FALSE;
	}

	void Join()
	{
		WaitForSingleObject(hThread, INFINITE);
	}

	uint32_t GetId() { return thread_id; }
};

#else
#ifndef HAVE_DARWIN
#include <semaphore.h>

class ThreadController
{
	sem_t sem;
	pthread_t handle;
public:
	void Setup(pthread_t h)
	{
		handle = h;
		sem_init(&sem, PTHREAD_PROCESS_PRIVATE, 0);
	}
	~ThreadController()
	{
		sem_destroy(&sem);
	}

	void Suspend()
	{
		ASSERT(pthread_equal(pthread_self(), handle));
		sem_wait(&sem);
	}

	bool Resume()
	{
		ASSERT(!pthread_equal(pthread_self(), handle));
		return sem_post(&sem) == 0;
	}

	void Join()
	{
		// waits until the thread finishes then returns
		pthread_join(handle, NULL);
	}

	INLINE uint32_t GetId() { 
#if PLATFORM == PLATFORM_APPLE
		return (uint32_t)pthread_mach_thread_np(handle);
#else
		return (uint32_t)handle;
#endif
	}
};

#else

class ThreadController
{
	pthread_cond_t cond;
	pthread_mutex_t mutex;
	pthread_t handle;
public:
	void Setup(pthread_t h)
	{
		handle = h;
		pthread_mutex_init(&mutex,NULL);
		pthread_cond_init(&cond,NULL);
	}
	~ThreadController()
	{
		pthread_mutex_destroy(&mutex);
		pthread_cond_destroy(&cond);
	}
	void Suspend()
	{
		pthread_cond_wait(&cond, &mutex);
	}
	bool Resume()
	{
		return pthread_cond_signal(&cond) == 0;
	}
	void Join()
	{
		pthread_join(handle,NULL);
	}
	INLINE uint32_t GetId() { 
#if PLATFORM == PLATFORM_APPLE
		return (uint32_t)pthread_mach_thread_np(handle);
#else
		return (uint32_t)handle;
#endif
	}
};

#endif

#endif


struct SERVER_DECL Thread
{
	ThreadBase * ExecutionTarget;
	ThreadController ControlInterface;
	CMutex SetupMutex;
	bool DeleteAfterExit;
};

typedef std::set<Thread*> ThreadSet;
#define THREAD_RESERVE 10

class SERVER_DECL CThreadPool
{
	int GetNumCpus();

	uint32_t _threadsRequestedSinceLastCheck;
	uint32_t _threadsFreedSinceLastCheck;
	uint32_t _threadsExitedSinceLastCheck;
	uint32_t _threadsToExit;
	int32_t _threadsEaten;
	CMutex _mutex;
	bool _bShutdown;

    ThreadSet m_activeThreads;
	ThreadSet m_freeThreads;

public:
	CThreadPool();

	// call every 2 minutes or so.
	void IntegrityCheck();

	// call at startup
	void Startup(int tCount = THREAD_RESERVE);

	// shutdown all threads
	void Shutdown();
	
	// return true - suspend ourselves, and wait for a future task.
	// return false - exit, we're shutting down or no longer needed.
	bool ThreadExit(Thread * t);

	// grabs/spawns a thread, and tells it to execute a task.
	void ExecuteTask(ThreadBase * ExecutionTarget);

	// prints some neat debug stats
	void ShowStats();

	// kills x free threads
	void KillFreeThreads(uint32_t count);

	// resets the gobble counter
	INLINE void Gobble() { _threadsEaten = (int32_t)m_freeThreads.size(); }

	// gets active thread count
	INLINE uint32_t GetActiveThreadCount() { return (uint32_t)m_activeThreads.size(); }

	// gets free thread count
	INLINE uint32_t GetFreeThreadCount() { return (uint32_t)m_freeThreads.size(); }

	// creates a thread, returns a handle to it.
	Thread * StartThreadEx(ThreadBase * ExecutionTarget) {
		Thread * t = StartThread(ExecutionTarget);
        if(NULL != t) {
		    CScopedLock scopedLock(_mutex);
		    m_activeThreads.insert(t);
        }
		return t;
	}

private:
	Thread * StartThread(ThreadBase * ExecutionTarget);
};

extern SERVER_DECL CThreadPool ThreadPool;

}

#endif
