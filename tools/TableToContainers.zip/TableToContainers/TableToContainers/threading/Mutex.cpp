#include "Common.h"
#include "Mutex.h"

using namespace thd;

#ifdef WIN32

/* Windows Critical Section Implementation */
CMutex::CMutex() { InitializeCriticalSection(&cs); }
CMutex::~CMutex() { DeleteCriticalSection(&cs); }

#else

/* this is done slightly differently on bsd-variants */
#if defined(__FreeBSD__) ||  defined(__APPLE_CC__) || defined(__OpenBSD__)
#define recursive_mutex_flag PTHREAD_MUTEX_RECURSIVE
#else
#define recursive_mutex_flag PTHREAD_MUTEX_RECURSIVE_NP
#endif

/* Linux mutex implementation */
bool CMutex::attr_initalized = false;
pthread_mutexattr_t CMutex::attr;

CMutex::CMutex()
{
	if(!attr_initalized) {
		attr_initalized = true;
		pthread_mutexattr_init(&attr);
		pthread_mutexattr_settype(&attr, recursive_mutex_flag);
	}

	pthread_mutex_init(&mutex, &attr);
}

CMutex::~CMutex() { pthread_mutex_destroy(&mutex); }

#endif
