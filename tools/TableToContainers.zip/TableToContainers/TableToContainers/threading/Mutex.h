/*
 * File:   Mutex.h
 * Author: Jehu Shaw
 *
 */

#ifndef __MUTEX_H_
#define __MUTEX_H_

#include "Common.h"
#include "ILock.h"

namespace thd {

class SERVER_DECL CMutex : public ILock
{
public:

	/** Initializes a mutex class, with InitializeCriticalSection / pthread_mutex_init
	 */
	CMutex();

	/** Deletes the associated critical section / mutex
	 */
	~CMutex();

	/** Lock this mutex. If it cannot be acquired immediately, it will block.
	 */
	void lock() throw()
	{
#if COMPILER == COMPILER_MICROSOFT
		EnterCriticalSection(&cs);
#else
		pthread_mutex_lock(&mutex);
#endif
	}

	/** Unlock this mutex. No error checking performed
	 */
	void unlock() throw()
	{
#if COMPILER == COMPILER_MICROSOFT
		LeaveCriticalSection(&cs);
#else
		pthread_mutex_unlock(&mutex);
#endif
	}

	/** Attempts to acquire this mutex. If it cannot be acquired (held by another thread)
	 * it will return false.
	 * @return false if cannot be acquired, true if it was acquired.
	 */
	bool tryLock() throw()
	{
#if COMPILER == COMPILER_MICROSOFT
		return (TryEnterCriticalSection(&cs) == TRUE ? true : false);
#else
		return (pthread_mutex_trylock(&mutex) == 0);
#endif
	}

protected:
#if COMPILER == COMPILER_MICROSOFT
	/** Critical section used for system calls
	 */
	CRITICAL_SECTION cs;

#else
	/** Static mutex attribute
	 */
	static bool attr_initalized;
	static pthread_mutexattr_t attr;

	/** pthread struct used in system calls
	 */
	pthread_mutex_t mutex;
#endif
};

}

#endif /*__MUTEX_H_ */

