
// TableToContainersDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "TableToContainers.h"
#include "TableToContainersDlg.h"
#include "afxdialogex.h"

#include "SeparatedStream.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define DEST_TABLE_NAME "containers"

const char* informationSchema = "information_schema";
const char* sql_databases = "SELECT `SCHEMA_NAME` FROM `SCHEMATA`;";
const char* sql_tables = "SELECT `TABLE_NAME` FROM `TABLES` WHERE `TABLE_SCHEMA` = \'%s\' COLLATE utf8_general_ci;";
const char* sql_config_option = "SELECT `name`,`value` FROM `%s`.`config_options`;";
const char* sql_fields = "SELECT `COLUMN_NAME` FROM `COLUMNS` WHERE `TABLE_SCHEMA` = \'%s\' COLLATE utf8_general_ci  AND `TABLE_NAME` = \'%s\' COLLATE utf8_general_ci ORDER BY `ORDINAL_POSITION` ASC;";
const char* sql_replace_container = "REPLACE INTO `%s`.`containers` (`name`,`db_schema`,`db_table`,`key_columns`,`value_columns`,`flags`,`cas_column`,`expire_time_column`,`unique_idx_name_on_key`) VALUES (\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\');";
const char* sql_insert_container = "INSERT INTO `%s`.`containers` (`name`,`db_schema`,`db_table`,`key_columns`,`value_columns`,`flags`,`cas_column`,`expire_time_column`,`unique_idx_name_on_key`) VALUES (\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\');";
const char* sql_key_columns = "SELECT `COLUMN_NAME`,`CONSTRAINT_NAME` FROM `KEY_COLUMN_USAGE` WHERE `TABLE_SCHEMA` = \'%s\' COLLATE utf8_general_ci  AND `TABLE_NAME` = \'%s\' COLLATE utf8_general_ci ORDER BY `ORDINAL_POSITION` ASC;";

enum {
	ADD_CONTAINER_FAIL,
	ADD_CONTAINER_SUCCESS,
	ADD_CONTAINER_SQL_NULL,
	ADD_CONTAINER_CANNT_FIND_DEST_TABLE,
	ADD_CONTAINER_EMPTY_NAME,
	ADD_CONTAINER_EMPTY_DATABASE,
	ADD_CONTAINER_EMPTY_TABLE,
	ADD_CONTAINER_EMPTY_KEY,
	ADD_CONTAINER_EMPTY_CAS,
};

// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CTableToContainersDlg �Ի���




CTableToContainersDlg::CTableToContainersDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CTableToContainersDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTableToContainersDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT4, m_edtPassword);
	DDX_Control(pDX, IDC_EDIT1, m_edtPort);
	DDX_Control(pDX, IDC_IPADDRESS2, m_edtHost);
	DDX_Control(pDX, IDC_EDIT3, m_edtUser);
	DDX_Control(pDX, IDC_EDIT2, m_edtState);
	DDX_Control(pDX, IDC_COMBO1, m_comDatabases);
	DDX_Control(pDX, IDC_COMBO2, m_comTables);
	DDX_Control(pDX, IDC_COMBO3, m_desDatabases);
	DDX_Control(pDX, IDC_BUTTON3, m_btnConnect);
	DDX_Control(pDX, IDC_EDIT5, m_desTable);
	DDX_Control(pDX, IDC_COMBO4, m_comFlags);
	DDX_Control(pDX, IDC_COMBO5, m_comCas);
	DDX_Control(pDX, IDC_COMBO6, m_comExpire);
	DDX_Control(pDX, IDC_EDIT6, m_edtName);
	DDX_Control(pDX, IDC_COMBO8, m_comKeyType);
	DDX_Control(pDX, IDC_EDIT7, m_edtKeys);
	DDX_Control(pDX, IDC_EDIT8, m_edtValues);
	DDX_Control(pDX, IDC_COMBO7, m_comExcludeKey);
	DDX_Control(pDX, IDC_COMBO9, m_comIncludeKey);
}

BEGIN_MESSAGE_MAP(CTableToContainersDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON3, &CTableToContainersDlg::OnBnClickedButton3)
//	ON_EN_CHANGE(IDC_EDIT4, &CTableToContainersDlg::OnEnChangeEdit4)
ON_CBN_SELCHANGE(IDC_COMBO1, &CTableToContainersDlg::OnCbnSelchangeCombo1)
ON_CBN_SELCHANGE(IDC_COMBO3, &CTableToContainersDlg::OnCbnSelchangeCombo3)
ON_CBN_SELCHANGE(IDC_COMBO2, &CTableToContainersDlg::OnCbnSelchangeCombo2)
ON_BN_CLICKED(IDC_BUTTON1, &CTableToContainersDlg::OnBnClickedButton1)
ON_BN_CLICKED(IDC_BUTTON2, &CTableToContainersDlg::OnBnClickedButton2)
ON_BN_CLICKED(IDC_BUTTON4, &CTableToContainersDlg::OnBnClickedButton4)
//ON_EN_CHANGE(IDC_EDIT8, &CTableToContainersDlg::OnEnChangeEdit8)
ON_CBN_SELCHANGE(IDC_COMBO4, &CTableToContainersDlg::OnCbnSelchangeCombo4)
ON_CBN_SELCHANGE(IDC_COMBO5, &CTableToContainersDlg::OnCbnSelchangeCombo5)
ON_CBN_SELCHANGE(IDC_COMBO6, &CTableToContainersDlg::OnCbnSelchangeCombo6)
ON_BN_CLICKED(IDC_BUTTON5, &CTableToContainersDlg::OnBnClickedButton5)
ON_BN_CLICKED(IDC_BUTTON6, &CTableToContainersDlg::OnBnClickedButton6)
END_MESSAGE_MAP()


// CTableToContainersDlg ��Ϣ��������

BOOL CTableToContainersDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	m_nFlagsIdx = -1;
	m_nCasIdx = -1;
	m_nExpireIdx = -1;
	m_nBlankIdx = -1;
	m_cSeparator = '|';
	char m_cTableMapDelimiter = '.';
	m_bFindDestTable = false;
	m_edtUser.SetWindowText("root");
	m_edtPassword.SetPasswordChar('*');
	m_edtHost.SetAddress(127,0,0,1);
	m_edtPort.SetWindowText("3306");
	m_edtState.SetWindowText("Please set info and click connect button.");

	m_comKeyType.SetCurSel(m_comKeyType.AddString("PRIMARY"));

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CTableToContainersDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CTableToContainersDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CTableToContainersDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CTableToContainersDlg::OnBnClickedButton3()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_pDatabase = db::Database::CreateDatabaseInterface();
	CString strHost, strPort, strUser, strPassword;
	m_edtHost.GetWindowText(strHost);
	m_edtPort.GetWindowText(strPort);
	m_edtUser.GetWindowText(strUser);
	m_edtPassword.GetWindowText(strPassword);
	if(m_pDatabase->Initialize(strHost.GetString(),
		atoi(strPort.GetString()),
		strUser.GetString(),
		strPassword.GetString(),
		informationSchema,
		3, 3)) 
	{
		m_edtState.SetWindowText("Connect database success.");
		LoadDatabases();
		
	} else {
		m_edtState.SetWindowText("Connect database fail.");
	}
}

void CTableToContainersDlg::LoadDatabases()
{
	if(m_pDatabase.IsInvalid()) {
		MessageBox("Connect database first !");
		return;
	}
	if(m_comDatabases.GetCount() > 0) {
		m_comDatabases.ResetContent();
	}
	if(m_desDatabases.GetCount() > 0) {
		m_desDatabases.ResetContent();
	}

	util::CAutoPointer<db::QueryResult> pQueryResult(
		m_pDatabase->QueryNA(sql_databases));
	if(pQueryResult.IsInvalid()) {
		return;
	}
	
	do {
		db::Field* pField = pQueryResult->Fetch();
		if(NULL != pField) {
			const char* szDatabaseName = pField[0].GetString();
			m_comDatabases.AddString(szDatabaseName);
			m_desDatabases.AddString(szDatabaseName);
		} else {
			Log.Error("CTableToContainersDlg","@LoadDatabases NULL == pField");
		}
	} while(pQueryResult->NextRow());

	if(m_comDatabases.GetCount() > 0) {
		m_comDatabases.SetCurSel(0);
		SelectSrcDatabase(0);
	}
	if(m_desDatabases.GetCount() > 0) {
		m_desDatabases.SetCurSel(0);
		SelectDestDatabase(0);
	}
	UpdateValueString();
}

void CTableToContainersDlg::SelectSrcDatabase( int nIdx )
{
	if(m_comTables.GetCount() > 0) {
		m_comTables.ResetContent();
	}
	if(m_comFlags.GetCount() > 0) {
		m_comFlags.ResetContent();
	}
	if(m_comCas.GetCount() > 0) {
		m_comCas.ResetContent();
	}
	if(m_comExpire.GetCount() > 0) {
		m_comExpire.ResetContent();
	}
	m_edtKeys.SetWindowText("");
	if(!m_keyColumns.empty()) {
		m_keyColumns.clear();
	}
	if(!m_constraintName.IsEmpty()) {
		m_constraintName.Empty();
	}

	if(m_comExcludeKey.GetCount() > 0) {
		m_comExcludeKey.ResetContent();
	}

	if(m_comIncludeKey.GetCount() > 0) {
		m_comIncludeKey.ResetContent();
	}

	CString strDatabase;
	m_comDatabases.GetLBText(nIdx, strDatabase);
	if(strDatabase.IsEmpty()) {
		return;
	}
	
	util::CAutoPointer<db::QueryResult> pQueryResult(
		m_pDatabase->Query(sql_tables, (const char*)strDatabase.GetString()));
	if(pQueryResult.IsInvalid()) {
		return;
	}
	
	do {
		db::Field* pField = pQueryResult->Fetch();
		if(NULL != pField) {
			const char* szTableName = pField[0].GetString();
			m_comTables.AddString(szTableName);
		} else {
			Log.Error("CTableToContainersDlg","@SelectSrcDatabase NULL == pField");
		}
	} while(pQueryResult->NextRow());
	if(m_comTables.GetCount() > 0) {
		m_comTables.SetCurSel(0);
		CString strTable;
		m_comTables.GetLBText(0, strTable);
		if(!strTable.IsEmpty()) {
			LoadSrcKeyFields(strDatabase, strTable);
			LoadSrcFields(strDatabase, strTable);
		}
	}
}

void CTableToContainersDlg::SelectDestDatabase( int nIdx )
{
	m_bFindDestTable = false;
	CString strDatabase;
	m_desDatabases.GetLBText(nIdx, strDatabase);
	if(strDatabase.IsEmpty()) {
		return;
	}

	util::CAutoPointer<db::QueryResult> pQueryResult(
		m_pDatabase->Query(sql_tables, (const char*)strDatabase.GetString()));
	if(pQueryResult.IsInvalid()) {
		return;
	}
	
	do {
		db::Field* pField = pQueryResult->Fetch();
		if(NULL != pField) {
			const char* szTableName = pField[0].GetString();
			if(strcmp(DEST_TABLE_NAME,szTableName) == 0) {
				m_bFindDestTable = true;
				break;
			}
		} else {
			Log.Error("CTableToContainersDlg","@SelectDestDatabase NULL == pField");
		}
	} while(pQueryResult->NextRow());
	if(m_bFindDestTable) {
		GetConfigOptions(strDatabase);
		m_desTable.SetWindowText(DEST_TABLE_NAME);
	}else {
		m_desTable.SetWindowText("Not find "DEST_TABLE_NAME);
	}
}

void CTableToContainersDlg::GetConfigOptions(const CString& strDatabase)
{
	util::CAutoPointer<db::QueryResult> pQueryResult(
		m_pDatabase->Query(sql_config_option, (const char*)strDatabase.GetString()));
	if(pQueryResult.IsInvalid()) {
		Log.Error("CCacheDBManager","@GetConfigOptions %s Fail !", sql_config_option);
		return;
	}
	if(pQueryResult->GetFieldCount() != 2) {
		Log.Error("CTableToContainersDlg","&GetConfigOptions %s"
			" pQueryResult->GetFieldCount() != 2", sql_config_option);
		assert(false);
		return;
	}
	
	do {
		db::Field* pField = pQueryResult->Fetch();
		if(NULL != pField) {
			if(strcmp(pField[0].GetString(),"separator") == 0) {
				m_cSeparator = *pField[1].GetString();
			} else if(strcmp(pField[0].GetString(),"table_map_delimiter") == 0){
				m_cTableMapDelimiter = *pField[1].GetString();
			}
		} else {
			Log.Error("CTableToContainersDlg","@GetConfigOptions NULL == pField");
		}
	} while(pQueryResult->NextRow());
}

void CTableToContainersDlg::OnCbnSelchangeCombo1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nIdx = m_comDatabases.GetCurSel();
	SelectSrcDatabase(nIdx);
	UpdateValueString();
}


void CTableToContainersDlg::OnCbnSelchangeCombo3()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nIdx = m_desDatabases.GetCurSel();
	SelectDestDatabase(nIdx);
}

void CTableToContainersDlg::LoadSrcFields(const CString& strDatabase, const CString& strTable)
{
	if(m_comFlags.GetCount() > 0) {
		m_comFlags.ResetContent();
	}
	if(m_comCas.GetCount() > 0) {
		m_comCas.ResetContent();
	}
	if(m_comExpire.GetCount() > 0) {
		m_comExpire.ResetContent();
	}

	util::CAutoPointer<db::QueryResult> pQueryResult(
		m_pDatabase->Query(sql_fields,
		(const char*)strDatabase.GetString(),
		(const char*)strTable.GetString()));
	if(pQueryResult.IsInvalid()) {
		return;
	}

	int nFlagsIdx = -1;
	int nCasIdx = -1;
	int nExpireIdx = -1;
	m_comFlags.AddString("");
	m_nBlankIdx = m_comCas.AddString("");
	m_comExpire.AddString("");
	do {
		db::Field* pField = pQueryResult->Fetch();
		if(NULL != pField) {
			const char* szFieldName = pField[0].GetString();
			std::string strField(szFieldName);
			StrToLower(strField);
			if(std::string::npos != strField.find("flags")) {
				nFlagsIdx = m_comFlags.AddString(szFieldName);
				m_comCas.AddString(szFieldName);
				m_comExpire.AddString(szFieldName);
				continue;
			} else if(std::string::npos != strField.find("cas")) {
				nCasIdx = m_comCas.AddString(szFieldName);
				m_comFlags.AddString(szFieldName);
				m_comExpire.AddString(szFieldName);
				continue;
			} else if(std::string::npos != strField.find("expire")) {
				nExpireIdx = m_comExpire.AddString(szFieldName);
				m_comFlags.AddString(szFieldName);
				m_comCas.AddString(szFieldName);
				continue;
			}
			m_comFlags.AddString(szFieldName);
			m_comCas.AddString(szFieldName);
			m_comExpire.AddString(szFieldName);
		} else {
			Log.Error("CTableToContainersDlg","@LoadSrcFields NULL == pField");
		}
	} while(pQueryResult->NextRow());

	if(nExpireIdx > -1) {
		m_nExpireIdx = nExpireIdx;
		m_comExpire.SetCurSel(nExpireIdx);
	}

	if(nCasIdx > -1) {
		m_nCasIdx = nCasIdx;
		m_comCas.SetCurSel(nCasIdx);
	}

	if(nFlagsIdx > -1) {
		m_nFlagsIdx = nFlagsIdx;
		m_comFlags.SetCurSel(nFlagsIdx);
	}
}


void CTableToContainersDlg::OnCbnSelchangeCombo2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int ndbIdx = m_comDatabases.GetCurSel();
	CString strDatabase;
	m_comDatabases.GetLBText(ndbIdx, strDatabase);

	int ntblIdx = m_comTables.GetCurSel();
	CString strTable;
	m_comTables.GetLBText(ntblIdx, strTable);
	if(strDatabase.IsEmpty() || strTable.IsEmpty()) {
		return;
	}
	LoadSrcKeyFields(strDatabase, strTable);
	LoadSrcFields(strDatabase, strTable);
	UpdateValueString();
}


void CTableToContainersDlg::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nResult = AddContainerValue(sql_replace_container);
	switch(nResult) {
	case ADD_CONTAINER_CANNT_FIND_DEST_TABLE:
		MessageBox("Can't find the table \"containers\".");
		break;
	case ADD_CONTAINER_EMPTY_NAME:
		MessageBox("The name must be set !");
		break;
	case ADD_CONTAINER_SUCCESS:
		MessageBox("Replace a record of containers success !");
		break;
	case ADD_CONTAINER_FAIL:
		MessageBox("Replace a record of containers fail !");
		break;
	case ADD_CONTAINER_EMPTY_KEY:
		MessageBox("The key is empty !");
		break;
	case ADD_CONTAINER_EMPTY_DATABASE:
		MessageBox("The name of database is empty !");
		break;
	case ADD_CONTAINER_EMPTY_TABLE:
		MessageBox("The name of table is empty !");
		break;
	case ADD_CONTAINER_EMPTY_CAS:
		MessageBox("The CAS is empty !");
		break;
	default:
		break;
	}
}


void CTableToContainersDlg::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nResult = AddContainerValue(sql_insert_container);
	switch(nResult) {
	case ADD_CONTAINER_CANNT_FIND_DEST_TABLE:
		MessageBox("Can't find the table \"containers\".");
		break;
	case ADD_CONTAINER_EMPTY_NAME:
		MessageBox("The name must be set !");
		break;
	case ADD_CONTAINER_SUCCESS:
		MessageBox("Insert a record of containers success !");
		break;
	case ADD_CONTAINER_FAIL:
		MessageBox("Insert a record of containers fail !");
		break;
	case ADD_CONTAINER_EMPTY_KEY:
		MessageBox("The key is empty !");
		break;
	case ADD_CONTAINER_EMPTY_DATABASE:
		MessageBox("The name of database is empty !");
		break;
	case ADD_CONTAINER_EMPTY_TABLE:
		MessageBox("The name of table is empty !");
		break;
	case ADD_CONTAINER_EMPTY_CAS:
		MessageBox("The CAS is empty !");
		break;
	default:
		break;
	}
}

int CTableToContainersDlg::AddContainerValue(const char* sql)
{
	if(NULL == sql) {
		return ADD_CONTAINER_SQL_NULL;
	}
	if(!m_bFindDestTable) {
		return ADD_CONTAINER_CANNT_FIND_DEST_TABLE;
	}
	CString strName;
	m_edtName.GetWindowText(strName);
	if(strName.IsEmpty()) {
		return ADD_CONTAINER_EMPTY_NAME;
	}

	CString strDestDatabase;
	if(m_desDatabases.GetCount() > 0) {
		int nDesIdx = m_desDatabases.GetCurSel();
		m_desDatabases.GetLBText(nDesIdx, strDestDatabase);
	}

	CString strDatabase;
	if(m_comDatabases.GetCount() > 0) {
		int nDatabaseIdx = m_comDatabases.GetCurSel();
		m_comDatabases.GetLBText(nDatabaseIdx, strDatabase);
	}
	if(strDatabase.IsEmpty()) {
		return ADD_CONTAINER_EMPTY_DATABASE;
	}

	CString strTable;
	if(m_comTables.GetCount() > 0) {
		int nTableIdx = m_comTables.GetCurSel();
		m_comTables.GetLBText(nTableIdx, strTable);
	}
	if(strTable.IsEmpty()) {
		return ADD_CONTAINER_EMPTY_TABLE;
	}

	CString strKey;
	m_edtKeys.GetWindowText(strKey);
	if(strKey.IsEmpty()) {
		return ADD_CONTAINER_EMPTY_KEY;
	}

	CString strFlags;
	if(m_comFlags.GetCount() > 0) {
		int nFlagsIdx = m_comFlags.GetCurSel();
		m_comFlags.GetLBText(nFlagsIdx, strFlags);
	}

	CString strCas;
	if(m_comCas.GetCount() > 0) {
		int nCasIdx = m_comCas.GetCurSel();
		m_comCas.GetLBText(nCasIdx, strCas);
	}
	if(strCas.IsEmpty()) {
		return ADD_CONTAINER_EMPTY_CAS;
	}

	CString strExpire;
	if(m_comExpire.GetCount() > 0) {
		int nExpireIdx = m_comExpire.GetCurSel();
		m_comExpire.GetLBText(nExpireIdx, strExpire);
	}

	CString strKeyType;
	m_comKeyType.GetWindowText(strKeyType);
	if(strKeyType.IsEmpty()) {
		m_comKeyType.GetLBText(0, strKeyType);
	}

	CString strValues;
	m_edtValues.GetWindowText(strValues);

	if(m_pDatabase->WaitExecute(sql,
		(const char*)strDestDatabase.GetString(),
		(const char*)strName.GetString(),
		(const char*)strDatabase.GetString(),
		(const char*)strTable.GetString(),
		(const char*)strKey.GetString(),
		(const char*)strValues.GetString(),
		(const char*)strFlags.GetString(),
		(const char*)strCas.GetString(),
		(const char*)strExpire.GetString(),
		(const char*)strKeyType.GetString()
		)) 
	{		
		return ADD_CONTAINER_SUCCESS;
	} else {
		return ADD_CONTAINER_FAIL;
	}
}

void CTableToContainersDlg::LoadSrcKeyFields(const CString& strDatabase, const CString& strTable)
{
	if(!m_keyColumns.empty()) {
		m_keyColumns.clear();
	}
	if(!m_constraintName.IsEmpty()) {
		m_constraintName.Empty();
	}
	m_edtKeys.SetWindowText("");
	m_comKeyType.SetWindowText("");

	if(m_comExcludeKey.GetCount() > 0) {
		m_comExcludeKey.ResetContent();
	}

	if(m_comIncludeKey.GetCount() > 0) {
		m_comIncludeKey.ResetContent();
	}

	util::CAutoPointer<db::QueryResult> pQueryResult(
		m_pDatabase->Query(sql_key_columns,
		(const char*)strDatabase.GetString(),
		(const char*)strTable.GetString()));
	if(pQueryResult.IsInvalid()) {
		return;
	}
	db::Field* pField = pQueryResult->Fetch();
	if(NULL != pField) {
		m_constraintName = pField[1].GetString();
	} else {
		Log.Error("CTableToContainersDlg","@LoadKeyFields1 NULL == pField");
	}
	util::CSeparatedStream separated(m_cSeparator);
	CString strFieldName;
	do {
		pField = pQueryResult->Fetch();
		if(NULL != pField) {
			const char* szFieldName = pField[0].GetString();
			if(NULL != szFieldName) {
				strFieldName = szFieldName;
				m_keyColumns.push_back(strFieldName);
				m_comExcludeKey.AddString(strFieldName);
				separated << szFieldName;
			}
		} else {
			Log.Error("CTableToContainersDlg","@LoadKeyFields2 NULL == pField");
		}
	} while(pQueryResult->NextRow());
	separated.endLine();
	m_edtKeys.SetWindowText(separated.str());
	m_comKeyType.SetWindowText(m_constraintName.GetString());
	if(m_comExcludeKey.GetCount() > 0) {
		m_comExcludeKey.SetCurSel(0);
	}
}

bool CTableToContainersDlg::ExcludeKeyFields(const CString& field)
{
	int nSize = m_comExcludeKey.GetCount();
	if(nSize > 0) {
		int nIndex = m_comExcludeKey.FindStringExact(0, field);
		if(nIndex > -1) {
			return true;
		}
	}
	return false;
}


void CTableToContainersDlg::OnBnClickedButton4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if(m_pDatabase.IsInvalid()) {
		MessageBox("Connect database first!");
		return;
	}
	LoadDatabases();
}

void CTableToContainersDlg::UpdateValueString()
{
	CString strValue;
	util::CSeparatedStream separated(m_cSeparator);
	int nFlagsIdx = m_comFlags.GetCurSel();
	int nCasIdx = m_comCas.GetCurSel();
	int nExpireIdx = m_comExpire.GetCurSel();
	int nSize = m_comCas.GetCount();
	for(int i = 0; i < nSize; ++i) {

		if(m_nBlankIdx == i
			|| nFlagsIdx == i 
			|| nCasIdx == i 
			|| nExpireIdx == i) {
			continue;
		}
		m_comCas.GetLBText(i, strValue);
		if(ExcludeKeyFields(strValue)) {
			continue;
		}
		separated << (const char*)strValue.GetString();
	}
	separated.endLine();

	m_edtValues.SetWindowText(separated.str());
}



void CTableToContainersDlg::OnCbnSelchangeCombo4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nFlagsIdx = m_comFlags.GetCurSel();
	CString strKeys;
	m_edtKeys.GetWindowText(strKeys);
	CString strFlags;
	m_comFlags.GetLBText(nFlagsIdx, strFlags);
	int nFindIdx = strKeys.Find(strFlags);
	if(nFlagsIdx == m_nExpireIdx 
		|| nFlagsIdx == m_nCasIdx 
		|| nFindIdx > -1) 
	{
		m_comFlags.SetCurSel(m_nBlankIdx);
		m_nFlagsIdx = m_nBlankIdx;
	} else {
		m_nFlagsIdx = nFlagsIdx;
	}
	UpdateValueString();
}


void CTableToContainersDlg::OnCbnSelchangeCombo5()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nCasIdx = m_comCas.GetCurSel();
	CString strKeys;
	m_edtKeys.GetWindowText(strKeys);
	CString strCas;
	m_comCas.GetLBText(nCasIdx, strCas);
	int nFindIdx = strKeys.Find(strCas);
	if(nCasIdx == m_nExpireIdx 
		|| nCasIdx == m_nFlagsIdx 
		|| nFindIdx > -1) 
	{
		m_comCas.SetCurSel(m_nBlankIdx);
		m_nCasIdx = m_nBlankIdx;
	} else {
		m_nCasIdx = nCasIdx;
	}
	UpdateValueString();
}


void CTableToContainersDlg::OnCbnSelchangeCombo6()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nExpireIdx = m_comExpire.GetCurSel();
	CString strKeys;
	m_edtKeys.GetWindowText(strKeys);
	CString strExpire;
	m_comExpire.GetLBText(nExpireIdx, strExpire);
	int nFindIdx = strKeys.Find(strExpire);
	if(nExpireIdx == m_nCasIdx 
		|| nExpireIdx == m_nFlagsIdx 
		|| nFindIdx > -1) 
	{
		m_comExpire.SetCurSel(m_nBlankIdx);
		m_nExpireIdx = m_nBlankIdx;
	} else {
		m_nExpireIdx = nExpireIdx;
	}
	UpdateValueString();
}


void CTableToContainersDlg::OnBnClickedButton5()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if(m_comExcludeKey.GetCount() < 1) {
		return;
	}
	CString strKey;
	int nIdx = m_comExcludeKey.GetCurSel();
	m_comExcludeKey.GetLBText(nIdx, strKey);
	m_comExcludeKey.DeleteString(nIdx);
	int nCurCount = m_comExcludeKey.GetCount();
	if(nCurCount < 1) {
		m_comExcludeKey.SetCurSel(-1);
	} else {
		if(nIdx < nCurCount) {
			m_comExcludeKey.SetCurSel(nIdx);
		} else {
			m_comExcludeKey.SetCurSel(nCurCount - 1);
		}
	}

	m_comIncludeKey.AddString(strKey);
	if(m_comIncludeKey.GetCurSel() < 0) {
		m_comIncludeKey.SetCurSel(0);
	}
	UpdateValueString();
}


void CTableToContainersDlg::OnBnClickedButton6()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if(m_comIncludeKey.GetCount() < 1) {
		return;
	}
	CString strKey;
	int nIdx = m_comIncludeKey.GetCurSel();
	m_comIncludeKey.GetLBText(nIdx, strKey);
	m_comIncludeKey.DeleteString(nIdx);
	int nCurCount = m_comIncludeKey.GetCount();
	if(nCurCount < 1) {
		m_comIncludeKey.SetCurSel(-1);
	} else {
		if(nIdx < nCurCount) {
			m_comIncludeKey.SetCurSel(nIdx);
		} else {
			m_comIncludeKey.SetCurSel(nCurCount - 1);
		}
	}

	m_comExcludeKey.AddString(strKey);
	if(m_comExcludeKey.GetCurSel() < 0) {
		m_comExcludeKey.SetCurSel(0);
	}
	UpdateValueString();
}
