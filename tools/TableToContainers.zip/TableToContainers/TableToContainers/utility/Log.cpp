/*
 * File:   Log.cpp
 * Author: Jehu Shaw
 *
 */

#include "Log.h"
#include <io.h>
#include <direct.h>
#include "AtomicLock.h"
#include "SpinLock.h"

#include <cstdarg>
#if defined( __WIN32__) || defined( WIN32 ) || defined ( _WIN32 )
#include <process.h>
#else
#include <pthread.h>
#endif

using namespace std;

namespace util {

string FormatOutputString(const char * Prefix, const char * Description, bool useTimeStamp)
{

	char p[MAX_PATH];
	p[0] = 0;
	time_t t = time(NULL);
	tm a;
	gmtime_s(&a, &t);
	strcat(p, Prefix);
	strcat(p, "/");
	strcat(p, Description);
	if(useTimeStamp)
	{
		char ftime[100];
		snprintf(ftime, 100, "-%-4d-%02d-%02d %02d-%02d-%02d", a.tm_year+1900, a.tm_mon+1,
			a.tm_mday, a.tm_hour, a.tm_min, a.tm_sec);
		strcat(p, ftime);
	}

	strcat(p, ".log");
	return string(p);
}

#if defined( __WIN32__) || defined( WIN32 ) || defined ( _WIN32 )
unsigned int _stdcall threadLoop(void * arguments){
	oLog * sts = (oLog *) arguments;
	sts->Run();
	return 0;
}
#else
void * threadLoop(void * arguments){
	oLog * sts = (oLog *) arguments;
	sts->Run();
	return 0;
}
#endif
}

using namespace util;

oLog::oLog():m_bStarted(false)
, m_queue(MININUM_LOG_QUEUE_SIZE) {

}

oLog::~oLog() {

}

void oLog::outFile(const char* szFileName, const char* szMsg, const char* szSource, bool bPrintTime/* = true*/)
{
	if(NULL == szFileName || NULL == szMsg) {
		return;
	}

	struct OutputData* pOutput = m_queue.WriteLock();
	pOutput->strfileName = szFileName;

	if(bPrintTime) {
		char time_buffer[TIME_FORMAT_LENGTH];
		Time(time_buffer);
		pOutput->strMsg = time_buffer;
	}

	if(szSource != NULL){
		pOutput->strMsg += szSource;
		pOutput->strMsg += ": ";
	}
	pOutput->strMsg += szMsg;
	m_queue.WriteUnlock();
}

time_t oLog::Time(char* buffer)
{
	time_t now;
	struct tm timeinfo;

	time( &now );
	localtime_s( &timeinfo, &now );

	if(NULL == buffer) {
		return now;
	}

	strftime(buffer,TIME_FORMAT_LENGTH,TIME_FORMAT, &timeinfo);

    return now;
}

void oLog::outString( const char * str, ... )
{
	if(!m_bStarted)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, str);
	vsnprintf(buf, 32768, str, ap);
	va_end(ap);

	outFile(NORMAL_LOG_FILE_NAME, buf);
}

void oLog::outError( const char * err, ... )
{
	if(!m_bStarted)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, err);
	vsnprintf(buf, 32768, err, ap);
	va_end(ap);

	outFile(ERROR_LOG_FILE_NAME, buf);
}

void oLog::outBasic( const char * str, ... )
{
	if(!m_bStarted)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, str);
	vsnprintf(buf, 32768, str, ap);
	va_end(ap);

	outFile(NORMAL_LOG_FILE_NAME, buf);
}

void oLog::outDetail( const char * str, ... )
{
	if(!m_bStarted || m_fileLogLevel < 1)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, str);
	vsnprintf(buf, 32768, str, ap);
	va_end(ap);

	outFile(NORMAL_LOG_FILE_NAME, buf);
}

void oLog::outDebug( const char * str, ... )
{
	if(!m_bStarted || m_fileLogLevel < 2)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, str);
	vsnprintf(buf, 32768, str, ap);
	va_end(ap);

	outFile(DEBUG_LOG_FILE_NAME, buf);
}

void oLog::outLog(const char* szFileName, const char * format, ...) {

	if(!m_bStarted)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, format);
	vsnprintf(buf, 32768, format, ap);
	va_end(ap);

	outFile(szFileName, buf);
}

//old NGLog.h methods
void oLog::Notice(const char * source, const char * format, ...)
{
	if(!m_bStarted || m_fileLogLevel < 1)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, format);
	vsnprintf(buf, 32768, format, ap);
	va_end(ap);

	outFile(NORMAL_LOG_FILE_NAME, buf, source);
}

void oLog::Warning(const char * source, const char * format, ...)
{
	if(!m_bStarted || m_fileLogLevel < 1)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, format);
	vsnprintf(buf, 32768, format, ap);
	va_end(ap);

	outFile(WARNING_LOG_FILE_NAME, buf, source);
}

void oLog::Success(const char * source, const char * format, ...)
{
	if(!m_bStarted)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, format);
	vsnprintf(buf, 32768, format, ap);
	va_end(ap);

	outFile(NORMAL_LOG_FILE_NAME, buf, source);
}

void oLog::Error(const char * source, const char * format, ...)
{
	if(!m_bStarted) 
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, format);
	vsnprintf(buf, 32768, format, ap);
	va_end(ap);

	outFile(ERROR_LOG_FILE_NAME, buf, source);
}

void oLog::Debug(const char * source, const char * format, ...)
{
	if(!m_bStarted || m_fileLogLevel < 2)
		return;

	char buf[32768];
	va_list ap;

	va_start(ap, format);
	vsnprintf(buf, 32768, format, ap);
	va_end(ap);

	outFile(DEBUG_LOG_FILE_NAME, buf, source);
}

void oLog::LargeErrorMessage(const char * source, ...)
{
	if(!m_bStarted || NULL == source)
	{
		return;
	}
	va_list ap;
	va_start(ap, source);

	std::vector<char*> lines;
	char * pointer;

	pointer = const_cast<char*>(source);
	lines.push_back(pointer);

	size_t i,j,k;
	pointer = va_arg(ap, char*);
	while( pointer != NULL )
	{
		lines.push_back( pointer );
		pointer = va_arg(ap, char*);
	}
	va_end(ap);
	
	outError("*********************************************************************");
	outError("*                        MAJOR ERROR/WARNING                        *");
	outError("*                        ===================                        *");

	for(std::vector<char*>::iterator itr = lines.begin(); itr != lines.end(); ++itr)
	{
		stringstream sstext;
		i = strlen(*itr);
		j = (i<=65) ? 65 - i : 0;
		sstext << "* " << *itr;
		for( k = 0; k < j; ++k )
		{
			sstext << " ";
		}

		sstext << " *";
		outError(sstext.str().c_str());
	}

	outError("*********************************************************************");
}

void oLog::Init(int32_t fileLogLevel, const string strLogPath)
{
	if(atomic_cmpxchg8(&m_bStarted, true, false) != false) {
		return;
	}
	m_strLogPath = strLogPath;

	if(access(m_strLogPath.c_str(), 0) == -1) {
		mkdir(m_strLogPath.c_str());
	}

	SetFileLoggingLevel(fileLogLevel);

#if defined( __WIN32__) || defined( WIN32 ) || defined ( _WIN32 )
	HANDLE handle = (HANDLE)_beginthreadex(NULL, 0, &threadLoop, (LPVOID)this, 0, NULL);
	m_threadControl.Setup(handle, 0);
#else
	pthread_t tid;
	pthread_create(&tid, NULL, &threadLoop, (void*)this);
	m_threadControl.Setup(tid);
	pthread_detach(tid);
#endif

}

void oLog::Dispose()
{
	atomic_xchg8(&m_bStarted, false);
	m_threadControl.Join();
}

void oLog::SetFileLoggingLevel(int32_t level)
{
	//log level -1 is no more allowed
	if(level >= 0) {
		m_fileLogLevel = level;
	}
}

void oLog::Run()
{
	while(m_bStarted) {

		int nSize = m_queue.Size();
		for(int i = 0; i < nSize; ++i) {
			struct OutputData* pOutput = m_queue.ReadLock();
			if(NULL == pOutput) {
				break;
			}

			time_t curTime = time(NULL);
			struct tm tmCur = {0,0,0,0,0,0,0,0,0};
			localtime_s(&tmCur, &curTime);

			char szLogFile[MAX_PATH] ={'\0'};
			sprintf_s(szLogFile, "%s%s(%4d-%02d-%02d).log", m_strLogPath.c_str(), pOutput->strfileName.c_str(),
				tmCur.tm_year + 1900, tmCur.tm_mon+1, tmCur.tm_mday);

			FILE* file(NULL);
			if(fopen_s(&file, szLogFile, "a+") != 0) {
				continue;
			}
			fprintf(file, "%s\n", pOutput->strMsg.c_str());
			long logLength = filelength(fileno(file));
			fclose(file);
			// Log file is too large
			if (logLength >= MAX_LOG_FILE_SIZE) {

				char szBackupFile[MAX_PATH] = {'\0'};
				sprintf_s(szBackupFile, "%s%s(%4d-%02d-%02d-%02d%02d%02d-backup).log", m_strLogPath.c_str(),
					pOutput->strfileName.c_str(), tmCur.tm_year + 1900, tmCur.tm_mon+1, tmCur.tm_mday,
					tmCur.tm_hour, tmCur.tm_min, tmCur.tm_sec);

				rename(szLogFile, szBackupFile);
			}
			m_queue.ReadUnlock();
		}		
		Sleep(10);
	}
}


