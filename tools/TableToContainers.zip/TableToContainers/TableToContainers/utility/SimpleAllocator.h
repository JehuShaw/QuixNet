/*
 * File:   SimpleAllocator.h
 * Author: Jehu Shaw
 *
 * Created on 2014_4_23, 10:32
 */

#ifndef SIMPLEALLOCATOR_H_
#define SIMPLEALLOCATOR_H_

#include <vector>
#include <assert.h>
#include "SpinLock.h"
#include "ScopedLock.h"

namespace util {

class BytesUnit {
public:
	BytesUnit(size_t size) 
        : m_object(NULL)
        , m_index(-1)
        , m_delete(true) 
    {
		if(0 == size) {
			return;
		}
		m_object = malloc(size);
	}

	BytesUnit(void* object, bool bDelete) 
		: m_index(-1), m_object(object), m_delete(bDelete)  {
	}

    BytesUnit(const BytesUnit& orig): m_index(orig.m_index),
        m_object(orig.m_object), m_delete(orig.m_delete) {

    }

	~BytesUnit() {

	}

	void Dispose() {
		if(m_delete) {
			free(m_object);
			m_object = NULL;
		}
	}

	inline void* getObject() {
		return m_object;
	}

	inline void setIndex(long index) {
		atomic_xchg(&this->m_index, index);
	}

	inline long getIndex() {
		return (long)this->m_index;
	}

	bool operator==(const BytesUnit& right) const {
		return this->m_object == right.m_object;
	}
	
	bool operator!=(const BytesUnit& right) const
	{
		return this->m_object != right.m_object;
	}

	bool operator>(const BytesUnit& right) const
	{
		return this->m_object > right.m_object;
	}

	bool operator<(const BytesUnit& right) const
	{
		return this->m_object < right.m_object;
	}

private:
	void* m_object;
	volatile long m_index;
	bool m_delete;
};

template <
		 class T,					// allocate type
         short blocksPerBatch		// preallocation size
         >
class SimpleAllocator
{
public:
	typedef std::vector<T*> TVector;
	typedef std::set<BytesUnit> ByteSet;

public:
	SimpleAllocator(): offset(-1) {
	}

	~SimpleAllocator();

	T* allocateBlock();

	void releaseBlock(const T* pBlock);

private:

	inline void pushBackObject(BytesUnit& unit) {
        unit.setIndex((long)objectVector.size());
		objectVector.push_back((T*)unit.getObject());
	}

	inline BytesUnit* findUnit(const T* pBlock) {
		BytesUnit unit((void*)pBlock, false);
		ByteSet::iterator it(batchSet.find(unit));
		if(batchSet.end() == it) {
			return NULL;
		}
		return (BytesUnit*)&*it;
	}

	inline bool insertUnit(const BytesUnit& unit) {
		ByteSet::_Pairib pairIB(batchSet.insert(unit));
		return pairIB.second;
	}


private:
	// used object set
	TVector objectVector;
	// binary date set
	ByteSet batchSet;
	// allocation offset
	long offset;
    // allocation mutex
    thd::CSpinLock mutex;
};

template <typename T, short blocksPerBatch>
SimpleAllocator<T, blocksPerBatch>::~SimpleAllocator() {
	objectVector.clear();
	ByteSet::iterator it = batchSet.begin();
	for(; batchSet.end() != it; ++it) {
		const_cast<ByteSet::value_type&>(*it).Dispose();
	}
}

template <typename T, short blocksPerBatch>
void SimpleAllocator<T, blocksPerBatch>::releaseBlock(const T* pBlock) {

	if(NULL == pBlock) {
		return;
	}

	thd::CScopedLock scopedSpin(mutex);

    if(offset < 0) {
        return;
    }

	BytesUnit* pCurUnit = findUnit(pBlock);
	if(NULL == pCurUnit) {
		return;
	}
	
	if(pCurUnit->getIndex() == (long)offset) {
		--offset;
		return;
	}

	T* pLast = objectVector[(long)offset];
	assert(NULL != pLast);
	BytesUnit* pLastUnit = findUnit(pLast);
	assert(NULL != pLastUnit);

	long curIndex = pCurUnit->getIndex();
	objectVector[offset] = (T*)pCurUnit->getObject();
	objectVector[curIndex] = (T*)pLastUnit->getObject();
	pLastUnit->setIndex(curIndex);
	pCurUnit->setIndex(offset);

	--offset;
}

template <typename T, short blocksPerBatch>
T* SimpleAllocator<T, blocksPerBatch>::allocateBlock() {

    thd::CScopedLock scopedSpin(mutex);
    if(offset + 1 >= (long)objectVector.size()) {
        // first allocator
        BytesUnit bytesUnit(sizeof(T));
        pushBackObject(bytesUnit);
        insertUnit(bytesUnit);
        // next allocator
        for(int i = 1; i < blocksPerBatch; ++i) {
            
            BytesUnit bytesUnit(sizeof(T));
            pushBackObject(bytesUnit);
            insertUnit(bytesUnit);
        }
    }
	return objectVector[++offset];
}

}

#endif /* SIMPLEALLOCATOR_H_ */
