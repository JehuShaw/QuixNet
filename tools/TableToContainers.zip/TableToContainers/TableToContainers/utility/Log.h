/*
 * File:   Log.h
 * Author: Jehu Shaw
 *
 */

#ifndef _SERVER_LOG_H
#define _SERVER_LOG_H

#include "Common.h"
#include "Singleton.h"
#include "CircleQueue.h"

namespace util {

#define TIME_FORMAT "[%H:%M]"
#define TIME_FORMAT_LENGTH 8
// set default file name
#define NORMAL_LOG_FILE_NAME "normal"
#define DEBUG_LOG_FILE_NAME "debug"
#define WARNING_LOG_FILE_NAME "warning"
#define ERROR_LOG_FILE_NAME "error"

static const long MAX_LOG_FILE_SIZE = 1024 * 1024 * 16;
static const unsigned int MININUM_LOG_QUEUE_SIZE = 64;

std::string FormatOutputString(const char * Prefix, const char * Description, bool useTimeStamp);

template<class ElementType> class CCircleQueue;

struct OutputData {
	std::string strfileName;
	std::string strMsg;
}; 

class SERVER_DECL oLog : public Singleton< oLog > {
public:
	oLog();
	~oLog();
  //log level 0
  void outString( const char * str, ... );
  void outError( const char * err, ... );
  void outBasic( const char * str, ... );
  //log level 1
  void outDetail( const char * str, ... );
  //log level 2
  void outDebug( const char * str, ... );

  void outLog(const char* szFileName, const char * format, ...);

  void outFile(const char* szFileName, const char* szMsg,
	  const char* szSource = NULL, bool bPrintTime = true);

  //old NGLog.h methods
  //log level 0
  void Success(const char * source, const char * format, ...);
  void Error(const char * source, const char * format, ...);
  void LargeErrorMessage(const char * str, ...);
  //log level 1
  void Notice(const char * source, const char * format, ...);
  void Warning(const char * source, const char * format, ...);
  //log level 2
  void Debug(const char * source, const char * format, ...);
  
  void Init(int32_t fileLogLevel, const std::string strLogPath = "./log/");
  void SetFileLoggingLevel(int32_t level);

  void Dispose();

private:
	volatile long m_fileLogLevel;
	thd::ThreadController m_threadControl;
	volatile bool m_bStarted;
	thd::CCircleQueue<struct OutputData> m_queue;
	std::string m_strLogPath;

private:
    void Run();

	time_t Time(char *buffer);

	INLINE char dcd( char in ){
		char out = in;
		out -= 13;
		out ^= 131;
		return out;
	} 

	void dcds( char *str ){
		unsigned long i = 0;
		size_t len = strlen( str );

		for(i = 0; i < len; ++i )
			str[i] = dcd( str[i] );

	}

	void pdcds( const char *str, char *buf ){
		strcpy(buf, str);
		dcds( buf );
	}

#if defined( __WIN32__) || defined( WIN32 ) || defined ( _WIN32 )
friend unsigned int _stdcall threadLoop(void * arguments);
#else
friend void * threadLoop(void * arguments);
#endif 

};

}

#define sLog (*util::oLog::instance())
#define Log sLog


#endif
