/*
 * File:   Singleton.h
 * Author: Jehu Shaw
 *
 */

#ifndef _SERVER_SINGLETON_H
#define _SERVER_SINGLETON_H

#include <assert.h>
#include "SpinLock.h"
#include "ScopedLock.h"
#include "AutoPointer.h"

namespace util {

template <class T>
class Singleton
{
public:
	static CAutoPointer<T> instance();
	static void release();
protected:

	Singleton(void){ assert(_instance == NULL); }

	~Singleton(void){}

	Singleton(const Singleton&){}

	Singleton & operator= (const Singleton &){ return *this; }

	static CAutoPointer<T> _instance;
	static thd::CSpinLock _lock; 
};

template <class T>
CAutoPointer<T> Singleton<T>::_instance;

template <class T>
thd::CSpinLock Singleton<T>::_lock; 

template <class T>
CAutoPointer<T> Singleton<T>::instance()
{
	if(_instance == NULL)
	{
		thd::CScopedLock scopedLock(_lock);
		if(_instance == NULL)
		{
			_instance.SetRawPointer(new T);
		}
	}
	return _instance;
}

template <class T>
void Singleton<T>::release()
{
	if(_instance != NULL) {
		thd::CScopedLock scopedLock(_lock);
		_instance.SetRawPointer(NULL);
	}
}

}

#endif
