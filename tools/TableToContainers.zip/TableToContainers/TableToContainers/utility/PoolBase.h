/*
 * File:   PoolBase.h
 * Author: Jehu Shaw
 *
 * Created on 2014_4_23, 10:32
 */

#ifndef POOLBASE_H_
#define POOLBASE_H_

#include "Common.h"
#include <vector>
#include "SimpleAllocator.h"

namespace util {

#ifdef DISABLE_POOL_BASE
template <
	typename T,												// allocation type
	short BatchSize                                         // preallocate size
>	
class PoolBase{};

#else

template <
	typename T,
	short BatchSize,
	template <typename, short> class Alloc = SimpleAllocator
>	
class PoolBase
{
	typedef Alloc<T, BatchSize> MyAlloc;
public:
	virtual ~PoolBase() {
	}

	void* operator new(size_t s) {
		return myAlloc.allocateBlock();
	}

	void operator delete(void* p) {
		myAlloc.releaseBlock((T*)p);
	}

private:
	void* operator new[](size_t s) {
		return NULL;
	}

	void operator delete[](void* p) {		
	}

private:
	static MyAlloc myAlloc;
};

template <typename T, short BatchSize, template <typename, short> class Alloc>
typename PoolBase<T, BatchSize, Alloc>::MyAlloc PoolBase<T, BatchSize, Alloc>::myAlloc;


#endif // DISABLE_POOL_BASE

}

#endif /* POOLBASE_H_ */