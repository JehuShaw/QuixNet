
// TableToContainersDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"
#include "DatabaseEnv.h"

namespace util {
	class CSeparatedStream;
}

// CTableToContainersDlg �Ի���
class CTableToContainersDlg : public CDialogEx
{
// ����
public:
	CTableToContainersDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_TABLETOCONTAINERS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

protected:
	util::CAutoPointer<db::Database> m_pDatabase;
	void LoadDatabases();
	void SelectSrcDatabase(int nIdx);
	void SelectDestDatabase(int nIdx);
	void LoadSrcFields(const CString& strDatabase, const CString& strTable);
	void GetConfigOptions(const CString& strDatabase);
	int AddContainerValue(const char* sql);
	void LoadSrcKeyFields(const CString& strDatabase, const CString& strTable);
	bool ExcludeKeyFields(const CString& field);
	void UpdateValueString();
	bool m_bFindDestTable;
	char m_cSeparator;
	char m_cTableMapDelimiter;

	std::vector<CString> m_keyColumns;
	CString m_constraintName;
	int m_nFlagsIdx;
	int m_nCasIdx;
	int m_nExpireIdx;
	int m_nBlankIdx;
public:
	afx_msg void OnBnClickedButton3();
	CEdit m_edtPassword;
	CEdit m_edtPort;
	CIPAddressCtrl m_edtHost;
	CEdit m_edtUser;
	CEdit m_edtState;
	CComboBox m_comDatabases;
	CComboBox m_comTables;
	CComboBox m_desDatabases;
	afx_msg void OnCbnSelchangeCombo1();
	CButton m_btnConnect;
	afx_msg void OnCbnSelchangeCombo3();
	CEdit m_desTable;
	CComboBox m_comFlags;
	CComboBox m_comCas;
	CComboBox m_comExpire;
	afx_msg void OnCbnSelchangeCombo2();
	afx_msg void OnBnClickedButton1();
	CEdit m_edtName;
	CComboBox m_comKeyType;
	afx_msg void OnBnClickedButton2();
	CEdit m_edtKeys;
	afx_msg void OnBnClickedButton4();
	CEdit m_edtValues;
	afx_msg void OnCbnSelchangeCombo4();
	afx_msg void OnCbnSelchangeCombo5();
	afx_msg void OnCbnSelchangeCombo6();
	CComboBox m_comExcludeKey;
	CComboBox m_comIncludeKey;
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
};
