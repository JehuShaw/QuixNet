/*
 * File:   Errors.h
 * Author: Jehu Shaw
 *
 */

#ifndef _SERVER_ERRORS_H
#define _SERVER_ERRORS_H

// TODO: handle errors better

// An assert isn't necessarily fatal, but we want to stop anyways
#define WPAssert( EXPR ) if (!(EXPR)) { assert(EXPR); ((void(*)())0)(); }

#define WPError( assertion, errmsg ) if( ! (assertion) ) { Log.outError( "%s:%i ERROR:\n  %s\n", __FILE__, __LINE__, (char *)errmsg ); assert( #assertion &&0 ); }
#define WPWarning( assertion, errmsg ) if( ! (assertion) ) { Log.outError( "%s:%i WARNING:\n  %s\n", __FILE__, __LINE__, (char *)errmsg ); }

// This should always halt everything.  If you ever find yourself wanting to remove the assert( false ), switch to WPWarning or WPError
#define WPFatal( assertion, errmsg ) if( ! (assertion) ) { Log.outError( "%s:%i FATAL ERROR:\n  %s\n", __FILE__, __LINE__, (char *)errmsg ); assert( #assertion &&0 ); abort(); }

#define ASSERT WPAssert

enum eServerError{
	//SERROR_TIMEOUT = 0,
	//SERROR_UNSPECIFIED = -1,
	//NO_THIS_REGISTER_SERVER_TYPE = -2,
	//NO_REMOTE_SERVER_MODULE = -3,
	//CONNECT_CHANNEL_ALREADY_EXIST = -4,
	//NO_THIS_SERVER_MODULE = -5,
	//REMOVE_CONNECT_CHANNEL_FAIL = -6,
};

#endif

